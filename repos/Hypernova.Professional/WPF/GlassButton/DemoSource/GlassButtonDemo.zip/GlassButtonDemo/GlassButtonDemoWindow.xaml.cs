﻿namespace GlassButtonDemo
{
    /// <summary>
    /// Interaction logic for GlassButtonDemoWindow.xaml
    /// </summary>
    public partial class GlassButtonDemoWindow
    {
        public GlassButtonDemoWindow()
        {
            InitializeComponent();
        }
    }
}
