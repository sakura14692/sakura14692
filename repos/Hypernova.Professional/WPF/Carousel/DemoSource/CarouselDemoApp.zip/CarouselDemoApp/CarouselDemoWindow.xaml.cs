﻿using System.Windows.Media;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Threading;
using Binarymission.WPF.Controls.AdvancedContainerControls;

namespace CarouselDemoApp
{
    public partial class CarouselDemoWindow
    {
        private DispatcherTimer _timer;

        public CarouselDemoWindow()
        {
            InitializeComponent();
            DataContext = this;
            Initialise();
        }

        public static readonly DependencyProperty CarouselDataSourceItemsCountProperty = DependencyProperty.Register(
            "CarouselDataSourceItemsCount", typeof (int), typeof (CarouselDemoWindow), new PropertyMetadata(default(int)));

        public int CarouselDataSourceItemsCount
        {
            get { return (int) GetValue(CarouselDataSourceItemsCountProperty); }
            set { SetValue(CarouselDataSourceItemsCountProperty, value); }
        }
       
        public static readonly DependencyProperty ItemDimensionProperty = DependencyProperty.Register(
            "ItemDimension", typeof (Size), typeof (CarouselDemoWindow), new PropertyMetadata(default(Size)));

        public Size ItemDimension
        {
            get { return (Size) GetValue(ItemDimensionProperty); }
            set { SetValue(ItemDimensionProperty, value); }
        }

        public static readonly DependencyProperty SelectedCarouselIndexProperty = DependencyProperty.Register(
            "SelectedCarouselIndex", typeof (int), typeof (CarouselDemoWindow), new PropertyMetadata(default(int)));

        public int SelectedCarouselIndex
        {
            get { return (int) GetValue(SelectedCarouselIndexProperty); }
            set { SetValue(SelectedCarouselIndexProperty, value); }
        }

        public static readonly DependencyProperty SelectedAmbientLightColorBrushProperty = DependencyProperty.Register(
            "SelectedAmbientLightColorBrush", typeof (SolidColorBrush), typeof (CarouselDemoWindow), new PropertyMetadata(default(SolidColorBrush),
                (o, args) =>
                {
                    var instance = o as CarouselDemoWindow;

                    if (instance == null)
                        return;

                    instance.Carousel.CarouselViewport3DAmbientLightColor = instance.SelectedAmbientLightColorBrush.Color;
                }));

        public SolidColorBrush SelectedAmbientLightColorBrush
        {
            get { return (SolidColorBrush) GetValue(SelectedAmbientLightColorBrushProperty); }
            set { SetValue(SelectedAmbientLightColorBrushProperty, value); }
        }
        
        public Carousel Carousel => _carouselInstance;

        private void Initialise()
        {
            ItemDimension = new Size(650, 550);
            SelectedAmbientLightColorBrush = new SolidColorBrush(Colors.Transparent);
            
            _timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(1750) };
            _timer.Tick += PerformAutoCarouselItemSelection();

            _timer.Start();

            var source = new List<string>
            {
                @"\MediaObjects\Media1.jpg",
                @"\MediaObjects\Media2.jpg",
                @"\MediaObjects\Media3.jpg",
                @"\MediaObjects\Media4.jpg",
                @"\MediaObjects\Media5.jpg",
                @"\MediaObjects\Media6.jpg"
            };

            _carouselInstance.ItemsSource = source;
            CarouselDataSourceItemsCount = source.Count - 1;
            SelectedCarouselIndex = 0;
        }

        private EventHandler PerformAutoCarouselItemSelection()
        {
            return (senderObject, eArgs) =>
            {
                if (_carouselInstance == null || _carouselInstance.Items.Count == 0) return;

                if (SelectedCarouselIndex < _carouselInstance.Items.Count-1) _carouselInstance.SelectedIndex++;
                else
                {
                    SelectedCarouselIndex = 0;
                }
            };
        }

        private void chkTimerEnabled_Click(object sender, RoutedEventArgs e)
        {
            if (ChkTimerEnabled.IsChecked != null && ChkTimerEnabled.IsChecked.Value) _timer.Start();
            else _timer.Stop();
        }

        private void ItemWidthValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            ItemDimension = new Size(ItemWidthSlider.Value, ItemDimension.Height);
        }

        private void ItemHeightValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            ItemDimension = new Size(ItemDimension.Width, ItemHeightSlider.Value);
        }

        private void ExitInvoked(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}