﻿using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media.Imaging;

namespace BinaryTreeListViewWPFDemo.Converters
{
    public class PathToImageSourceConverter : IValueConverter
    {
        public object Convert(object o, Type type, object parameter, CultureInfo culture)
        {
            // Just simply return a BitmapImage instance from the uri obtained from the xml data source.
            return new BitmapImage(new Uri(o.ToString(), UriKind.Relative));
        }

        public object ConvertBack(object o, Type type, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}
