﻿using System;
using System.Collections.Generic;
using Binarymission.WPF.Controls.WindowControls;
using Binarymission.WPF.Controls.WindowControls.Enums;

namespace BinaryTreeListViewWPFDemo
{
    /// <summary>
    /// Interaction logic for TreeListViewDemoWindow.xaml
    /// </summary>
    public partial class TreeListViewDemoWindow
    {
        public TreeListViewDemoWindow()
        {
            InitializeComponent();
            Loaded += TreeListViewDemoWindow_Loaded;
        }

        private void TreeListViewDemoWindow_Loaded(object sender, System.Windows.RoutedEventArgs e)
        {
            _treeListViewInstance.ExpandNodesByIndices(new List<int> { 0, 3, 5});
            _treeListViewInstance.SelectNodeByIndex(3);
            _treeListViewInstance.Focus();
        }

        protected override void OnInitialized(EventArgs e)
        {
            base.OnInitialized(e);
            BinaryRibbonBuiltInSkinController.Skin = RibbonSkin.OfficeBlack;
        }

        private void CollapseAllNodesRequested(object sender, System.Windows.RoutedEventArgs e)
        {
            _treeListViewInstance.CollapseAllNodes();
        }

        private void ExpandAllNodesRequested(object sender, System.Windows.RoutedEventArgs e)
        {
            _treeListViewInstance.ExpandAllNodes(true);
        }
        
        private void AppExitRequested(object sender, System.Windows.RoutedEventArgs e)
        {
            Close();
        }
    }
}
