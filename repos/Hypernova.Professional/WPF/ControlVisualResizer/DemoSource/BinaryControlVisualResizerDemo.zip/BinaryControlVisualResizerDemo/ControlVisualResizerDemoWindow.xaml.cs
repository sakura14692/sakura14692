﻿using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Win32;

namespace BinaryControlVisualResizerDemo
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class ControlVisualResizerDemo
    {
        public ControlVisualResizerDemo()
        {
            InitializeComponent();
            InitialiseImageSourceDefaults();
            DataContext = this;
        }

        private void InitialiseImageSourceDefaults()
        {
            var imageSource = new BitmapImage();
            imageSource.BeginInit();
            imageSource.UriSource =
                new Uri("pack://application:,,,/ControlVisualResizerDemo;component/MediaObjects/LovelyCosmos.png");
            imageSource.EndInit();
            ImageSource = imageSource;
            IsImageSourceValid = true;
        }

        public static readonly DependencyProperty IsImageSourceValidProperty = DependencyProperty.Register(
            "IsImageSourceValid", typeof(bool), typeof(ControlVisualResizerDemo), new PropertyMetadata(default(bool)));

        public bool IsImageSourceValid
        {
            get { return (bool)GetValue(IsImageSourceValidProperty); }
            set { SetValue(IsImageSourceValidProperty, value); }
        }

        public static readonly DependencyProperty ImageUriProperty = DependencyProperty.Register(
            "ImageUri", typeof(string), typeof(ControlVisualResizerDemo), new PropertyMetadata(default(string), (o, args) =>
                {
                    var instance = o as ControlVisualResizerDemo;

                    if (instance == null)
                        return;

                    instance.ImageSource = new System.Windows.Media.Imaging.BitmapImage(new Uri(instance.ImageUri));
                    instance.IsImageSourceValid = instance.ImageSource != null;
                }));

        public string ImageUri
        {
            get { return (string)GetValue(ImageUriProperty); }
            set { SetValue(ImageUriProperty, value); }
        }

        public static readonly DependencyProperty IsPopupOpenProperty = DependencyProperty.Register(
            "IsPopupOpen", typeof (bool), typeof (ControlVisualResizerDemo), new PropertyMetadata(default(bool)));

        public bool IsPopupOpen
        {
            get { return (bool)GetValue(IsPopupOpenProperty); }
            set { SetValue(IsPopupOpenProperty, value); }
        }

        public static readonly DependencyProperty ImageSourceProperty = DependencyProperty.Register(
            "ImageSource", typeof (ImageSource), typeof (ControlVisualResizerDemo));

        public ImageSource ImageSource
        {
            get { return (ImageSource)GetValue(ImageSourceProperty); }
            set { SetValue(ImageSourceProperty, value); }
        }

        private void PopupInvoked(object sender, RoutedEventArgs e)
        {
            IsPopupOpen = !IsPopupOpen;
        }

        private void ExitApp(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void SelectFileInvoked(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
            {
                InitialDirectory = System.IO.Directory.GetCurrentDirectory(),
                Filter = "Image Sources (*.bmp, *.png, *.gif, *.jpg)|*.bmp*;*.png; *.gif; *.jpg",
                Multiselect = false
            };
            var showDialog = dialog.ShowDialog();
            if (showDialog != null && (bool)showDialog)
                ImageUri = dialog.FileName;
        }
    }
}
