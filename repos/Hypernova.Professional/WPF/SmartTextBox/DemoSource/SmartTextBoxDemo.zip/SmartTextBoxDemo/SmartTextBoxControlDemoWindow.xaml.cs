﻿using System.Windows;

namespace SmartTextBoxDemo
{
    /// <summary>
    /// Interaction logic for SmartTextBoxControlDemoWindow.xaml
    /// </summary>
    public partial class SmartTextBoxControlDemoWindow
    {
        public SmartTextBoxControlDemoWindow()
        {
            InitializeComponent();
        }

        private void ExitApp(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
