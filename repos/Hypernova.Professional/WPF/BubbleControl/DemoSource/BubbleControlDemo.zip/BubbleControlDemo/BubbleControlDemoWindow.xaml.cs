﻿using System.Collections.ObjectModel;
using System.Windows;

namespace BubbleControlDemo
{
    /// <summary>
    /// Interaction logic for BubbleControlDemoWindow.xaml
    /// </summary>
    public partial class BubbleControlDemoWindow
    {
        public BubbleControlDemoWindow()
        {
            InitializeComponent();

            // Here I will add the MouseRightButtonUpEvent to be used for invoking the ExoticBubble control's features...
            // Remember, the ExoticBubble control already provides (by default) invoking its services for the "Mouse Left Button down" RoutedEvent.
            // This way, we get the bubble control invoked in many situations.
            ExoticBubbleInvokers = new ObservableCollection<RoutedEvent>
            {
                MouseRightButtonUpEvent
            };

            DataContext = this;
        }

        public ObservableCollection<RoutedEvent> ExoticBubbleInvokers { get; set; }

        private void AppExit(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
