﻿using System.Collections.Generic;
using System.Windows;

namespace SpinnersDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class SpinnersDemoWindow
    {
        public SpinnersDemoWindow()
        {
            InitializeComponent();

            DomainItems = new List<string>
            {
                "WPF", 
                "Silverlight", 
                "Windows Phone",
                "ASP.NET MVC",
                "HTML 5"
            };

            DataContext = this;
        }

        public IEnumerable<string> DomainItems { get; set; }

        private void AppExit(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
