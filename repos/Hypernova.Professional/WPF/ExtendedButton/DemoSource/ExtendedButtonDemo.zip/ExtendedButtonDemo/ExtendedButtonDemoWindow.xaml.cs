﻿using System.Windows;

namespace ExtendedButtonDemo
{
    /// <summary>
    /// Interaction logic for ExtendedButtonDemoWindow.xaml
    /// </summary>
    public partial class ExtendedButtonDemoWindow
    {
        public ExtendedButtonDemoWindow()
        {
            InitializeComponent();
        }
        
        private void AppExitRequestHandler(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
