﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace ExtendedButtonDemo.Converters
{
    public class SimpleCombBoxSelectedIndexBooleanConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value == null || parameter == null)
                return false;

            var param = parameter.ToString();

            var incomingValue = (int)value;
            switch (incomingValue)
            {
                case 0:
                    return false;
                case 1:
                    return string.Equals(param, "Glow", StringComparison.CurrentCultureIgnoreCase);
                case 2:
                    return true;
                default:
                    return false;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
