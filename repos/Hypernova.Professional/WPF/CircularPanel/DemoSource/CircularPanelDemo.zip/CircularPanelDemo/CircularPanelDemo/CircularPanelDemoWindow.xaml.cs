﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Drawing;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Binarymission.WPF.Controls.ExtendedPanelControls;
using Binarymission.WPF.Controls.InputControls.Spinners;

namespace CircularPanelDemo
{
    /// <summary>
    /// Interaction logic for CircularPanelDemoWindow.xaml
    /// </summary>
    public partial class CircularPanelDemoWindow
    {
        private static readonly Random Random = new Random();

        internal class ColorHost
        {
            public Color Color { get; set; }

            public string Name { get; set; }
        }

        public CircularPanelDemoWindow()
        {
            InitializeComponent();
            GapAngleCalculationStrategies = new ObservableCollection<string>(Enum.GetNames(typeof (CircularPanel.GapAngleCalculationStrategy)));
            PopulateSampleContentForCircularPanel();
            DataContext = this;
        }

        public UIElementCollection PanelItems
        {
            get { return (UIElementCollection)GetValue(PanelItemsProperty); }
            set { SetValue(PanelItemsProperty, value); }
        }

        public static readonly DependencyProperty PanelItemsProperty =
            DependencyProperty.Register("PanelItems", typeof(UIElementCollection), typeof(CircularPanelDemoWindow), new PropertyMetadata(null));
        

        public static readonly DependencyProperty GapAngleCalculationStrategiesProperty = DependencyProperty.Register(
            "GapAngleCalculationStrategies", typeof (ObservableCollection<string>), typeof (CircularPanelDemoWindow), new PropertyMetadata(null));

        public ObservableCollection<string> GapAngleCalculationStrategies
        {
            get { return (ObservableCollection<string>) GetValue(GapAngleCalculationStrategiesProperty); }
            set { SetValue(GapAngleCalculationStrategiesProperty, value); }
        }

        public static readonly DependencyProperty IsPanelItemsGapAngleEnabledProperty = DependencyProperty.Register(
            "IsPanelItemsGapAngleEnabled", typeof (bool), typeof (CircularPanelDemoWindow), new PropertyMetadata(default(bool)));

        public bool IsPanelItemsGapAngleEnabled
        {
            get { return (bool) GetValue(IsPanelItemsGapAngleEnabledProperty); }
            set { SetValue(IsPanelItemsGapAngleEnabledProperty, value); }
        }

        private void PopulateSampleContentForCircularPanel()
        {
            var colorsList = (from pi in typeof(Colors).GetProperties()
                              select new ColorHost()
                              {
                                  Name = pi.Name,
                                  Color = (Color)pi.GetValue(null, null)
                              }).ToList();

            for (var i = 10; i < 25; i++)
            {
                var border = new Border { Background = new SolidColorBrush(colorsList.ElementAt(Random.Next(0, colorsList.Count - 1)).Color) };
                var borderChild = new TextBlock { Text = $"Item {i}" };
                border.Child = borderChild;
                _circularPanelInstance.Children.Add(border);
            }
        }
        
        private void AngleCalculationStrategyProvider_OnValueChanged(object sender, RoutedEventArgs e)
        {
            var args = e as DomainSpinner.ValueChangedEventArgs;

            if (args != null && args.Value == null)
                return;

            if (args != null)
                IsPanelItemsGapAngleEnabled = (CircularPanel.GapAngleCalculationStrategy)
                    Enum.Parse(typeof (CircularPanel.GapAngleCalculationStrategy),
                        args.Value.ToString()) == CircularPanel.GapAngleCalculationStrategy.Custom;
        }

        private void AppExitInvokeHandler(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
