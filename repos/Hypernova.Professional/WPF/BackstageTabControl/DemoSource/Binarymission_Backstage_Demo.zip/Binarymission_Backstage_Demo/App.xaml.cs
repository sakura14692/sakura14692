﻿using System.Windows;

namespace Binarymission.Demos.BackstageTabControlDemo
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App
    {
    }
}
