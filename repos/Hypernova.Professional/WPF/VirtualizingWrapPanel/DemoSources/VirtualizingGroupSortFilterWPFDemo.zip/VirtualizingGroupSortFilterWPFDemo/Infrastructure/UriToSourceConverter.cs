﻿using System;
using System.Windows.Data;
using System.Windows.Media.Imaging;

namespace VirtualizingGroupSortFilterWPFDemo.Infrastructure
{
    public class UriToSourceConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            var sourceImage = new BitmapImage();
            var uri = value as Uri;

            if (uri != null)
            {
                sourceImage = new BitmapImage(uri);
            }

            return sourceImage;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
