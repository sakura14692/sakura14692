﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Threading;
using System.Windows.Data;
using System.Windows.Input;
using Binarymission.WPF.Data.DataExtensions;
using VirtualizingGroupSortFilterWPFDemo.Constants;
using VirtualizingGroupSortFilterWPFDemo.Infrastructure;
using VirtualizingGroupSortFilterWPFDemo.Models;

namespace VirtualizingGroupSortFilterWPFDemo.ViewModels
{
    // A simple view mode class that will be used as the data context for the view.
    // The People property of this class will be the one that the itemscontrol will bind to.

    class PeopleViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged = delegate { };
        VirtualizingCollectionView _people;
        private readonly Random _random;
        private RelayCommand _filterPeopleCommand;

        public PeopleViewModel()
        {
            _random = new Random();
           CreatePeople();
        }

        public VirtualizingCollectionView People
        {
            get { return _people; }
            private set
            {
                _people = value;
                PropertyChanged(this, new PropertyChangedEventArgs("People"));
            }
        }

        public PersonDto SelectedPerson { get; set; }
        
        public ICommand FilterPeopleCommand
        {
            get {
                return _filterPeopleCommand ??
                       (_filterPeopleCommand =
                           new RelayCommand(param => FilterPeople(param as string),
                               param => CanFilterPeople(param as string)));
            }
        }
        
        private void CreatePeople()
        {
            var listOfPerson = new ObservableCollection<PersonDto>();

            for (var i = 0; i < 3000; i++)
            {
                // Applying a simple criteria to set some person objects to be residing in south and others as unknown - just to see the effect on grouping feature.
                                
                var imageIndex = _random.Next(0, 23);
                var imageUri = new Uri("pack://application:,,,/VirtualizingGroupSortFilterWPFDemo;Component/Resources/" +
                                       $"{imageIndex}.png");
                
                var person = new PersonDto("First" + i,
                    "Last" + i,
                    (i % 10 == 3) ? ResidenceLocation.South : ResidenceLocation.North,
                    i,
                    imageUri);
                    
                listOfPerson.Add(person);
            }

            // This is the important thing to do.
            // Create an instance of the VirtualizingCollectionView class and supply the actual data source to it, so it can perform virtualization on it.
            var virtualizedView = new VirtualizingCollectionView(listOfPerson);

            // Lets apply the sorting on the ID property
            virtualizedView.SortDescriptions?.Add(new SortDescription("ID", ListSortDirection.Ascending));

            // Lets apply the grouping on the Residence property.
            virtualizedView.GroupDescriptions?.Add(new PropertyGroupDescription("Residence"));

            People = virtualizedView;
        }
       
        private static bool CanFilterPeople(string filterTextLastname)
        {
            return true;
        }

        private void FilterPeople(string filterTextLastname)
        {
            if (filterTextLastname == null) return;

            if (People == null) return;

            if (!People.CanFilter) return;

            CreatePeople();

            People.Filter = (param) =>
            {
                var personDto = param as PersonDto;
                return personDto != null && personDto.LastName.StartsWith(filterTextLastname, true,
                    Thread.CurrentThread.CurrentCulture);
            };
        }        
    }
}
