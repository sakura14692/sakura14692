﻿using System;
using System.ComponentModel;
using VirtualizingGroupSortFilterWPFDemo.Constants;

namespace VirtualizingGroupSortFilterWPFDemo.Models
{
    public class PersonDto : INotifyPropertyChanged
    {
        public PersonDto() { }

        public PersonDto(string firstName, 
                            string lastName,
                            ResidenceLocation residenceLocation,
                            long id, 
                            Uri personResidenceCityWeatherConditionImageUri)
        {
            _firstName = firstName;
            _lastName = lastName;
            _residence = residenceLocation;
            _id = id;
            _personResidenceCityWeatherConditionImageUri = personResidenceCityWeatherConditionImageUri;
        }

        private long _id;

        public long Id
        {
            get { return _id; }
            set
            {
                if (_id != value)
                {
                    _id = value;
                    RaisePropertyChanged("Id");
                }
            }
        }

        private ResidenceLocation _residence;

        public ResidenceLocation Residence
        {
            get { return _residence; }
            set
            {
                if (_residence != value)
                {
                    _residence = value;
                    RaisePropertyChanged("Residence");
                }
            }
        }

        private string _firstName;

        public string FirstName
        {
            get { return _firstName; }
            set
            {
                if (_firstName != value)
                {
                    _firstName = value;
                    RaisePropertyChanged("FirstName");
                }
            }
        }

        private string _lastName;

        public string LastName
        {
            get { return _lastName; }
            set
            {
                if (_lastName != value)
                {
                    _lastName = value;
                    RaisePropertyChanged("LastName");
                }
            }
        }

        private Uri _personResidenceCityWeatherConditionImageUri;

        public Uri PersonResidenceCityWeatherConditionImageUri
        {
            get { return _personResidenceCityWeatherConditionImageUri; }
            set
            {
                if (_personResidenceCityWeatherConditionImageUri != value)
                {
                    _personResidenceCityWeatherConditionImageUri = value;
                    RaisePropertyChanged("_personResidenceCityWeatherConditionImageUri");
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged = delegate { };

        public void RaisePropertyChanged(string propertyName)
        {
            var handler = PropertyChanged;
            handler?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
