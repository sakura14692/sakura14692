﻿using VirtualizingGroupSortFilterWPFDemo.ViewModels;

namespace VirtualizingGroupSortFilterWPFDemo
{
    /// <summary>
    /// Interaction logic for VirtualizingGroupSortFilterDemoWindow.xaml
    /// </summary>
    public partial class VirtualizingGroupSortFilterDemoWindow
    {
        public VirtualizingGroupSortFilterDemoWindow()
        {
            InitializeComponent();
        }

        protected override void OnInitialized(System.EventArgs e)
        {
            base.OnInitialized(e);

            // Set up the Data context, that is all to it. 
            // Completely MVVM pattern friendly.            

            SetDataContext();
        }

        public void SetDataContext()
        {
            DataContext = new PeopleViewModel();
        }
    }
}
