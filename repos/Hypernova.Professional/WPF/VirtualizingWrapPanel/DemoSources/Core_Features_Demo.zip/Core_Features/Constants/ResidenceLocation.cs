﻿namespace VirtualizingWrapPanelCoreDemo.Constants
{
    public enum ResidenceLocation
    {
        North = 0,
        South,
        West,
        East,
        Unknown
    }
}
