﻿using VirtualizingWrapPanelCoreDemo.ViewModels;

namespace VirtualizingWrapPanelCoreDemo
{
    /// <summary>
    /// Interaction logic for VirtualizingWrapPanelCoreDemoWindow.xaml
    /// </summary>
    public partial class VirtualizingWrapPanelCoreDemoWindow
    {
        public VirtualizingWrapPanelCoreDemoWindow()
        {
            InitializeComponent();

            // Set up the Data context, that is all to it. 
            // Completely MVVM pattern friendly.            

            SetDataContext();
        }

        public void SetDataContext()
        {
            DataContext = new PeopleViewModel();
        }
    }
}
