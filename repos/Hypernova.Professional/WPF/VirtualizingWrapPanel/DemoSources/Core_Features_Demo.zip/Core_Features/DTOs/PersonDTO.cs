﻿using System;
using System.ComponentModel;
using VirtualizingWrapPanelCoreDemo.Constants;

namespace VirtualizingWrapPanelCoreDemo.DTOs
{
    public class PersonDto : INotifyPropertyChanged
    {
        public PersonDto() { }

        public PersonDto(string firstName,
                            string lastName,
                            ResidenceLocation residenceLocation,
                            long id,
                            Uri personPlaceholderImageUri)
        {
            _firstName = firstName;
            _lastName = lastName;
            _residence = residenceLocation;
            _id = id;
            _personPlaceholderImageUri = personPlaceholderImageUri;
        }

        private long _id;

        public long Id
        {
            get { return _id; }
            set
            {
                if (_id == value) return;

                _id = value;
                RaisePropertyChanged("Id");
            }
        }

        private ResidenceLocation _residence;

        public ResidenceLocation Residence
        {
            get { return _residence; }
            set
            {
                if (_residence == value) return;

                _residence = value;
                RaisePropertyChanged("Residence");
            }
        }

        private string _firstName;

        public string FirstName
        {
            get { return _firstName; }
            set
            {
                if (_firstName == value) return;

                _firstName = value;
                RaisePropertyChanged("FirstName");
            }
        }

        private string _lastName;

        public string LastName
        {
            get { return _lastName; }
            set
            {
                if (_lastName == value) return;

                _lastName = value;
                RaisePropertyChanged("LastName");
            }
        }

        private Uri _personPlaceholderImageUri;

        public Uri PersonPlaceholderImageUri
        {
            get { return _personPlaceholderImageUri; }
            set
            {
                if (_personPlaceholderImageUri == value) return;

                _personPlaceholderImageUri = value;
                RaisePropertyChanged("_personPlaceholderImageUri");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged = delegate { };

        public void RaisePropertyChanged(string propertyName)
        {
            var handler = PropertyChanged;
            handler?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
