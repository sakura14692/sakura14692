﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Threading;
using System.Windows.Input;
using BinarymissionControlsDataExtensions = Binarymission.WPF.Data.DataExtensions;
using VirtualizingWrapPanelCoreDemo.Constants;
using VirtualizingWrapPanelCoreDemo.DTOs;
using VirtualizingWrapPanelCoreDemo.Infrastructure;

namespace VirtualizingWrapPanelCoreDemo.ViewModels
{
    // A simple view mode class that will be used as the data context for the view.
    // The People property of this class will be the one that the itemscontrol will bind to.

    class PeopleViewModel : INotifyPropertyChanged
    {
        private BinarymissionControlsDataExtensions.VirtualizingCollectionView _people;
        private RelayCommand _filterPeopleCommand;
        private readonly Random _random;

        public event PropertyChangedEventHandler PropertyChanged = delegate { };
        
        public PeopleViewModel()
        {
            _random = new Random();
           CreatePeople();
        }

        public BinarymissionControlsDataExtensions.VirtualizingCollectionView People
        {
            get { return _people; }
            private set
            {
                _people = value;
                PropertyChanged(this, new PropertyChangedEventArgs("People"));
            }
        }

        public PersonDto SelectedPerson { get; set; }

        public ICommand FilterPeopleCommand
        {
            get {
                return _filterPeopleCommand ??
                       (_filterPeopleCommand =
                           new RelayCommand(param => FilterPeople(param as string),
                               param => CanFilterPeople(param as string)));
            }
        }

        private void CreatePeople()
        {
            var listOfPerson = new ObservableCollection<PersonDto>();

            for (var i = 0; i <= 100000; i++)
            {
                // Applying a simple criteria to set some person objects to be residing in south and others as unknown - just to see the effect on grouping feature.
                                
                var imageIndex = _random.Next(1, 23);
                var imageUri = new Uri("pack://application:,,,/VirtualizingWrapPanelCoreDemo;Component/Images/" +
                                       $"{imageIndex}.png");
                
                var person = new PersonDto("First" + i,
                    "Last" + i,
                    (i % 10 == 3) ? ResidenceLocation.South : ResidenceLocation.North,
                    i,
                    imageUri);
                    
                listOfPerson.Add(person);
            }

            // This is the important thing to do.
            // Create an instance of the VirtualizingCollectionView class and supply the actual data source to it, so it can perform virtualization on it.
            var virtualizedView = new BinarymissionControlsDataExtensions.VirtualizingCollectionView(listOfPerson);
            People = virtualizedView;
        }
       
        private bool CanFilterPeople(string filterTextLastname)
        {
            return true;
        }

        private void FilterPeople(string filterTextLastname)
        {
            if (filterTextLastname == null) return;

            if (People == null) return;
            if (!People.CanFilter) return;

            CreatePeople();
            People.Filter = (param) =>
            {
                var personDto = param as PersonDto;
                return personDto != null && personDto.LastName.StartsWith(filterTextLastname, true,
                    Thread.CurrentThread.CurrentCulture);
            };
        }
    }
}
