﻿using System;
using System.Windows.Controls;
using System.Windows.Data;

namespace VirtualizingWrapPanelCoreDemo.Infrastructure
{
    public class ComboBoxOrientationValueConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            var item = value as ComboBoxItem;

            if(item != null)
                return item.Content.ToString() == "Horizontal" ? Orientation.Horizontal : Orientation.Vertical;

            return null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}