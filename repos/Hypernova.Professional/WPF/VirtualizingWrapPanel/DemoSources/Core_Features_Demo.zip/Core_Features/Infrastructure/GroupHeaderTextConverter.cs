﻿using System;
using System.Windows.Data;

namespace VirtualizingWrapPanelCoreDemo.Infrastructure
{
    // A simple converter that will help us add more data/text to the group header section -->

    class GroupHeaderTextConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value == null) return null;

            var data = value.ToString();
            data = "--- Group data: People grouped on Residence property value being:  " + data + " ---";
            return data;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
