﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using Binarymission.WPF.Controls.ExtendedContainerControls;

namespace BinarySmartInfoPanelDemo
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class SmartInfoPanelDemoWindow
    {
        public SmartInfoPanelDemoWindow()
        {
            InitializeComponent();
            FlipTypes = new ObservableCollection<string>(Enum.GetNames(typeof(SmartInfoPanel.FlipType)));
            DataContext = this;
        }

        public static readonly DependencyProperty FlipTypesProperty = DependencyProperty.Register(
            "FlipTypes", typeof (ObservableCollection<string>), typeof (SmartInfoPanelDemoWindow), new PropertyMetadata(default(ObservableCollection<string>)));

        public ObservableCollection<string> FlipTypes
        {
            get { return (ObservableCollection<string>) GetValue(FlipTypesProperty); }
            set { SetValue(FlipTypesProperty, value); }
        }

        private void ExitApplicationInvoked(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
