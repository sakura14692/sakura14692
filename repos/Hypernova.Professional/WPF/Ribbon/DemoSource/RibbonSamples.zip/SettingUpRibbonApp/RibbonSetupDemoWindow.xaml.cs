﻿using System.Windows;
using Binarymission.WPF.Controls.WindowControls;

namespace SettingUpRibbonApp
{
    /// <summary>
    /// Interaction logic for RibbonSetupDemoWindow.xaml
    /// </summary>
    public partial class RibbonSetupDemoWindow
    {
        public RibbonSetupDemoWindow()
        {
            InitializeComponent();
            BinaryRibbonBuiltInSkinController.Skin = Binarymission.WPF.Controls.WindowControls.Enums.RibbonSkin.OfficeSilver;
        }

        private void BinaryRibbonMenuItem_Blue_Click(object sender, RoutedEventArgs e)
        {
            BinaryRibbonBuiltInSkinController.Skin = Binarymission.WPF.Controls.WindowControls.Enums.RibbonSkin.OfficeBlue;
        }

        private void BinaryRibbonMenuItem_Silver_Click(object sender, RoutedEventArgs e)
        {
            BinaryRibbonBuiltInSkinController.Skin = Binarymission.WPF.Controls.WindowControls.Enums.RibbonSkin.OfficeSilver;
        }

        private void BinaryRibbonMenuItem_Windows_7_Click(object sender, RoutedEventArgs e)
        {
            BinaryRibbonBuiltInSkinController.Skin = Binarymission.WPF.Controls.WindowControls.Enums.RibbonSkin.Windows7;
        }

        private void BinaryRibbonGroup_ExecuteModalDialogLauncher(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Sample Modal dialog invocation from Ribbon bar panel.", "Sample Modal dialog window.");
        }

        private void ToggleGlassRenderingState(object sender, RoutedEventArgs e)
        {
            var binaryRibbonToggleButtonControl = sender as BinaryRibbonToggleButtonControl;
            if (binaryRibbonToggleButtonControl?.IsChecked != null)
                _mainWindow.RenderGlassIfOSSupports = binaryRibbonToggleButtonControl.IsChecked.Value;
        }

        private void ContextTabChangedToWip(object sender, RoutedEventArgs e)
        {
            var controlToExecute = sender as BinaryRibbonToggleButtonControl; ;
            _ribbonPanel.ContextualTabSet = controlToExecute?.IsChecked != null && (controlToExecute.IsChecked.Value) ? _contextTabBackup : null;
        }
    }
}
