﻿using Binarymission.WPF.Controls.WindowControls;

namespace RibbonWindowSample
{
    /// <summary>
    /// Simply setting the main window as of the BinaryRibbonWindow type class  gets us the Office style application window
    /// </summary>
    public partial class OfficeStyleWindowSetupDemoWindow
    {
        public OfficeStyleWindowSetupDemoWindow()
        {
            InitializeComponent();

            BinaryRibbonBuiltInSkinController.Skin = Binarymission.WPF.Controls.WindowControls.Enums.RibbonSkin.OfficeBlack;
        }
    }
}
