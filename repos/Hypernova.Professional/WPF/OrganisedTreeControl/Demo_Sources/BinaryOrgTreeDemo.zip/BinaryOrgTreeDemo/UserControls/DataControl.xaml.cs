﻿namespace BinaryOrgTreeDemo.UserControls
{
    public partial class DataControl
    {
        public DataControl()
        {
            InitializeComponent();
        }
    }
}
