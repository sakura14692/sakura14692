﻿using System.IO;
using System.Windows;
using System.Windows.Media.Imaging;
using Binarymission.WPF.Controls.TreeControls;

namespace BinaryOrgTreeDemo.Windows
{
    /// <summary>
    /// Interaction logic for CustomExportConfigurationDialog.xaml
    /// </summary>
    public partial class CustomExportConfigurationDialog
    {
        private readonly OrganizedTree _chartTree;

        public CustomExportConfigurationDialog()
        {
            InitializeComponent();
        }

        public CustomExportConfigurationDialog(OrganizedTree chartTree)
        {
            InitializeComponent();
            _chartTree = chartTree;
        }

        private void OnExportClick(object sender, RoutedEventArgs e)
        {
            // Here you can do whatever you want, using the orgChart nodes collection or other properties and using them to produce whatever you want to do.
            // In this sample, I am just going to call the Export() method, which will give me a BitmapSource of image stream of the chart that is so far presented, and I will 
            // save that to the disk as a JPEG file.
            var renderTargetBitmap = _chartTree.Export();

            const string destinationExportFileName = @"Binarymission_Chart_Image.jpg";

            using (var outStream = new FileStream(destinationExportFileName, FileMode.Create))
            {
                var encoder = new JpegBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(renderTargetBitmap));
                encoder.Save(outStream);
            }

            MessageBox.Show(
                $"Successfully saved the tree control's data as a JPEG image in: {destinationExportFileName}",
                "Export successful",
                MessageBoxButton.OK,
                MessageBoxImage.Information);

            Close();
        }
    }
}
