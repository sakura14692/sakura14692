﻿using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using Binarymission.WPF.Controls.TreeControls;
using BinaryOrgTreeDemo.UserControls;
using BinaryOrgTreeDemo.Windows;

namespace BinaryOrgTreeDemo
{
    /// <summary>
    /// Interaction logic for TreeWindow.xaml
    /// </summary>
    public partial class TreeWindow
    {
        public TreeWindow()
        {
            InitializeComponent();
            RenderTree();
        }

        private void RenderTree()
        {
            // Clear any nodes, if the organized tree control already has some.
            if (OrgGridTree.Nodes != null && OrgGridTree.Nodes.Count > 0)
                OrgGridTree.Nodes.Clear();

            // I have set up a custom default node visual size, based on my custom data template visual I have created,.
            // Your data template size may vary form this, of course.
            var defaultNodeSize = new Size(260, 76);

            // Now, lets create some nodes, that we will then add to the organized tree control.
            var directorNode = CreateNode("Mike Joseph",
                                            "Director",
                                            "2",
                                            defaultNodeSize,
                                            Application.Current.Resources["backgroundBrush"] as Brush);
            var presidentTechnicalNode = CreateNode("Josh M",
                                                    "President - Technical",
                                                    "1",
                                                    defaultNodeSize,
                                                    Application.Current.Resources["backgroundBrush2"] as Brush);
            var presidentOpsNode = CreateNode("MacDonald M",
                                                "President - Corporate",
                                                "3",
                                                defaultNodeSize,
                                                Application.Current.Resources["backgroundBrush3"] as Brush);

            directorNode.Children.Add(presidentTechnicalNode);
            directorNode.Children.Add(presidentOpsNode);

            var vpOpsNode = CreateNode("Richard P",
                                        "VP - Operations ",
                                        "0",
                                        defaultNodeSize,
                                        Application.Current.Resources["backgroundBrush4"] as Brush);
            var vpSalesMarketingNode = CreateNode("Robert P",
                                                    "VP - Sales",
                                                    "0",
                                                    defaultNodeSize,
                                                    Application.Current.Resources["backgroundBrush5"] as Brush);
            var vpPrAndMediaNode = CreateNode("Fiona B",
                                                "VP - PR, Media",
                                                "0",
                                                defaultNodeSize,
                                                Application.Current.Resources["backgroundBrush6"] as Brush);
            var solArchitectNode = CreateNode("Steve P",
                                                "Solution Architect",
                                                "2",
                                                defaultNodeSize,
                                                Application.Current.Resources["backgroundBrush7"] as Brush);
            var tdaNode = CreateNode("Jacobson J",
                                      "Design Authority",
                                      "0",
                                      defaultNodeSize,
                                      Application.Current.Resources["backgroundBrush8"] as Brush);
            var techArchitectNode = CreateNode("Mike J",
                                                "Technical Architect",
                                                "0",
                                                defaultNodeSize,
                                                Application.Current.Resources["backgroundBrush9"] as Brush);

            presidentTechnicalNode.Children.Add(solArchitectNode);
            solArchitectNode.Children.AddRange(new[]
            {
                tdaNode, techArchitectNode
            });

            presidentOpsNode.Children.Add(vpOpsNode);
            presidentOpsNode.Children.Add(vpSalesMarketingNode);
            presidentOpsNode.Children.Add(vpPrAndMediaNode);

            OrgGridTree.Nodes?.Add(directorNode);

            // Call the RenderTree() method on the control to let it display the nodes as tree.
            OrgGridTree.RenderTree();
        }

        // This is a simple helper method that creates each desired node object, by setting up an instance of a custom "data template" I have created (as an example) 
        // for rendering the node's visual.
        // You can reference the custom data template type and its visual by reading through the other files named "DataControl.xaml" and "DataControl.xaml.cs".
        // Of course, you can create your own, that reflects your business requirements for the node's visual.
        private OrganizedTreeNode CreateNode(string name,
            string position,
            string reportingSubordinates,
            Size nodeSize,
            Brush nodeBackgroundBrush = null)
        {
            if (nodeBackgroundBrush == null) nodeBackgroundBrush = new SolidColorBrush(Colors.Orange);

            var dataControlInstance = new DataControl
            {
                Width = nodeSize.Width,
                Height = nodeSize.Height,
                Cursor = Cursors.Hand,
                PersonName = { Text = name },
                PersonPosition = { Text = position },
                NumberOfReports = { Text = "Number of reports: " + reportingSubordinates },
                LayoutRoot = { Background = nodeBackgroundBrush }
            };

            // Lets attach a method from where we will run a custom dialog to use the "Export" feature of the control.
            dataControlInstance.ImagePrint.PreviewMouseUp += ProcessTreeControlForExportFromCustomDialog;
            return new OrganizedTreeNode(dataControlInstance, nodeSize);
        }

        // Clicking on the printer image within my custom data template for node, will invoke a custom dialog from where i will do whatever i want to do with the control's data,
        // say for example, asking the control to "Export" the content as jpeg image.
        void ProcessTreeControlForExportFromCustomDialog(object sender, MouseButtonEventArgs e)
        {
            // I am running a custom dialog from where i will call the control's Export() method.
            var dialog = new CustomExportConfigurationDialog(OrgGridTree);
            dialog.ShowDialog();
        }

        // Clicking the Print button on my window will call on the control's Print() method that will prepare the content into a stream, 
        // and send it automatically to a printer that will be chosen by the user at runtime.
        // Note that Print method and Export methods are two different features.
        private void HandlePrintTreeRequest(object sender, RoutedEventArgs e)
        {
            OrgGridTree.Print();
        }
    }
}
