namespace BinaryPowerTabStripDemo
{
    partial class BinaryPowerTabStripDemoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Drawing.StringFormat stringFormat1 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat2 = new System.Drawing.StringFormat();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BinaryPowerTabStripDemoForm));
            System.Drawing.StringFormat stringFormat3 = new System.Drawing.StringFormat();
            this.binaryPowerTabStrip1 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabStrip();
            this.binaryPowerTabPage1 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.chkShoudlAutoSizeTabHeaders1 = new System.Windows.Forms.CheckBox();
            this.overflowModeCmbBx1 = new System.Windows.Forms.ComboBox();
            this.label90 = new System.Windows.Forms.Label();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.tabPageRenderingLocationCmbBxTab1 = new System.Windows.Forms.ComboBox();
            this.label79 = new System.Windows.Forms.Label();
            this.cmbTabPageRenderingStyleTab1 = new System.Windows.Forms.ComboBox();
            this.label80 = new System.Windows.Forms.Label();
            this.binaryColorPickerComboBox40 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBox41 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBox42 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBox43 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBox44 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBox45 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBox46 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.chkDrawGapBetweenTabPagesTabPage1 = new System.Windows.Forms.CheckBox();
            this.label84 = new System.Windows.Forms.Label();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.label85 = new System.Windows.Forms.Label();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.label86 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.label88 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.tabPageRenderingLocationCmbBx = new System.Windows.Forms.ComboBox();
            this.label77 = new System.Windows.Forms.Label();
            this.cmbTabPageRenderingStyle = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.binaryColorPickerComboBoxTabPageHeaderForecolor = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBoxMenuButtonFillColor = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBoxMenuButtonBorderColor = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBoxMenuButtonColor = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBoxCloseButtonFillColor = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBox1CloseButtonBorderColor = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBox1CloseButtonColor = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.chkDrawGapBetweenTabPages = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.chkDrawTabPageOnTopofEachother = new System.Windows.Forms.CheckBox();
            this.chkEnableDragDrop1 = new System.Windows.Forms.CheckBox();
            this.label10 = new System.Windows.Forms.Label();
            this.chkShowCloseButton = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.chkShowMenuDropDownButton = new System.Windows.Forms.CheckBox();
            this.chkDrawBorderAroundTabStrip = new System.Windows.Forms.CheckBox();
            this.numericUpDownEmptySpaceLengthBeforeFirstTagPageHeader = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.binaryPowerTabStripUsingBuiltinStyle = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabStrip();
            this.binaryPowerTabPage_Welcome = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.binaryColorPickerComboBox6 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label58 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.binaryColorPickerComboBox2 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.binaryColorPickerComboBox1 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.binaryPowerTabPage_UserManagement = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.binaryColorPickerComboBox7 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label60 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.binaryColorPickerComboBox3 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.binaryColorPickerComboBox4 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.binaryPowerTabPage_CustomerMeetings = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.binaryColorPickerComboBox5 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label57 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.binaryColorPickerComboBox15 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.binaryColorPickerComboBox16 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryPowerTabPage_DatabaseReplication = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.binaryColorPickerComboBox8 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label59 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.binaryColorPickerComboBox13 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.binaryColorPickerComboBox14 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryPowerTabPage_EmailArchives = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.binaryColorPickerComboBox9 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label61 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.binaryColorPickerComboBox17 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBox18 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.binaryPowerTabPage2 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label40 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.chkShouldAutoSizeTabHeaders2 = new System.Windows.Forms.CheckBox();
            this.label92 = new System.Windows.Forms.Label();
            this.overflowModeCmbBx2 = new System.Windows.Forms.ComboBox();
            this.customTabPagesRenderignLocationCmbBx = new System.Windows.Forms.ComboBox();
            this.label78 = new System.Windows.Forms.Label();
            this.cmbCustomTabPageRenderingStyle = new System.Windows.Forms.ComboBox();
            this.label76 = new System.Windows.Forms.Label();
            this.binaryColorPickerComboBoxSideBarFillColor = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBoxTabPageHeaderForecolor2 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBoxMenuButtonFillColor2 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBoxMenuButtonBorderColor2 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBoxMenuButtonColor2 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBoxCloseButtonFillColor2 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBoxCloseButtonBorderColor2 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBoxCloseButtonColor2 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBoxTabPageBorderColor2 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.chkDrawGapBetweenTabPages2 = new System.Windows.Forms.CheckBox();
            this.label24 = new System.Windows.Forms.Label();
            this.chkDrawTabPageOnTopofEachOther2 = new System.Windows.Forms.CheckBox();
            this.chkEnableDragDrop2 = new System.Windows.Forms.CheckBox();
            this.chkShowSideBarOnTabPageHeader = new System.Windows.Forms.CheckBox();
            this.label25 = new System.Windows.Forms.Label();
            this.chkShowCloseButton2 = new System.Windows.Forms.CheckBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.chkShowMenuDropdownButton2 = new System.Windows.Forms.CheckBox();
            this.chkDrawBorderAroundTabStrip2 = new System.Windows.Forms.CheckBox();
            this.cmbGradientOrientationOnTabPageHeader = new System.Windows.Forms.ComboBox();
            this.numericUpDownEmptySpaceLengthBeforeFirstTabPageHeader2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownGapLengthBetweenTabPageHeader = new System.Windows.Forms.NumericUpDown();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.binaryPowerTabStripUsingCustomStyle = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabStrip();
            this.binaryPowerTabPage_Custom_Welcome = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.binaryColorPickerComboBox12 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.binaryColorPickerComboBoxTabPageHeaderEndColor = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label56 = new System.Windows.Forms.Label();
            this.binaryColorPickerComboBox19 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBoxTabPageHeaderstartcolor = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBox20 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.binaryPowerTabPage_Custom_UserManagement = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.panel6 = new System.Windows.Forms.Panel();
            this.binaryColorPickerComboBox30 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBox10 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label66 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.binaryColorPickerComboBox21 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBox11 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBox22 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label63 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.binaryPowerTabPage_Custom_DatabaseReplication = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.panel7 = new System.Windows.Forms.Panel();
            this.binaryColorPickerComboBox34 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label55 = new System.Windows.Forms.Label();
            this.binaryColorPickerComboBox35 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBox25 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label70 = new System.Windows.Forms.Label();
            this.binaryColorPickerComboBox26 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label71 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.binaryColorPickerComboBox36 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label72 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.binaryPowerTabPage_Custom_CustomerMeetings = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label54 = new System.Windows.Forms.Label();
            this.binaryColorPickerComboBox32 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBox27 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBox28 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label68 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.binaryColorPickerComboBox33 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label69 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.binaryColorPickerComboBox31 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryPowerTabPage_Custom_EmailArchives = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.panel8 = new System.Windows.Forms.Panel();
            this.binaryColorPickerComboBox37 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label53 = new System.Windows.Forms.Label();
            this.binaryColorPickerComboBox38 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.binaryColorPickerComboBox23 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label73 = new System.Windows.Forms.Label();
            this.binaryColorPickerComboBox24 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label74 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.binaryColorPickerComboBox39 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label75 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.binaryColorPickerComboBox29 = new Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox();
            this.label65 = new System.Windows.Forms.Label();
            this.binaryPowerTabStrip1.SuspendLayout();
            this.binaryPowerTabPage1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownEmptySpaceLengthBeforeFirstTagPageHeader)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            this.binaryPowerTabStripUsingBuiltinStyle.SuspendLayout();
            this.binaryPowerTabPage_Welcome.SuspendLayout();
            this.binaryPowerTabPage_UserManagement.SuspendLayout();
            this.binaryPowerTabPage_CustomerMeetings.SuspendLayout();
            this.binaryPowerTabPage_DatabaseReplication.SuspendLayout();
            this.binaryPowerTabPage_EmailArchives.SuspendLayout();
            this.binaryPowerTabPage2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownEmptySpaceLengthBeforeFirstTabPageHeader2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownGapLengthBetweenTabPageHeader)).BeginInit();
            this.binaryPowerTabStripUsingCustomStyle.SuspendLayout();
            this.binaryPowerTabPage_Custom_Welcome.SuspendLayout();
            this.panel3.SuspendLayout();
            this.binaryPowerTabPage_Custom_UserManagement.SuspendLayout();
            this.panel6.SuspendLayout();
            this.binaryPowerTabPage_Custom_DatabaseReplication.SuspendLayout();
            this.panel7.SuspendLayout();
            this.binaryPowerTabPage_Custom_CustomerMeetings.SuspendLayout();
            this.panel9.SuspendLayout();
            this.binaryPowerTabPage_Custom_EmailArchives.SuspendLayout();
            this.panel8.SuspendLayout();
            this.SuspendLayout();
            // 
            // binaryPowerTabStrip1
            // 
            this.binaryPowerTabStrip1.Cursor = System.Windows.Forms.Cursors.Default;
            this.binaryPowerTabStrip1.CustomEndColor = System.Drawing.Color.White;
            this.binaryPowerTabStrip1.CustomStartColor = System.Drawing.Color.Green;
            this.binaryPowerTabStrip1.DrawBorderAroundTabStrip = false;
            this.binaryPowerTabStrip1.DrawTabPageOnTopOfEachOther = false;
            this.binaryPowerTabStrip1.EmptySpaceLengthBeforeTheFirstTabPage = 0;
            this.binaryPowerTabStrip1.EnableAutomaticUpdateOfTabPagesHeaderSize = false;
            this.binaryPowerTabStrip1.EnableControlledLayoutRendering = false;
            this.binaryPowerTabStrip1.EnableDragAndDropOfTabPages = false;
            this.binaryPowerTabStrip1.EnableTabPageLevelCloseButtonRendering = true;
            this.binaryPowerTabStrip1.ExtendedWindowsXPRenderingFirstColor = System.Drawing.Color.Blue;
            this.binaryPowerTabStrip1.ExtendedWindowsXPRenderingSecondColor = System.Drawing.Color.LightBlue;
            this.binaryPowerTabStrip1.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.binaryPowerTabStrip1.HeaderFont = null;
            this.binaryPowerTabStrip1.HeaderTextCloseButtonExtraGap = 8;
            this.binaryPowerTabStrip1.IsBackgroundTransparent = false;
            this.binaryPowerTabStrip1.KeepShowingTooltipEvenWhenMousePointerIsMoving = false;
            this.binaryPowerTabStrip1.Location = new System.Drawing.Point(12, 12);
            this.binaryPowerTabStrip1.Name = "binaryPowerTabStrip1";
            this.binaryPowerTabStrip1.NewlyAddedPagesAreLocatedAtLeftCorner = false;
            this.binaryPowerTabStrip1.PreventInvalidation = false;
            this.binaryPowerTabStrip1.RenderFullTextForTabPageHeader = false;
            this.binaryPowerTabStrip1.SelectedPageHeaderTextIsRenderedBold = true;
            this.binaryPowerTabStrip1.ShouldAutoSizeTabs = false;
            this.binaryPowerTabStrip1.ShowToolTip = true;
            this.binaryPowerTabStrip1.Size = new System.Drawing.Size(768, 587);
            this.binaryPowerTabStrip1.TabBottomOrientationCloseButtonPosition = Binarymission.WinForms.Controls.TabControls.CloseButtonPosition.Bottom;
            stringFormat1.Alignment = System.Drawing.StringAlignment.Center;
            stringFormat1.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat1.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat1.Trimming = System.Drawing.StringTrimming.EllipsisCharacter;
            this.binaryPowerTabStrip1.TabHeaderStringFormat = stringFormat1;
            this.binaryPowerTabStrip1.TabIndex = 0;
            this.binaryPowerTabStrip1.TabPageBorderColor = System.Drawing.SystemColors.ControlDark;
            this.binaryPowerTabStrip1.TabPageCloseButtonMouseEnterColor = System.Drawing.Color.Red;
            this.binaryPowerTabStrip1.TabPageCloseButtonRectangleBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryPowerTabStrip1.TabPageCloseButtonRectangleFillColor = System.Drawing.SystemColors.Highlight;
            this.binaryPowerTabStrip1.TabPageCurrentSelectionIndicatorEndColor = System.Drawing.Color.White;
            this.binaryPowerTabStrip1.TabPageCurrentSelectionIndicatorStartColor = System.Drawing.Color.Orange;
            this.binaryPowerTabStrip1.TabPageHeaderDrawingGradientOrientation = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.binaryPowerTabStrip1.TabPageHeaderForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabStrip1.TabPageHeaderHeight = 24;
            this.binaryPowerTabStrip1.TabPageHeaderShowsSideBar = false;
            this.binaryPowerTabStrip1.TabPageHeaderTextFontOverridesControlDefault = false;
            this.binaryPowerTabStrip1.TabPageHeaderWidth = 200;
            this.binaryPowerTabStrip1.TabPages.AddRange(new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage[] {
            this.binaryPowerTabPage1,
            this.binaryPowerTabPage2});
            this.binaryPowerTabStrip1.TabPagesCloseButtonColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabStrip1.TabPagesHaveGapBetweenThem = false;
            this.binaryPowerTabStrip1.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabStrip1.TabPagesOverFlowMenuDropDownColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabStrip1.TabPagesOverFlowMenuGlyphActiveRectangleBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryPowerTabStrip1.TabPagesOverFlowMenuGlyphActiveRectangleFillColor = System.Drawing.SystemColors.Highlight;
            this.binaryPowerTabStrip1.TabPagesRenderingLocation = Binarymission.WinForms.Controls.TabControls.TabPagesRenderingLocation.Top;
            this.binaryPowerTabStrip1.TabRenderingStyle = Binarymission.WinForms.Controls.TabControls.RenderingStyle.VisualStudio2008;
            this.binaryPowerTabStrip1.TabsOverflowMode = Binarymission.WinForms.Controls.TabControls.OverflowMode.MultiLine;
            this.binaryPowerTabStrip1.Text = "binaryPowerTabStrip1";
            this.binaryPowerTabStrip1.ThemeBorderColorCanBeOverridden = false;
            this.binaryPowerTabStrip1.ToolTipConfiguration.AutomaticDelay = 500;
            this.binaryPowerTabStrip1.ToolTipConfiguration.AutoPopDelay = 5000;
            this.binaryPowerTabStrip1.ToolTipConfiguration.BackColor = System.Drawing.SystemColors.Info;
            this.binaryPowerTabStrip1.ToolTipConfiguration.ForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabStrip1.ToolTipConfiguration.InitialDelay = 500;
            this.binaryPowerTabStrip1.ToolTipConfiguration.IsBalloon = false;
            this.binaryPowerTabStrip1.ToolTipConfiguration.ReshowDelay = 100;
            this.binaryPowerTabStrip1.ToolTipConfiguration.StripAmpersands = false;
            this.binaryPowerTabStrip1.ToolTipConfiguration.ToolTipIcon = System.Windows.Forms.ToolTipIcon.None;
            this.binaryPowerTabStrip1.ToolTipConfiguration.ToolTipTitle = "";
            this.binaryPowerTabStrip1.ToolTipConfiguration.UseAnimation = false;
            this.binaryPowerTabStrip1.ToolTipConfiguration.UseFading = false;
            this.binaryPowerTabStrip1.UseTabCurrentSelectionIndicatorColor = true;
            // 
            // binaryPowerTabPage1
            // 
            this.binaryPowerTabPage1.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(181)))), ((int)(((byte)(226)))));
            this.binaryPowerTabPage1.BorderSize = 1;
            this.binaryPowerTabPage1.Controls.Add(this.panel1);
            this.binaryPowerTabPage1.CurrentlySelected = true;
            this.binaryPowerTabPage1.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage1.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage1.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage1.IsBackgroundTransparent = false;
            this.binaryPowerTabPage1.IsHeaderEnabled = true;
            this.binaryPowerTabPage1.Name = "binaryPowerTabPage1";
            this.binaryPowerTabPage1.Size = new System.Drawing.Size(766, 562);
            this.binaryPowerTabPage1.TabIndex = 0;
            this.binaryPowerTabPage1.TabPageContentIsDirty = false;
            this.binaryPowerTabPage1.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage1.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage1.Text = "Built-in styles";
            this.binaryPowerTabPage1.ToolTipText = "";
            // 
            // panel1
            // 
            this.panel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.panel10);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.binaryPowerTabStripUsingBuiltinStyle);
            this.panel1.Location = new System.Drawing.Point(4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(757, 552);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label1.Location = new System.Drawing.Point(28, 193);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(163, 14);
            this.label1.TabIndex = 38;
            this.label1.Text = "  Customisation Options  ";
            // 
            // panel10
            // 
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.chkShoudlAutoSizeTabHeaders1);
            this.panel10.Controls.Add(this.overflowModeCmbBx1);
            this.panel10.Controls.Add(this.label90);
            this.panel10.Controls.Add(this.checkBox2);
            this.panel10.Controls.Add(this.tabPageRenderingLocationCmbBxTab1);
            this.panel10.Controls.Add(this.label79);
            this.panel10.Controls.Add(this.cmbTabPageRenderingStyleTab1);
            this.panel10.Controls.Add(this.label80);
            this.panel10.Controls.Add(this.binaryColorPickerComboBox40);
            this.panel10.Controls.Add(this.binaryColorPickerComboBox41);
            this.panel10.Controls.Add(this.binaryColorPickerComboBox42);
            this.panel10.Controls.Add(this.binaryColorPickerComboBox43);
            this.panel10.Controls.Add(this.binaryColorPickerComboBox44);
            this.panel10.Controls.Add(this.binaryColorPickerComboBox45);
            this.panel10.Controls.Add(this.binaryColorPickerComboBox46);
            this.panel10.Controls.Add(this.label81);
            this.panel10.Controls.Add(this.label82);
            this.panel10.Controls.Add(this.label83);
            this.panel10.Controls.Add(this.chkDrawGapBetweenTabPagesTabPage1);
            this.panel10.Controls.Add(this.label84);
            this.panel10.Controls.Add(this.checkBox4);
            this.panel10.Controls.Add(this.checkBox5);
            this.panel10.Controls.Add(this.label85);
            this.panel10.Controls.Add(this.checkBox6);
            this.panel10.Controls.Add(this.label86);
            this.panel10.Controls.Add(this.label87);
            this.panel10.Controls.Add(this.checkBox7);
            this.panel10.Controls.Add(this.checkBox8);
            this.panel10.Controls.Add(this.numericUpDown1);
            this.panel10.Controls.Add(this.numericUpDown3);
            this.panel10.Controls.Add(this.label88);
            this.panel10.Controls.Add(this.label89);
            this.panel10.Location = new System.Drawing.Point(18, 200);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(722, 341);
            this.panel10.TabIndex = 27;
            // 
            // chkShoudlAutoSizeTabHeaders1
            // 
            this.chkShoudlAutoSizeTabHeaders1.AutoSize = true;
            this.chkShoudlAutoSizeTabHeaders1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkShoudlAutoSizeTabHeaders1.ForeColor = System.Drawing.SystemColors.WindowText;
            this.chkShoudlAutoSizeTabHeaders1.Location = new System.Drawing.Point(15, 65);
            this.chkShoudlAutoSizeTabHeaders1.Name = "chkShoudlAutoSizeTabHeaders1";
            this.chkShoudlAutoSizeTabHeaders1.Size = new System.Drawing.Size(166, 17);
            this.chkShoudlAutoSizeTabHeaders1.TabIndex = 43;
            this.chkShoudlAutoSizeTabHeaders1.Text = "Should auto-size tab headers";
            this.chkShoudlAutoSizeTabHeaders1.UseVisualStyleBackColor = true;
            this.chkShoudlAutoSizeTabHeaders1.CheckedChanged += new System.EventHandler(this.HandleBuiltinStyledTabControlShouldAutoSizeTabsChanged);
            // 
            // overflowModeCmbBx1
            // 
            this.overflowModeCmbBx1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.overflowModeCmbBx1.FormattingEnabled = true;
            this.overflowModeCmbBx1.Items.AddRange(new object[] {
            "Menu",
            "MultiLine"});
            this.overflowModeCmbBx1.Location = new System.Drawing.Point(574, 145);
            this.overflowModeCmbBx1.Name = "overflowModeCmbBx1";
            this.overflowModeCmbBx1.Size = new System.Drawing.Size(130, 21);
            this.overflowModeCmbBx1.TabIndex = 42;
            this.overflowModeCmbBx1.SelectedIndexChanged += new System.EventHandler(this.HandleBuiltinStyledTabControlTabsOverflowChanged);
            // 
            // label90
            // 
            this.label90.AutoSize = true;
            this.label90.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label90.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label90.Location = new System.Drawing.Point(369, 147);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(125, 13);
            this.label90.TabIndex = 41;
            this.label90.Text = "Tab pags overflow mode";
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Checked = true;
            this.checkBox2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.checkBox2.Location = new System.Drawing.Point(372, 25);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(286, 17);
            this.checkBox2.TabIndex = 40;
            this.checkBox2.Text = "Enable drawing \"Close button\" in the Tab page header";
            this.checkBox2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.HandleEnableTabPageLevelCloseButtonRenderingChanged);
            // 
            // tabPageRenderingLocationCmbBxTab1
            // 
            this.tabPageRenderingLocationCmbBxTab1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.tabPageRenderingLocationCmbBxTab1.FormattingEnabled = true;
            this.tabPageRenderingLocationCmbBxTab1.Items.AddRange(new object[] {
            "Top",
            "Bottom"});
            this.tabPageRenderingLocationCmbBxTab1.Location = new System.Drawing.Point(574, 119);
            this.tabPageRenderingLocationCmbBxTab1.Name = "tabPageRenderingLocationCmbBxTab1";
            this.tabPageRenderingLocationCmbBxTab1.Size = new System.Drawing.Size(130, 21);
            this.tabPageRenderingLocationCmbBxTab1.TabIndex = 39;
            this.tabPageRenderingLocationCmbBxTab1.SelectedIndexChanged += new System.EventHandler(this.HandleTabPageRenderingLocationOptionChanged);
            // 
            // label79
            // 
            this.label79.AutoSize = true;
            this.label79.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label79.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label79.Location = new System.Drawing.Point(369, 122);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(146, 13);
            this.label79.TabIndex = 38;
            this.label79.Text = "Tab pages rendering location";
            // 
            // cmbTabPageRenderingStyleTab1
            // 
            this.cmbTabPageRenderingStyleTab1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTabPageRenderingStyleTab1.FormattingEnabled = true;
            this.cmbTabPageRenderingStyleTab1.Items.AddRange(new object[] {
            "ExtendedWindowsXP",
            "WindowsXP",
            "VisualStudio2005",
            "VisualStudio2008",
            "TrapeziumTop",
            "Custom"});
            this.cmbTabPageRenderingStyleTab1.Location = new System.Drawing.Point(574, 93);
            this.cmbTabPageRenderingStyleTab1.Name = "cmbTabPageRenderingStyleTab1";
            this.cmbTabPageRenderingStyleTab1.Size = new System.Drawing.Size(130, 21);
            this.cmbTabPageRenderingStyleTab1.TabIndex = 37;
            this.cmbTabPageRenderingStyleTab1.SelectedIndexChanged += new System.EventHandler(this.HandleBuiltinStyledTabPageRenderingStyleTab1SelectedIndexChanged);
            // 
            // label80
            // 
            this.label80.AutoSize = true;
            this.label80.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label80.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label80.Location = new System.Drawing.Point(369, 97);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(127, 13);
            this.label80.TabIndex = 36;
            this.label80.Text = "Tab page rendering style";
            // 
            // binaryColorPickerComboBox40
            // 
            this.binaryColorPickerComboBox40.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox40.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox40.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox40.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox40.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox40.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox40.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox40.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox40.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox40.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox40.FormattingEnabled = true;
            this.binaryColorPickerComboBox40.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBox40.Location = new System.Drawing.Point(575, 172);
            this.binaryColorPickerComboBox40.Name = "binaryColorPickerComboBox40";
            this.binaryColorPickerComboBox40.SelectedColor = System.Drawing.Color.Black;
            this.binaryColorPickerComboBox40.ShowBorderAlways = true;
            this.binaryColorPickerComboBox40.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox40.Size = new System.Drawing.Size(129, 22);
            this.binaryColorPickerComboBox40.TabIndex = 35;
            this.binaryColorPickerComboBox40.SelectedColorChanged += new System.EventHandler(this.HandleBuiltinStyleTabPageHeaderForeColorChanged);
            // 
            // binaryColorPickerComboBox41
            // 
            this.binaryColorPickerComboBox41.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox41.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox41.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox41.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox41.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox41.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox41.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox41.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox41.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox41.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox41.FormattingEnabled = true;
            this.binaryColorPickerComboBox41.Items.AddRange(new object[] {
            "210, 222, 242"});
            this.binaryColorPickerComboBox41.Location = new System.Drawing.Point(557, 301);
            this.binaryColorPickerComboBox41.Name = "binaryColorPickerComboBox41";
            this.binaryColorPickerComboBox41.SelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(222)))), ((int)(((byte)(242)))));
            this.binaryColorPickerComboBox41.ShowBorderAlways = true;
            this.binaryColorPickerComboBox41.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox41.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox41.TabIndex = 34;
            this.binaryColorPickerComboBox41.SelectedColorChanged += new System.EventHandler(this.HandleBuiltinStyleTabPagesOverFlowMenuGlyphActiveRectangleFillColorChanged);
            // 
            // binaryColorPickerComboBox42
            // 
            this.binaryColorPickerComboBox42.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox42.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox42.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox42.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox42.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox42.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox42.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox42.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox42.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox42.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox42.FormattingEnabled = true;
            this.binaryColorPickerComboBox42.Items.AddRange(new object[] {
            "51, 153, 255"});
            this.binaryColorPickerComboBox42.Location = new System.Drawing.Point(557, 273);
            this.binaryColorPickerComboBox42.Name = "binaryColorPickerComboBox42";
            this.binaryColorPickerComboBox42.SelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(153)))), ((int)(((byte)(255)))));
            this.binaryColorPickerComboBox42.ShowBorderAlways = true;
            this.binaryColorPickerComboBox42.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox42.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox42.TabIndex = 33;
            this.binaryColorPickerComboBox42.SelectedColorChanged += new System.EventHandler(this.HandleBuiltinStyleTabPagesOverFlowMenuGlyphActiveRectangleBorderColorChanged);
            // 
            // binaryColorPickerComboBox43
            // 
            this.binaryColorPickerComboBox43.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox43.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox43.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox43.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox43.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox43.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox43.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox43.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox43.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox43.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox43.FormattingEnabled = true;
            this.binaryColorPickerComboBox43.Items.AddRange(new object[] {
            "51, 153, 255"});
            this.binaryColorPickerComboBox43.Location = new System.Drawing.Point(557, 245);
            this.binaryColorPickerComboBox43.Name = "binaryColorPickerComboBox43";
            this.binaryColorPickerComboBox43.SelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(153)))), ((int)(((byte)(255)))));
            this.binaryColorPickerComboBox43.ShowBorderAlways = true;
            this.binaryColorPickerComboBox43.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox43.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox43.TabIndex = 32;
            this.binaryColorPickerComboBox43.SelectedColorChanged += new System.EventHandler(this.HandleBuiltinStyleTabPagesOverFlowMenuDropDownColorChanged);
            // 
            // binaryColorPickerComboBox44
            // 
            this.binaryColorPickerComboBox44.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox44.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox44.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox44.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox44.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox44.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox44.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox44.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox44.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox44.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox44.FormattingEnabled = true;
            this.binaryColorPickerComboBox44.Items.AddRange(new object[] {
            "210, 222, 242"});
            this.binaryColorPickerComboBox44.Location = new System.Drawing.Point(189, 301);
            this.binaryColorPickerComboBox44.Name = "binaryColorPickerComboBox44";
            this.binaryColorPickerComboBox44.SelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(222)))), ((int)(((byte)(242)))));
            this.binaryColorPickerComboBox44.ShowBorderAlways = true;
            this.binaryColorPickerComboBox44.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox44.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox44.TabIndex = 31;
            this.binaryColorPickerComboBox44.SelectedColorChanged += new System.EventHandler(this.HandleBuiltinStyleTabPageCloseButtonRectangleFillColorChanged);
            // 
            // binaryColorPickerComboBox45
            // 
            this.binaryColorPickerComboBox45.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox45.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox45.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox45.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox45.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox45.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox45.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox45.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox45.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox45.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox45.FormattingEnabled = true;
            this.binaryColorPickerComboBox45.Items.AddRange(new object[] {
            "51, 153, 255"});
            this.binaryColorPickerComboBox45.Location = new System.Drawing.Point(189, 273);
            this.binaryColorPickerComboBox45.Name = "binaryColorPickerComboBox45";
            this.binaryColorPickerComboBox45.SelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(153)))), ((int)(((byte)(255)))));
            this.binaryColorPickerComboBox45.ShowBorderAlways = true;
            this.binaryColorPickerComboBox45.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox45.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox45.TabIndex = 30;
            this.binaryColorPickerComboBox45.SelectedColorChanged += new System.EventHandler(this.HandleBuiltinStyleTabPageCloseButtonRectangleBorderColorChanged);
            // 
            // binaryColorPickerComboBox46
            // 
            this.binaryColorPickerComboBox46.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox46.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox46.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox46.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox46.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox46.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox46.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox46.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox46.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox46.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox46.FormattingEnabled = true;
            this.binaryColorPickerComboBox46.Items.AddRange(new object[] {
            "51, 153, 255"});
            this.binaryColorPickerComboBox46.Location = new System.Drawing.Point(189, 245);
            this.binaryColorPickerComboBox46.Name = "binaryColorPickerComboBox46";
            this.binaryColorPickerComboBox46.SelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(51)))), ((int)(((byte)(153)))), ((int)(((byte)(255)))));
            this.binaryColorPickerComboBox46.ShowBorderAlways = true;
            this.binaryColorPickerComboBox46.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox46.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox46.TabIndex = 29;
            this.binaryColorPickerComboBox46.SelectedColorChanged += new System.EventHandler(this.HandleTabPagesCloseButtonColorSelectedColorChanged);
            // 
            // label81
            // 
            this.label81.AutoSize = true;
            this.label81.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label81.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label81.Location = new System.Drawing.Point(388, 253);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(94, 13);
            this.label81.TabIndex = 26;
            this.label81.Text = "Menu button color";
            // 
            // label82
            // 
            this.label82.AutoSize = true;
            this.label82.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label82.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label82.Location = new System.Drawing.Point(31, 253);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(94, 13);
            this.label82.TabIndex = 25;
            this.label82.Text = "Close button color";
            // 
            // label83
            // 
            this.label83.AutoSize = true;
            this.label83.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label83.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label83.Location = new System.Drawing.Point(370, 173);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(136, 13);
            this.label83.TabIndex = 23;
            this.label83.Text = "Tab page Header forecolor";
            // 
            // chkDrawGapBetweenTabPagesTabPage1
            // 
            this.chkDrawGapBetweenTabPagesTabPage1.AutoSize = true;
            this.chkDrawGapBetweenTabPagesTabPage1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkDrawGapBetweenTabPagesTabPage1.ForeColor = System.Drawing.SystemColors.WindowText;
            this.chkDrawGapBetweenTabPagesTabPage1.Location = new System.Drawing.Point(15, 100);
            this.chkDrawGapBetweenTabPagesTabPage1.Name = "chkDrawGapBetweenTabPagesTabPage1";
            this.chkDrawGapBetweenTabPagesTabPage1.Size = new System.Drawing.Size(168, 17);
            this.chkDrawGapBetweenTabPagesTabPage1.TabIndex = 11;
            this.chkDrawGapBetweenTabPagesTabPage1.Text = "Draw gap between tab pages";
            this.chkDrawGapBetweenTabPagesTabPage1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.chkDrawGapBetweenTabPagesTabPage1.UseVisualStyleBackColor = true;
            this.chkDrawGapBetweenTabPagesTabPage1.CheckedChanged += new System.EventHandler(this.HandleBuiltinStyleTabPagesHaveGapBetweenThemChanged);
            // 
            // label84
            // 
            this.label84.AutoSize = true;
            this.label84.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label84.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label84.Location = new System.Drawing.Point(31, 303);
            this.label84.Name = "label84";
            this.label84.Size = new System.Drawing.Size(107, 13);
            this.label84.TabIndex = 21;
            this.label84.Text = "Close button fill color";
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox4.ForeColor = System.Drawing.SystemColors.WindowText;
            this.checkBox4.Location = new System.Drawing.Point(372, 59);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(199, 17);
            this.checkBox4.TabIndex = 9;
            this.checkBox4.Text = "Draw tab page on top of each other";
            this.checkBox4.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.HandleBuiltinStyleDrawTabPageOnTopOfEachOtherChanged);
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox5.ForeColor = System.Drawing.SystemColors.WindowText;
            this.checkBox5.Location = new System.Drawing.Point(15, 21);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(173, 17);
            this.checkBox5.TabIndex = 10;
            this.checkBox5.Text = "Enable drag-drop of tab pages";
            this.checkBox5.UseVisualStyleBackColor = true;
            this.checkBox5.CheckedChanged += new System.EventHandler(this.HandleBuiltinStyleTabControlEnableDragAndDropOfTabPagesChanged);
            // 
            // label85
            // 
            this.label85.AutoSize = true;
            this.label85.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label85.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label85.Location = new System.Drawing.Point(31, 278);
            this.label85.Name = "label85";
            this.label85.Size = new System.Drawing.Size(129, 13);
            this.label85.TabIndex = 20;
            this.label85.Text = "Close button border color";
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Checked = true;
            this.checkBox6.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox6.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox6.ForeColor = System.Drawing.SystemColors.WindowText;
            this.checkBox6.Location = new System.Drawing.Point(15, 219);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(114, 17);
            this.checkBox6.TabIndex = 1;
            this.checkBox6.Text = "Show close button";
            this.checkBox6.UseVisualStyleBackColor = true;
            this.checkBox6.CheckedChanged += new System.EventHandler(this.HandleShowCloseButtonCheckedChanged);
            // 
            // label86
            // 
            this.label86.AutoSize = true;
            this.label86.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label86.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label86.Location = new System.Drawing.Point(388, 303);
            this.label86.Name = "label86";
            this.label86.Size = new System.Drawing.Size(107, 13);
            this.label86.TabIndex = 17;
            this.label86.Text = "Menu button fill color";
            // 
            // label87
            // 
            this.label87.AutoSize = true;
            this.label87.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label87.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label87.Location = new System.Drawing.Point(388, 278);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(129, 13);
            this.label87.TabIndex = 16;
            this.label87.Text = "Menu button border color";
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Checked = true;
            this.checkBox7.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox7.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox7.ForeColor = System.Drawing.SystemColors.WindowText;
            this.checkBox7.Location = new System.Drawing.Point(372, 223);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(167, 17);
            this.checkBox7.TabIndex = 2;
            this.checkBox7.Text = "Show menu dropdown button";
            this.checkBox7.UseVisualStyleBackColor = true;
            this.checkBox7.CheckedChanged += new System.EventHandler(this.HandleBuiltinStyleShowOverflowMenuGlyphChanged);
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox8.ForeColor = System.Drawing.SystemColors.WindowText;
            this.checkBox8.Location = new System.Drawing.Point(15, 43);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(166, 17);
            this.checkBox8.TabIndex = 8;
            this.checkBox8.Text = "Draw border around tab strip";
            this.checkBox8.UseVisualStyleBackColor = true;
            this.checkBox8.CheckedChanged += new System.EventHandler(this.HandleBuiltinStyleDrawBorderAroundTabStripChanged);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numericUpDown1.Location = new System.Drawing.Point(287, 155);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(48, 21);
            this.numericUpDown1.TabIndex = 14;
            this.numericUpDown1.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.HandleBuiltinStyledTabControlEmptySpaceLengthBeforeFirstTagPageHeaderValueChanged);
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.Enabled = false;
            this.numericUpDown3.Location = new System.Drawing.Point(287, 123);
            this.numericUpDown3.Maximum = new decimal(new int[] {
            15,
            0,
            0,
            0});
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(48, 21);
            this.numericUpDown3.TabIndex = 13;
            this.numericUpDown3.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.numericUpDown3.ValueChanged += new System.EventHandler(this.HandleBuiltinStyleGapBetweenTabPagesValuesChanged);
            // 
            // label88
            // 
            this.label88.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label88.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label88.Location = new System.Drawing.Point(33, 152);
            this.label88.Name = "label88";
            this.label88.Size = new System.Drawing.Size(206, 28);
            this.label88.TabIndex = 7;
            this.label88.Text = "Empty space length before the first tabpage header";
            // 
            // label89
            // 
            this.label89.AutoSize = true;
            this.label89.Enabled = false;
            this.label89.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label89.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label89.Location = new System.Drawing.Point(33, 128);
            this.label89.Name = "label89";
            this.label89.Size = new System.Drawing.Size(189, 13);
            this.label89.TabIndex = 6;
            this.label89.Text = "Gap length between tabpage headers";
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.checkBox1);
            this.panel5.Controls.Add(this.tabPageRenderingLocationCmbBx);
            this.panel5.Controls.Add(this.label77);
            this.panel5.Controls.Add(this.cmbTabPageRenderingStyle);
            this.panel5.Controls.Add(this.label13);
            this.panel5.Controls.Add(this.binaryColorPickerComboBoxTabPageHeaderForecolor);
            this.panel5.Controls.Add(this.binaryColorPickerComboBoxMenuButtonFillColor);
            this.panel5.Controls.Add(this.binaryColorPickerComboBoxMenuButtonBorderColor);
            this.panel5.Controls.Add(this.binaryColorPickerComboBoxMenuButtonColor);
            this.panel5.Controls.Add(this.binaryColorPickerComboBoxCloseButtonFillColor);
            this.panel5.Controls.Add(this.binaryColorPickerComboBox1CloseButtonBorderColor);
            this.panel5.Controls.Add(this.binaryColorPickerComboBox1CloseButtonColor);
            this.panel5.Controls.Add(this.label12);
            this.panel5.Controls.Add(this.label9);
            this.panel5.Controls.Add(this.label5);
            this.panel5.Controls.Add(this.chkDrawGapBetweenTabPages);
            this.panel5.Controls.Add(this.label11);
            this.panel5.Controls.Add(this.chkDrawTabPageOnTopofEachother);
            this.panel5.Controls.Add(this.chkEnableDragDrop1);
            this.panel5.Controls.Add(this.label10);
            this.panel5.Controls.Add(this.chkShowCloseButton);
            this.panel5.Controls.Add(this.label7);
            this.panel5.Controls.Add(this.label6);
            this.panel5.Controls.Add(this.chkShowMenuDropDownButton);
            this.panel5.Controls.Add(this.chkDrawBorderAroundTabStrip);
            this.panel5.Controls.Add(this.numericUpDownEmptySpaceLengthBeforeFirstTagPageHeader);
            this.panel5.Controls.Add(this.numericUpDown2);
            this.panel5.Controls.Add(this.label4);
            this.panel5.Controls.Add(this.label3);
            this.panel5.Location = new System.Drawing.Point(18, 204);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(722, 300);
            this.panel5.TabIndex = 27;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Checked = true;
            this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.ForeColor = System.Drawing.SystemColors.WindowText;
            this.checkBox1.Location = new System.Drawing.Point(357, 21);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(286, 17);
            this.checkBox1.TabIndex = 40;
            this.checkBox1.Text = "Enable drawing \"Close button\" in the Tab page header";
            this.checkBox1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.HandleEnableTabPageLevelCloseButtonRenderingChanged);
            // 
            // tabPageRenderingLocationCmbBx
            // 
            this.tabPageRenderingLocationCmbBx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.tabPageRenderingLocationCmbBx.FormattingEnabled = true;
            this.tabPageRenderingLocationCmbBx.Items.AddRange(new object[] {
            "Top",
            "Bottom"});
            this.tabPageRenderingLocationCmbBx.Location = new System.Drawing.Point(559, 88);
            this.tabPageRenderingLocationCmbBx.Name = "tabPageRenderingLocationCmbBx";
            this.tabPageRenderingLocationCmbBx.Size = new System.Drawing.Size(130, 21);
            this.tabPageRenderingLocationCmbBx.TabIndex = 39;
            this.tabPageRenderingLocationCmbBx.SelectedIndexChanged += new System.EventHandler(this.HandleTabPageRenderingLocationOptionChanged);
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label77.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label77.Location = new System.Drawing.Point(354, 93);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(146, 13);
            this.label77.TabIndex = 38;
            this.label77.Text = "Tab pages rendering location";
            // 
            // cmbTabPageRenderingStyle
            // 
            this.cmbTabPageRenderingStyle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTabPageRenderingStyle.FormattingEnabled = true;
            this.cmbTabPageRenderingStyle.Items.AddRange(new object[] {
            "WindowsXP",
            "VisualStudio2005",
            "VisualStudio2008"});
            this.cmbTabPageRenderingStyle.Location = new System.Drawing.Point(559, 62);
            this.cmbTabPageRenderingStyle.Name = "cmbTabPageRenderingStyle";
            this.cmbTabPageRenderingStyle.Size = new System.Drawing.Size(130, 21);
            this.cmbTabPageRenderingStyle.TabIndex = 37;
            this.cmbTabPageRenderingStyle.SelectedIndexChanged += new System.EventHandler(this.HandleBuiltinStyledTabPageRenderingStyleTab1SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label13.Location = new System.Drawing.Point(354, 67);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(127, 13);
            this.label13.TabIndex = 36;
            this.label13.Text = "Tab page rendering style";
            // 
            // binaryColorPickerComboBoxTabPageHeaderForecolor
            // 
            this.binaryColorPickerComboBoxTabPageHeaderForecolor.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxTabPageHeaderForecolor.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxTabPageHeaderForecolor.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxTabPageHeaderForecolor.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxTabPageHeaderForecolor.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxTabPageHeaderForecolor.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxTabPageHeaderForecolor.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxTabPageHeaderForecolor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxTabPageHeaderForecolor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxTabPageHeaderForecolor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxTabPageHeaderForecolor.FormattingEnabled = true;
            this.binaryColorPickerComboBoxTabPageHeaderForecolor.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBoxTabPageHeaderForecolor.Location = new System.Drawing.Point(560, 112);
            this.binaryColorPickerComboBoxTabPageHeaderForecolor.Name = "binaryColorPickerComboBoxTabPageHeaderForecolor";
            this.binaryColorPickerComboBoxTabPageHeaderForecolor.SelectedColor = System.Drawing.Color.Empty;
            this.binaryColorPickerComboBoxTabPageHeaderForecolor.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxTabPageHeaderForecolor.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxTabPageHeaderForecolor.Size = new System.Drawing.Size(129, 22);
            this.binaryColorPickerComboBoxTabPageHeaderForecolor.TabIndex = 35;
            this.binaryColorPickerComboBoxTabPageHeaderForecolor.SelectedColorChanged += new System.EventHandler(this.HandleBuiltinStyleTabPageHeaderForeColorChanged);
            // 
            // binaryColorPickerComboBoxMenuButtonFillColor
            // 
            this.binaryColorPickerComboBoxMenuButtonFillColor.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxMenuButtonFillColor.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxMenuButtonFillColor.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxMenuButtonFillColor.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxMenuButtonFillColor.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxMenuButtonFillColor.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxMenuButtonFillColor.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxMenuButtonFillColor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxMenuButtonFillColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxMenuButtonFillColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxMenuButtonFillColor.FormattingEnabled = true;
            this.binaryColorPickerComboBoxMenuButtonFillColor.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBoxMenuButtonFillColor.Location = new System.Drawing.Point(542, 238);
            this.binaryColorPickerComboBoxMenuButtonFillColor.Name = "binaryColorPickerComboBoxMenuButtonFillColor";
            this.binaryColorPickerComboBoxMenuButtonFillColor.SelectedColor = System.Drawing.Color.Empty;
            this.binaryColorPickerComboBoxMenuButtonFillColor.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxMenuButtonFillColor.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxMenuButtonFillColor.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBoxMenuButtonFillColor.TabIndex = 34;
            this.binaryColorPickerComboBoxMenuButtonFillColor.SelectedColorChanged += new System.EventHandler(this.HandleBuiltinStyleTabPagesOverFlowMenuGlyphActiveRectangleFillColorChanged);
            // 
            // binaryColorPickerComboBoxMenuButtonBorderColor
            // 
            this.binaryColorPickerComboBoxMenuButtonBorderColor.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxMenuButtonBorderColor.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxMenuButtonBorderColor.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxMenuButtonBorderColor.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxMenuButtonBorderColor.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxMenuButtonBorderColor.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxMenuButtonBorderColor.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxMenuButtonBorderColor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxMenuButtonBorderColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxMenuButtonBorderColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxMenuButtonBorderColor.FormattingEnabled = true;
            this.binaryColorPickerComboBoxMenuButtonBorderColor.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBoxMenuButtonBorderColor.Location = new System.Drawing.Point(542, 210);
            this.binaryColorPickerComboBoxMenuButtonBorderColor.Name = "binaryColorPickerComboBoxMenuButtonBorderColor";
            this.binaryColorPickerComboBoxMenuButtonBorderColor.SelectedColor = System.Drawing.Color.Empty;
            this.binaryColorPickerComboBoxMenuButtonBorderColor.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxMenuButtonBorderColor.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxMenuButtonBorderColor.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBoxMenuButtonBorderColor.TabIndex = 33;
            this.binaryColorPickerComboBoxMenuButtonBorderColor.SelectedColorChanged += new System.EventHandler(this.HandleBuiltinStyleTabPagesOverFlowMenuGlyphActiveRectangleBorderColorChanged);
            // 
            // binaryColorPickerComboBoxMenuButtonColor
            // 
            this.binaryColorPickerComboBoxMenuButtonColor.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxMenuButtonColor.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxMenuButtonColor.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxMenuButtonColor.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxMenuButtonColor.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxMenuButtonColor.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxMenuButtonColor.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxMenuButtonColor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxMenuButtonColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxMenuButtonColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxMenuButtonColor.FormattingEnabled = true;
            this.binaryColorPickerComboBoxMenuButtonColor.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBoxMenuButtonColor.Location = new System.Drawing.Point(542, 182);
            this.binaryColorPickerComboBoxMenuButtonColor.Name = "binaryColorPickerComboBoxMenuButtonColor";
            this.binaryColorPickerComboBoxMenuButtonColor.SelectedColor = System.Drawing.Color.Empty;
            this.binaryColorPickerComboBoxMenuButtonColor.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxMenuButtonColor.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxMenuButtonColor.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBoxMenuButtonColor.TabIndex = 32;
            this.binaryColorPickerComboBoxMenuButtonColor.SelectedColorChanged += new System.EventHandler(this.HandleBuiltinStyleTabPagesOverFlowMenuDropDownColorChanged);
            // 
            // binaryColorPickerComboBoxCloseButtonFillColor
            // 
            this.binaryColorPickerComboBoxCloseButtonFillColor.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxCloseButtonFillColor.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxCloseButtonFillColor.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxCloseButtonFillColor.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxCloseButtonFillColor.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxCloseButtonFillColor.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxCloseButtonFillColor.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxCloseButtonFillColor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxCloseButtonFillColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxCloseButtonFillColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxCloseButtonFillColor.FormattingEnabled = true;
            this.binaryColorPickerComboBoxCloseButtonFillColor.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBoxCloseButtonFillColor.Location = new System.Drawing.Point(186, 238);
            this.binaryColorPickerComboBoxCloseButtonFillColor.Name = "binaryColorPickerComboBoxCloseButtonFillColor";
            this.binaryColorPickerComboBoxCloseButtonFillColor.SelectedColor = System.Drawing.Color.Empty;
            this.binaryColorPickerComboBoxCloseButtonFillColor.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxCloseButtonFillColor.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxCloseButtonFillColor.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBoxCloseButtonFillColor.TabIndex = 31;
            this.binaryColorPickerComboBoxCloseButtonFillColor.SelectedColorChanged += new System.EventHandler(this.HandleBuiltinStyleTabPageCloseButtonRectangleFillColorChanged);
            // 
            // binaryColorPickerComboBox1CloseButtonBorderColor
            // 
            this.binaryColorPickerComboBox1CloseButtonBorderColor.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox1CloseButtonBorderColor.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox1CloseButtonBorderColor.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox1CloseButtonBorderColor.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox1CloseButtonBorderColor.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox1CloseButtonBorderColor.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox1CloseButtonBorderColor.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox1CloseButtonBorderColor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox1CloseButtonBorderColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox1CloseButtonBorderColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox1CloseButtonBorderColor.FormattingEnabled = true;
            this.binaryColorPickerComboBox1CloseButtonBorderColor.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBox1CloseButtonBorderColor.Location = new System.Drawing.Point(186, 210);
            this.binaryColorPickerComboBox1CloseButtonBorderColor.Name = "binaryColorPickerComboBox1CloseButtonBorderColor";
            this.binaryColorPickerComboBox1CloseButtonBorderColor.SelectedColor = System.Drawing.Color.Empty;
            this.binaryColorPickerComboBox1CloseButtonBorderColor.ShowBorderAlways = true;
            this.binaryColorPickerComboBox1CloseButtonBorderColor.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox1CloseButtonBorderColor.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox1CloseButtonBorderColor.TabIndex = 30;
            this.binaryColorPickerComboBox1CloseButtonBorderColor.SelectedColorChanged += new System.EventHandler(this.HandleBuiltinStyleTabPageCloseButtonRectangleBorderColorChanged);
            // 
            // binaryColorPickerComboBox1CloseButtonColor
            // 
            this.binaryColorPickerComboBox1CloseButtonColor.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox1CloseButtonColor.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox1CloseButtonColor.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox1CloseButtonColor.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox1CloseButtonColor.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox1CloseButtonColor.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox1CloseButtonColor.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox1CloseButtonColor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox1CloseButtonColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox1CloseButtonColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox1CloseButtonColor.FormattingEnabled = true;
            this.binaryColorPickerComboBox1CloseButtonColor.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBox1CloseButtonColor.Location = new System.Drawing.Point(186, 182);
            this.binaryColorPickerComboBox1CloseButtonColor.Name = "binaryColorPickerComboBox1CloseButtonColor";
            this.binaryColorPickerComboBox1CloseButtonColor.SelectedColor = System.Drawing.Color.Empty;
            this.binaryColorPickerComboBox1CloseButtonColor.ShowBorderAlways = true;
            this.binaryColorPickerComboBox1CloseButtonColor.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox1CloseButtonColor.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox1CloseButtonColor.TabIndex = 29;
            this.binaryColorPickerComboBox1CloseButtonColor.SelectedColorChanged += new System.EventHandler(this.HandleTabPagesCloseButtonColorSelectedColorChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label12.Location = new System.Drawing.Point(373, 190);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(94, 13);
            this.label12.TabIndex = 26;
            this.label12.Text = "Menu button color";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label9.Location = new System.Drawing.Point(28, 190);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(94, 13);
            this.label9.TabIndex = 25;
            this.label9.Text = "Close button color";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label5.Location = new System.Drawing.Point(354, 116);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(136, 13);
            this.label5.TabIndex = 23;
            this.label5.Text = "Tab page Header forecolor";
            // 
            // chkDrawGapBetweenTabPages
            // 
            this.chkDrawGapBetweenTabPages.AutoSize = true;
            this.chkDrawGapBetweenTabPages.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkDrawGapBetweenTabPages.ForeColor = System.Drawing.SystemColors.WindowText;
            this.chkDrawGapBetweenTabPages.Location = new System.Drawing.Point(12, 79);
            this.chkDrawGapBetweenTabPages.Name = "chkDrawGapBetweenTabPages";
            this.chkDrawGapBetweenTabPages.Size = new System.Drawing.Size(168, 17);
            this.chkDrawGapBetweenTabPages.TabIndex = 11;
            this.chkDrawGapBetweenTabPages.Text = "Draw gap between tab pages";
            this.chkDrawGapBetweenTabPages.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.chkDrawGapBetweenTabPages.UseVisualStyleBackColor = true;
            this.chkDrawGapBetweenTabPages.CheckedChanged += new System.EventHandler(this.HandleBuiltinStyleTabPagesHaveGapBetweenThemChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label11.Location = new System.Drawing.Point(28, 240);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(107, 13);
            this.label11.TabIndex = 21;
            this.label11.Text = "Close button fill color";
            // 
            // chkDrawTabPageOnTopofEachother
            // 
            this.chkDrawTabPageOnTopofEachother.AutoSize = true;
            this.chkDrawTabPageOnTopofEachother.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkDrawTabPageOnTopofEachother.ForeColor = System.Drawing.SystemColors.WindowText;
            this.chkDrawTabPageOnTopofEachother.Location = new System.Drawing.Point(357, 44);
            this.chkDrawTabPageOnTopofEachother.Name = "chkDrawTabPageOnTopofEachother";
            this.chkDrawTabPageOnTopofEachother.Size = new System.Drawing.Size(199, 17);
            this.chkDrawTabPageOnTopofEachother.TabIndex = 9;
            this.chkDrawTabPageOnTopofEachother.Text = "Draw tab page on top of each other";
            this.chkDrawTabPageOnTopofEachother.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.chkDrawTabPageOnTopofEachother.UseVisualStyleBackColor = true;
            this.chkDrawTabPageOnTopofEachother.CheckedChanged += new System.EventHandler(this.HandleBuiltinStyleDrawTabPageOnTopOfEachOtherChanged);
            // 
            // chkEnableDragDrop1
            // 
            this.chkEnableDragDrop1.AutoSize = true;
            this.chkEnableDragDrop1.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkEnableDragDrop1.ForeColor = System.Drawing.SystemColors.WindowText;
            this.chkEnableDragDrop1.Location = new System.Drawing.Point(12, 25);
            this.chkEnableDragDrop1.Name = "chkEnableDragDrop1";
            this.chkEnableDragDrop1.Size = new System.Drawing.Size(173, 17);
            this.chkEnableDragDrop1.TabIndex = 10;
            this.chkEnableDragDrop1.Text = "Enable drag-drop of tab pages";
            this.chkEnableDragDrop1.UseVisualStyleBackColor = true;
            this.chkEnableDragDrop1.CheckedChanged += new System.EventHandler(this.HandleBuiltinStyleTabControlEnableDragAndDropOfTabPagesChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label10.Location = new System.Drawing.Point(28, 215);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(129, 13);
            this.label10.TabIndex = 20;
            this.label10.Text = "Close button border color";
            // 
            // chkShowCloseButton
            // 
            this.chkShowCloseButton.AutoSize = true;
            this.chkShowCloseButton.Checked = true;
            this.chkShowCloseButton.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkShowCloseButton.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkShowCloseButton.ForeColor = System.Drawing.SystemColors.WindowText;
            this.chkShowCloseButton.Location = new System.Drawing.Point(12, 168);
            this.chkShowCloseButton.Name = "chkShowCloseButton";
            this.chkShowCloseButton.Size = new System.Drawing.Size(114, 17);
            this.chkShowCloseButton.TabIndex = 1;
            this.chkShowCloseButton.Text = "Show close button";
            this.chkShowCloseButton.UseVisualStyleBackColor = true;
            this.chkShowCloseButton.CheckedChanged += new System.EventHandler(this.HandleShowCloseButtonCheckedChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label7.Location = new System.Drawing.Point(373, 240);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(107, 13);
            this.label7.TabIndex = 17;
            this.label7.Text = "Menu button fill color";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label6.Location = new System.Drawing.Point(373, 215);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(129, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "Menu button border color";
            // 
            // chkShowMenuDropDownButton
            // 
            this.chkShowMenuDropDownButton.AutoSize = true;
            this.chkShowMenuDropDownButton.Checked = true;
            this.chkShowMenuDropDownButton.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkShowMenuDropDownButton.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkShowMenuDropDownButton.ForeColor = System.Drawing.SystemColors.WindowText;
            this.chkShowMenuDropDownButton.Location = new System.Drawing.Point(357, 168);
            this.chkShowMenuDropDownButton.Name = "chkShowMenuDropDownButton";
            this.chkShowMenuDropDownButton.Size = new System.Drawing.Size(167, 17);
            this.chkShowMenuDropDownButton.TabIndex = 2;
            this.chkShowMenuDropDownButton.Text = "Show menu dropdown button";
            this.chkShowMenuDropDownButton.UseVisualStyleBackColor = true;
            this.chkShowMenuDropDownButton.CheckedChanged += new System.EventHandler(this.HandleBuiltinStyleShowOverflowMenuGlyphChanged);
            // 
            // chkDrawBorderAroundTabStrip
            // 
            this.chkDrawBorderAroundTabStrip.AutoSize = true;
            this.chkDrawBorderAroundTabStrip.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkDrawBorderAroundTabStrip.ForeColor = System.Drawing.SystemColors.WindowText;
            this.chkDrawBorderAroundTabStrip.Location = new System.Drawing.Point(12, 53);
            this.chkDrawBorderAroundTabStrip.Name = "chkDrawBorderAroundTabStrip";
            this.chkDrawBorderAroundTabStrip.Size = new System.Drawing.Size(166, 17);
            this.chkDrawBorderAroundTabStrip.TabIndex = 8;
            this.chkDrawBorderAroundTabStrip.Text = "Draw border around tab strip";
            this.chkDrawBorderAroundTabStrip.UseVisualStyleBackColor = true;
            this.chkDrawBorderAroundTabStrip.CheckedChanged += new System.EventHandler(this.HandleBuiltinStyleDrawBorderAroundTabStripChanged);
            // 
            // numericUpDownEmptySpaceLengthBeforeFirstTagPageHeader
            // 
            this.numericUpDownEmptySpaceLengthBeforeFirstTagPageHeader.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numericUpDownEmptySpaceLengthBeforeFirstTagPageHeader.Location = new System.Drawing.Point(284, 121);
            this.numericUpDownEmptySpaceLengthBeforeFirstTagPageHeader.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.numericUpDownEmptySpaceLengthBeforeFirstTagPageHeader.Name = "numericUpDownEmptySpaceLengthBeforeFirstTagPageHeader";
            this.numericUpDownEmptySpaceLengthBeforeFirstTagPageHeader.Size = new System.Drawing.Size(48, 21);
            this.numericUpDownEmptySpaceLengthBeforeFirstTagPageHeader.TabIndex = 14;
            this.numericUpDownEmptySpaceLengthBeforeFirstTagPageHeader.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.numericUpDownEmptySpaceLengthBeforeFirstTagPageHeader.ValueChanged += new System.EventHandler(this.HandleBuiltinStyledTabControlEmptySpaceLengthBeforeFirstTagPageHeaderValueChanged);
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Enabled = false;
            this.numericUpDown2.Location = new System.Drawing.Point(284, 94);
            this.numericUpDown2.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(48, 21);
            this.numericUpDown2.TabIndex = 13;
            this.numericUpDown2.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.numericUpDown2.ValueChanged += new System.EventHandler(this.HandleBuiltinStyleGapBetweenTabPagesValueChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label4.Location = new System.Drawing.Point(9, 126);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(254, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Emptyspace length before the first tabpage header";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Enabled = false;
            this.label3.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label3.Location = new System.Drawing.Point(30, 99);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(186, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Gaplength between tabpage headers";
            // 
            // binaryPowerTabStripUsingBuiltinStyle
            // 
            this.binaryPowerTabStripUsingBuiltinStyle.Cursor = System.Windows.Forms.Cursors.Default;
            this.binaryPowerTabStripUsingBuiltinStyle.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabStripUsingBuiltinStyle.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabStripUsingBuiltinStyle.DrawBorderAroundTabStrip = false;
            this.binaryPowerTabStripUsingBuiltinStyle.DrawTabPageOnTopOfEachOther = false;
            this.binaryPowerTabStripUsingBuiltinStyle.EmptySpaceLengthBeforeTheFirstTabPage = 3;
            this.binaryPowerTabStripUsingBuiltinStyle.EnableAutomaticUpdateOfTabPagesHeaderSize = false;
            this.binaryPowerTabStripUsingBuiltinStyle.EnableControlledLayoutRendering = false;
            this.binaryPowerTabStripUsingBuiltinStyle.EnableDragAndDropOfTabPages = false;
            this.binaryPowerTabStripUsingBuiltinStyle.EnableTabPageLevelCloseButtonRendering = true;
            this.binaryPowerTabStripUsingBuiltinStyle.ExtendedWindowsXPRenderingFirstColor = System.Drawing.Color.Blue;
            this.binaryPowerTabStripUsingBuiltinStyle.ExtendedWindowsXPRenderingSecondColor = System.Drawing.Color.LightBlue;
            this.binaryPowerTabStripUsingBuiltinStyle.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.binaryPowerTabStripUsingBuiltinStyle.HeaderFont = null;
            this.binaryPowerTabStripUsingBuiltinStyle.HeaderTextCloseButtonExtraGap = 8;
            this.binaryPowerTabStripUsingBuiltinStyle.IsBackgroundTransparent = false;
            this.binaryPowerTabStripUsingBuiltinStyle.KeepShowingTooltipEvenWhenMousePointerIsMoving = false;
            this.binaryPowerTabStripUsingBuiltinStyle.Location = new System.Drawing.Point(17, 11);
            this.binaryPowerTabStripUsingBuiltinStyle.Name = "binaryPowerTabStripUsingBuiltinStyle";
            this.binaryPowerTabStripUsingBuiltinStyle.NewlyAddedPagesAreLocatedAtLeftCorner = false;
            this.binaryPowerTabStripUsingBuiltinStyle.PreventInvalidation = false;
            this.binaryPowerTabStripUsingBuiltinStyle.RenderFullTextForTabPageHeader = false;
            this.binaryPowerTabStripUsingBuiltinStyle.SelectedPageHeaderTextIsRenderedBold = true;
            this.binaryPowerTabStripUsingBuiltinStyle.ShouldAutoSizeTabs = false;
            this.binaryPowerTabStripUsingBuiltinStyle.ShowToolTip = true;
            this.binaryPowerTabStripUsingBuiltinStyle.Size = new System.Drawing.Size(722, 169);
            this.binaryPowerTabStripUsingBuiltinStyle.TabBottomOrientationCloseButtonPosition = Binarymission.WinForms.Controls.TabControls.CloseButtonPosition.Bottom;
            stringFormat2.Alignment = System.Drawing.StringAlignment.Center;
            stringFormat2.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat2.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat2.Trimming = System.Drawing.StringTrimming.EllipsisCharacter;
            this.binaryPowerTabStripUsingBuiltinStyle.TabHeaderStringFormat = stringFormat2;
            this.binaryPowerTabStripUsingBuiltinStyle.TabIndex = 1;
            this.binaryPowerTabStripUsingBuiltinStyle.TabPageBorderColor = System.Drawing.SystemColors.ControlDark;
            this.binaryPowerTabStripUsingBuiltinStyle.TabPageCloseButtonMouseEnterColor = System.Drawing.Color.Red;
            this.binaryPowerTabStripUsingBuiltinStyle.TabPageCloseButtonRectangleBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryPowerTabStripUsingBuiltinStyle.TabPageCloseButtonRectangleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(222)))), ((int)(((byte)(242)))));
            this.binaryPowerTabStripUsingBuiltinStyle.TabPageCurrentSelectionIndicatorEndColor = System.Drawing.Color.White;
            this.binaryPowerTabStripUsingBuiltinStyle.TabPageCurrentSelectionIndicatorStartColor = System.Drawing.Color.Orange;
            this.binaryPowerTabStripUsingBuiltinStyle.TabPageHeaderDrawingGradientOrientation = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.binaryPowerTabStripUsingBuiltinStyle.TabPageHeaderForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabStripUsingBuiltinStyle.TabPageHeaderHeight = 30;
            this.binaryPowerTabStripUsingBuiltinStyle.TabPageHeaderShowsSideBar = true;
            this.binaryPowerTabStripUsingBuiltinStyle.TabPageHeaderTextFontOverridesControlDefault = false;
            this.binaryPowerTabStripUsingBuiltinStyle.TabPageHeaderWidth = 150;
            this.binaryPowerTabStripUsingBuiltinStyle.TabPages.AddRange(new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage[] {
            this.binaryPowerTabPage_Welcome,
            this.binaryPowerTabPage_UserManagement,
            this.binaryPowerTabPage_CustomerMeetings,
            this.binaryPowerTabPage_DatabaseReplication,
            this.binaryPowerTabPage_EmailArchives});
            this.binaryPowerTabStripUsingBuiltinStyle.TabPagesCloseButtonColor = System.Drawing.SystemColors.Highlight;
            this.binaryPowerTabStripUsingBuiltinStyle.TabPagesHaveGapBetweenThem = false;
            this.binaryPowerTabStripUsingBuiltinStyle.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabStripUsingBuiltinStyle.TabPagesOverFlowMenuDropDownColor = System.Drawing.SystemColors.Highlight;
            this.binaryPowerTabStripUsingBuiltinStyle.TabPagesOverFlowMenuGlyphActiveRectangleBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryPowerTabStripUsingBuiltinStyle.TabPagesOverFlowMenuGlyphActiveRectangleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(210)))), ((int)(((byte)(222)))), ((int)(((byte)(242)))));
            this.binaryPowerTabStripUsingBuiltinStyle.TabPagesRenderingLocation = Binarymission.WinForms.Controls.TabControls.TabPagesRenderingLocation.Top;
            this.binaryPowerTabStripUsingBuiltinStyle.TabRenderingStyle = Binarymission.WinForms.Controls.TabControls.RenderingStyle.VisualStudio2008;
            this.binaryPowerTabStripUsingBuiltinStyle.TabsOverflowMode = Binarymission.WinForms.Controls.TabControls.OverflowMode.MultiLine;
            this.binaryPowerTabStripUsingBuiltinStyle.Text = "binaryPowerTabStrip2";
            this.binaryPowerTabStripUsingBuiltinStyle.ThemeBorderColorCanBeOverridden = false;
            this.binaryPowerTabStripUsingBuiltinStyle.ToolTipConfiguration.AutomaticDelay = 500;
            this.binaryPowerTabStripUsingBuiltinStyle.ToolTipConfiguration.AutoPopDelay = 5000;
            this.binaryPowerTabStripUsingBuiltinStyle.ToolTipConfiguration.BackColor = System.Drawing.SystemColors.Info;
            this.binaryPowerTabStripUsingBuiltinStyle.ToolTipConfiguration.ForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabStripUsingBuiltinStyle.ToolTipConfiguration.InitialDelay = 500;
            this.binaryPowerTabStripUsingBuiltinStyle.ToolTipConfiguration.IsBalloon = false;
            this.binaryPowerTabStripUsingBuiltinStyle.ToolTipConfiguration.ReshowDelay = 100;
            this.binaryPowerTabStripUsingBuiltinStyle.ToolTipConfiguration.StripAmpersands = false;
            this.binaryPowerTabStripUsingBuiltinStyle.ToolTipConfiguration.ToolTipIcon = System.Windows.Forms.ToolTipIcon.None;
            this.binaryPowerTabStripUsingBuiltinStyle.ToolTipConfiguration.ToolTipTitle = "";
            this.binaryPowerTabStripUsingBuiltinStyle.ToolTipConfiguration.UseAnimation = false;
            this.binaryPowerTabStripUsingBuiltinStyle.ToolTipConfiguration.UseFading = false;
            this.binaryPowerTabStripUsingBuiltinStyle.UseTabCurrentSelectionIndicatorColor = true;
            // 
            // binaryPowerTabPage_Welcome
            // 
            this.binaryPowerTabPage_Welcome.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage_Welcome.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.binaryPowerTabPage_Welcome.BorderSize = 1;
            this.binaryPowerTabPage_Welcome.Controls.Add(this.binaryColorPickerComboBox6);
            this.binaryPowerTabPage_Welcome.Controls.Add(this.label58);
            this.binaryPowerTabPage_Welcome.Controls.Add(this.label35);
            this.binaryPowerTabPage_Welcome.Controls.Add(this.binaryColorPickerComboBox2);
            this.binaryPowerTabPage_Welcome.Controls.Add(this.label15);
            this.binaryPowerTabPage_Welcome.Controls.Add(this.binaryColorPickerComboBox1);
            this.binaryPowerTabPage_Welcome.Controls.Add(this.label14);
            this.binaryPowerTabPage_Welcome.CustomEndColor = System.Drawing.Color.FromArgb(((int)(((byte)(140)))), ((int)(((byte)(208)))), ((int)(((byte)(234)))));
            this.binaryPowerTabPage_Welcome.CustomStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(174)))), ((int)(((byte)(223)))), ((int)(((byte)(230)))));
            this.binaryPowerTabPage_Welcome.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage_Welcome.Image = ((System.Drawing.Image)(resources.GetObject("binaryPowerTabPage_Welcome.Image")));
            this.binaryPowerTabPage_Welcome.IsBackgroundTransparent = false;
            this.binaryPowerTabPage_Welcome.IsHeaderEnabled = true;
            this.binaryPowerTabPage_Welcome.Name = "binaryPowerTabPage_Welcome";
            this.binaryPowerTabPage_Welcome.Size = new System.Drawing.Size(720, 108);
            this.binaryPowerTabPage_Welcome.TabIndex = 0;
            this.binaryPowerTabPage_Welcome.TabPageContentIsDirty = false;
            this.binaryPowerTabPage_Welcome.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage_Welcome.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage_Welcome.Text = "Welcome";
            this.binaryPowerTabPage_Welcome.ToolTipText = "";
            // 
            // binaryColorPickerComboBox6
            // 
            this.binaryColorPickerComboBox6.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox6.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox6.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox6.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox6.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox6.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox6.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox6.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox6.FormattingEnabled = true;
            this.binaryColorPickerComboBox6.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBox6.Location = new System.Drawing.Point(544, 72);
            this.binaryColorPickerComboBox6.Name = "binaryColorPickerComboBox6";
            this.binaryColorPickerComboBox6.SelectedColor = System.Drawing.Color.Black;
            this.binaryColorPickerComboBox6.ShowBorderAlways = true;
            this.binaryColorPickerComboBox6.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox6.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox6.TabIndex = 50;
            this.binaryColorPickerComboBox6.SelectedColorChanged += new System.EventHandler(this.HandleWelcomeTabPageHeaderForeColorChanged);
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label58.Location = new System.Drawing.Point(356, 77);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(135, 13);
            this.label58.TabIndex = 49;
            this.label58.Text = "Tab page header forecolor";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(233, 14);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(190, 13);
            this.label35.TabIndex = 42;
            this.label35.Text = "This is the \"Welcome\"  tab page.";
            // 
            // binaryColorPickerComboBox2
            // 
            this.binaryColorPickerComboBox2.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox2.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox2.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox2.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox2.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox2.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox2.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryColorPickerComboBox2.FormattingEnabled = true;
            this.binaryColorPickerComboBox2.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBox2.Location = new System.Drawing.Point(544, 44);
            this.binaryColorPickerComboBox2.Name = "binaryColorPickerComboBox2";
            this.binaryColorPickerComboBox2.SelectedColor = System.Drawing.Color.Black;
            this.binaryColorPickerComboBox2.ShowBorderAlways = true;
            this.binaryColorPickerComboBox2.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox2.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox2.TabIndex = 41;
            this.binaryColorPickerComboBox2.SelectedColorChanged += new System.EventHandler(this.HandleBuiltinStyleTabWelcomePageChildrenForeColorChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label15.Location = new System.Drawing.Point(356, 49);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(98, 13);
            this.label15.TabIndex = 40;
            this.label15.Text = "Tab page forecolor";
            // 
            // binaryColorPickerComboBox1
            // 
            this.binaryColorPickerComboBox1.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox1.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox1.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox1.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox1.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox1.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox1.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox1.FormattingEnabled = true;
            this.binaryColorPickerComboBox1.Items.AddRange(new object[] {
            "255, 255, 255"});
            this.binaryColorPickerComboBox1.Location = new System.Drawing.Point(188, 44);
            this.binaryColorPickerComboBox1.Name = "binaryColorPickerComboBox1";
            this.binaryColorPickerComboBox1.SelectedColor = System.Drawing.Color.White;
            this.binaryColorPickerComboBox1.ShowBorderAlways = true;
            this.binaryColorPickerComboBox1.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox1.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox1.TabIndex = 39;
            this.binaryColorPickerComboBox1.SelectedColorChanged += new System.EventHandler(this.HandleWelcomeTabPageBackColorChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label14.Location = new System.Drawing.Point(11, 47);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(100, 13);
            this.label14.TabIndex = 38;
            this.label14.Text = "Tab page backcolor";
            // 
            // binaryPowerTabPage_UserManagement
            // 
            this.binaryPowerTabPage_UserManagement.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage_UserManagement.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.binaryPowerTabPage_UserManagement.BorderSize = 1;
            this.binaryPowerTabPage_UserManagement.Controls.Add(this.binaryColorPickerComboBox7);
            this.binaryPowerTabPage_UserManagement.Controls.Add(this.label60);
            this.binaryPowerTabPage_UserManagement.Controls.Add(this.label37);
            this.binaryPowerTabPage_UserManagement.Controls.Add(this.binaryColorPickerComboBox3);
            this.binaryPowerTabPage_UserManagement.Controls.Add(this.label16);
            this.binaryPowerTabPage_UserManagement.Controls.Add(this.binaryColorPickerComboBox4);
            this.binaryPowerTabPage_UserManagement.Controls.Add(this.label17);
            this.binaryPowerTabPage_UserManagement.CustomEndColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(175)))), ((int)(((byte)(226)))));
            this.binaryPowerTabPage_UserManagement.CustomStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(209)))), ((int)(((byte)(237)))));
            this.binaryPowerTabPage_UserManagement.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage_UserManagement.Image = ((System.Drawing.Image)(resources.GetObject("binaryPowerTabPage_UserManagement.Image")));
            this.binaryPowerTabPage_UserManagement.IsBackgroundTransparent = false;
            this.binaryPowerTabPage_UserManagement.IsHeaderEnabled = true;
            this.binaryPowerTabPage_UserManagement.Name = "binaryPowerTabPage_UserManagement";
            this.binaryPowerTabPage_UserManagement.Size = new System.Drawing.Size(720, 108);
            this.binaryPowerTabPage_UserManagement.TabIndex = 1;
            this.binaryPowerTabPage_UserManagement.TabPageContentIsDirty = false;
            this.binaryPowerTabPage_UserManagement.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage_UserManagement.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage_UserManagement.Text = "User Management";
            this.binaryPowerTabPage_UserManagement.ToolTipText = "";
            // 
            // binaryColorPickerComboBox7
            // 
            this.binaryColorPickerComboBox7.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox7.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox7.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox7.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox7.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox7.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox7.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox7.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox7.FormattingEnabled = true;
            this.binaryColorPickerComboBox7.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBox7.Location = new System.Drawing.Point(544, 68);
            this.binaryColorPickerComboBox7.Name = "binaryColorPickerComboBox7";
            this.binaryColorPickerComboBox7.SelectedColor = System.Drawing.Color.Black;
            this.binaryColorPickerComboBox7.ShowBorderAlways = true;
            this.binaryColorPickerComboBox7.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox7.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox7.TabIndex = 52;
            this.binaryColorPickerComboBox7.SelectedColorChanged += new System.EventHandler(this.HandleUserManagementTabPageHeaderForeColorChanged);
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label60.Location = new System.Drawing.Point(356, 71);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(135, 13);
            this.label60.TabIndex = 48;
            this.label60.Text = "Tab page header forecolor";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(248, 13);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(242, 13);
            this.label37.TabIndex = 51;
            this.label37.Text = "This is the \"User Management\"  tab page.";
            // 
            // binaryColorPickerComboBox3
            // 
            this.binaryColorPickerComboBox3.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox3.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox3.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox3.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox3.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox3.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox3.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox3.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox3.FormattingEnabled = true;
            this.binaryColorPickerComboBox3.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBox3.Location = new System.Drawing.Point(544, 40);
            this.binaryColorPickerComboBox3.Name = "binaryColorPickerComboBox3";
            this.binaryColorPickerComboBox3.SelectedColor = System.Drawing.Color.Black;
            this.binaryColorPickerComboBox3.ShowBorderAlways = true;
            this.binaryColorPickerComboBox3.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox3.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox3.TabIndex = 45;
            this.binaryColorPickerComboBox3.SelectedColorChanged += new System.EventHandler(this.HandleBuiltinStyleTabUserManagementTabChildrenForecolorChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label16.Location = new System.Drawing.Point(356, 43);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(98, 13);
            this.label16.TabIndex = 44;
            this.label16.Text = "Tab page forecolor";
            // 
            // binaryColorPickerComboBox4
            // 
            this.binaryColorPickerComboBox4.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox4.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox4.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox4.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox4.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox4.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox4.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox4.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox4.FormattingEnabled = true;
            this.binaryColorPickerComboBox4.Items.AddRange(new object[] {
            "255, 255, 255"});
            this.binaryColorPickerComboBox4.Location = new System.Drawing.Point(188, 40);
            this.binaryColorPickerComboBox4.Name = "binaryColorPickerComboBox4";
            this.binaryColorPickerComboBox4.SelectedColor = System.Drawing.Color.White;
            this.binaryColorPickerComboBox4.ShowBorderAlways = true;
            this.binaryColorPickerComboBox4.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox4.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox4.TabIndex = 43;
            this.binaryColorPickerComboBox4.SelectedColorChanged += new System.EventHandler(this.HandleUserManagementTabPageBackColorChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label17.Location = new System.Drawing.Point(11, 43);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(100, 13);
            this.label17.TabIndex = 42;
            this.label17.Text = "Tab page backcolor";
            // 
            // binaryPowerTabPage_CustomerMeetings
            // 
            this.binaryPowerTabPage_CustomerMeetings.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage_CustomerMeetings.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.binaryPowerTabPage_CustomerMeetings.BorderSize = 1;
            this.binaryPowerTabPage_CustomerMeetings.Controls.Add(this.binaryColorPickerComboBox5);
            this.binaryPowerTabPage_CustomerMeetings.Controls.Add(this.label57);
            this.binaryPowerTabPage_CustomerMeetings.Controls.Add(this.label38);
            this.binaryPowerTabPage_CustomerMeetings.Controls.Add(this.binaryColorPickerComboBox15);
            this.binaryPowerTabPage_CustomerMeetings.Controls.Add(this.label32);
            this.binaryPowerTabPage_CustomerMeetings.Controls.Add(this.label31);
            this.binaryPowerTabPage_CustomerMeetings.Controls.Add(this.binaryColorPickerComboBox16);
            this.binaryPowerTabPage_CustomerMeetings.CustomEndColor = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(210)))), ((int)(((byte)(238)))));
            this.binaryPowerTabPage_CustomerMeetings.CustomStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(169)))), ((int)(((byte)(225)))));
            this.binaryPowerTabPage_CustomerMeetings.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage_CustomerMeetings.Image = ((System.Drawing.Image)(resources.GetObject("binaryPowerTabPage_CustomerMeetings.Image")));
            this.binaryPowerTabPage_CustomerMeetings.IsBackgroundTransparent = false;
            this.binaryPowerTabPage_CustomerMeetings.IsHeaderEnabled = true;
            this.binaryPowerTabPage_CustomerMeetings.Name = "binaryPowerTabPage_CustomerMeetings";
            this.binaryPowerTabPage_CustomerMeetings.Size = new System.Drawing.Size(720, 108);
            this.binaryPowerTabPage_CustomerMeetings.TabIndex = 3;
            this.binaryPowerTabPage_CustomerMeetings.TabPageContentIsDirty = false;
            this.binaryPowerTabPage_CustomerMeetings.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage_CustomerMeetings.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage_CustomerMeetings.Text = "Customer Meetings";
            this.binaryPowerTabPage_CustomerMeetings.ToolTipText = "";
            // 
            // binaryColorPickerComboBox5
            // 
            this.binaryColorPickerComboBox5.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox5.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox5.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox5.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox5.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox5.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox5.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox5.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox5.FormattingEnabled = true;
            this.binaryColorPickerComboBox5.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBox5.Location = new System.Drawing.Point(543, 69);
            this.binaryColorPickerComboBox5.Name = "binaryColorPickerComboBox5";
            this.binaryColorPickerComboBox5.SelectedColor = System.Drawing.Color.Black;
            this.binaryColorPickerComboBox5.ShowBorderAlways = true;
            this.binaryColorPickerComboBox5.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox5.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox5.TabIndex = 48;
            this.binaryColorPickerComboBox5.SelectedColorChanged += new System.EventHandler(this.HandleBuiltinStyleTabCustomerMeetingsTabPageHeaderForeColorChanged);
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label57.Location = new System.Drawing.Point(355, 74);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(135, 13);
            this.label57.TabIndex = 47;
            this.label57.Text = "Tab page header forecolor";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(264, 13);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(248, 13);
            this.label38.TabIndex = 46;
            this.label38.Text = "This is the \"Customer Meetings\"  tab page.";
            // 
            // binaryColorPickerComboBox15
            // 
            this.binaryColorPickerComboBox15.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox15.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox15.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox15.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox15.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox15.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox15.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox15.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox15.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox15.FormattingEnabled = true;
            this.binaryColorPickerComboBox15.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBox15.Location = new System.Drawing.Point(543, 41);
            this.binaryColorPickerComboBox15.Name = "binaryColorPickerComboBox15";
            this.binaryColorPickerComboBox15.SelectedColor = System.Drawing.Color.Black;
            this.binaryColorPickerComboBox15.ShowBorderAlways = true;
            this.binaryColorPickerComboBox15.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox15.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox15.TabIndex = 45;
            this.binaryColorPickerComboBox15.SelectedColorChanged += new System.EventHandler(this.HandleBuiltinStyledTabCustomerMeetingsTabPageChildrenForecolorChanged);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label32.Location = new System.Drawing.Point(9, 44);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(100, 13);
            this.label32.TabIndex = 42;
            this.label32.Text = "Tab page backcolor";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label31.Location = new System.Drawing.Point(355, 46);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(98, 13);
            this.label31.TabIndex = 44;
            this.label31.Text = "Tab page forecolor";
            // 
            // binaryColorPickerComboBox16
            // 
            this.binaryColorPickerComboBox16.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox16.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox16.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox16.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox16.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox16.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox16.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox16.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox16.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox16.FormattingEnabled = true;
            this.binaryColorPickerComboBox16.Items.AddRange(new object[] {
            "255, 255, 255"});
            this.binaryColorPickerComboBox16.Location = new System.Drawing.Point(186, 41);
            this.binaryColorPickerComboBox16.Name = "binaryColorPickerComboBox16";
            this.binaryColorPickerComboBox16.SelectedColor = System.Drawing.Color.White;
            this.binaryColorPickerComboBox16.ShowBorderAlways = true;
            this.binaryColorPickerComboBox16.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox16.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox16.TabIndex = 43;
            this.binaryColorPickerComboBox16.SelectedColorChanged += new System.EventHandler(this.HandleCustomStyleTabCustomerMeetingsTabPageBackColorChanged);
            // 
            // binaryPowerTabPage_DatabaseReplication
            // 
            this.binaryPowerTabPage_DatabaseReplication.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage_DatabaseReplication.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(181)))), ((int)(((byte)(226)))));
            this.binaryPowerTabPage_DatabaseReplication.BorderSize = 1;
            this.binaryPowerTabPage_DatabaseReplication.Controls.Add(this.binaryColorPickerComboBox8);
            this.binaryPowerTabPage_DatabaseReplication.Controls.Add(this.label59);
            this.binaryPowerTabPage_DatabaseReplication.Controls.Add(this.label39);
            this.binaryPowerTabPage_DatabaseReplication.Controls.Add(this.binaryColorPickerComboBox13);
            this.binaryPowerTabPage_DatabaseReplication.Controls.Add(this.label8);
            this.binaryPowerTabPage_DatabaseReplication.Controls.Add(this.label2);
            this.binaryPowerTabPage_DatabaseReplication.Controls.Add(this.binaryColorPickerComboBox14);
            this.binaryPowerTabPage_DatabaseReplication.CurrentlySelected = true;
            this.binaryPowerTabPage_DatabaseReplication.CustomEndColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(190)))), ((int)(((byte)(190)))));
            this.binaryPowerTabPage_DatabaseReplication.CustomStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(137)))), ((int)(((byte)(137)))));
            this.binaryPowerTabPage_DatabaseReplication.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage_DatabaseReplication.Image = ((System.Drawing.Image)(resources.GetObject("binaryPowerTabPage_DatabaseReplication.Image")));
            this.binaryPowerTabPage_DatabaseReplication.IsBackgroundTransparent = false;
            this.binaryPowerTabPage_DatabaseReplication.IsHeaderEnabled = true;
            this.binaryPowerTabPage_DatabaseReplication.Name = "binaryPowerTabPage_DatabaseReplication";
            this.binaryPowerTabPage_DatabaseReplication.Size = new System.Drawing.Size(720, 108);
            this.binaryPowerTabPage_DatabaseReplication.TabIndex = 2;
            this.binaryPowerTabPage_DatabaseReplication.TabPageContentIsDirty = false;
            this.binaryPowerTabPage_DatabaseReplication.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage_DatabaseReplication.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage_DatabaseReplication.Text = "DB Replication";
            this.binaryPowerTabPage_DatabaseReplication.ToolTipText = "";
            // 
            // binaryColorPickerComboBox8
            // 
            this.binaryColorPickerComboBox8.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox8.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox8.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox8.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox8.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox8.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox8.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox8.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox8.FormattingEnabled = true;
            this.binaryColorPickerComboBox8.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBox8.Location = new System.Drawing.Point(544, 64);
            this.binaryColorPickerComboBox8.Name = "binaryColorPickerComboBox8";
            this.binaryColorPickerComboBox8.SelectedColor = System.Drawing.Color.Black;
            this.binaryColorPickerComboBox8.ShowBorderAlways = true;
            this.binaryColorPickerComboBox8.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox8.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox8.TabIndex = 48;
            this.binaryColorPickerComboBox8.SelectedColorChanged += new System.EventHandler(this.HandleDatabaseReplicationTabPageHeaderForeColorChanged);
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label59.Location = new System.Drawing.Point(355, 69);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(135, 13);
            this.label59.TabIndex = 47;
            this.label59.Text = "Tab page header forecolor";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(258, 13);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(219, 13);
            this.label39.TabIndex = 46;
            this.label39.Text = "This is the \"DB Replication\"  tab page.";
            // 
            // binaryColorPickerComboBox13
            // 
            this.binaryColorPickerComboBox13.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox13.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox13.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox13.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox13.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox13.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox13.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox13.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox13.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox13.FormattingEnabled = true;
            this.binaryColorPickerComboBox13.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBox13.Location = new System.Drawing.Point(544, 39);
            this.binaryColorPickerComboBox13.Name = "binaryColorPickerComboBox13";
            this.binaryColorPickerComboBox13.SelectedColor = System.Drawing.Color.Black;
            this.binaryColorPickerComboBox13.ShowBorderAlways = true;
            this.binaryColorPickerComboBox13.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox13.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox13.TabIndex = 45;
            this.binaryColorPickerComboBox13.SelectedColorChanged += new System.EventHandler(this.HandleBuiltinStyledTabDbReplicationTabPageChildrenForecolorChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label8.Location = new System.Drawing.Point(11, 42);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 13);
            this.label8.TabIndex = 42;
            this.label8.Text = "Tab page backcolor";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label2.Location = new System.Drawing.Point(356, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(98, 13);
            this.label2.TabIndex = 44;
            this.label2.Text = "Tab page forecolor";
            // 
            // binaryColorPickerComboBox14
            // 
            this.binaryColorPickerComboBox14.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox14.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox14.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox14.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox14.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox14.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox14.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox14.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox14.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox14.FormattingEnabled = true;
            this.binaryColorPickerComboBox14.Items.AddRange(new object[] {
            "255, 255, 255"});
            this.binaryColorPickerComboBox14.Location = new System.Drawing.Point(188, 39);
            this.binaryColorPickerComboBox14.Name = "binaryColorPickerComboBox14";
            this.binaryColorPickerComboBox14.SelectedColor = System.Drawing.Color.White;
            this.binaryColorPickerComboBox14.ShowBorderAlways = true;
            this.binaryColorPickerComboBox14.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox14.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox14.TabIndex = 43;
            this.binaryColorPickerComboBox14.SelectedColorChanged += new System.EventHandler(this.HandleCustomStyledTabDatabaseReplicationBackColorChanged);
            // 
            // binaryPowerTabPage_EmailArchives
            // 
            this.binaryPowerTabPage_EmailArchives.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage_EmailArchives.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.binaryPowerTabPage_EmailArchives.BorderSize = 1;
            this.binaryPowerTabPage_EmailArchives.Controls.Add(this.binaryColorPickerComboBox9);
            this.binaryPowerTabPage_EmailArchives.Controls.Add(this.label61);
            this.binaryPowerTabPage_EmailArchives.Controls.Add(this.label36);
            this.binaryPowerTabPage_EmailArchives.Controls.Add(this.binaryColorPickerComboBox17);
            this.binaryPowerTabPage_EmailArchives.Controls.Add(this.binaryColorPickerComboBox18);
            this.binaryPowerTabPage_EmailArchives.Controls.Add(this.label33);
            this.binaryPowerTabPage_EmailArchives.Controls.Add(this.label34);
            this.binaryPowerTabPage_EmailArchives.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage_EmailArchives.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage_EmailArchives.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage_EmailArchives.Image = ((System.Drawing.Image)(resources.GetObject("binaryPowerTabPage_EmailArchives.Image")));
            this.binaryPowerTabPage_EmailArchives.IsBackgroundTransparent = false;
            this.binaryPowerTabPage_EmailArchives.IsHeaderEnabled = true;
            this.binaryPowerTabPage_EmailArchives.Name = "binaryPowerTabPage_EmailArchives";
            this.binaryPowerTabPage_EmailArchives.Size = new System.Drawing.Size(720, 108);
            this.binaryPowerTabPage_EmailArchives.TabIndex = 4;
            this.binaryPowerTabPage_EmailArchives.TabPageContentIsDirty = false;
            this.binaryPowerTabPage_EmailArchives.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage_EmailArchives.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage_EmailArchives.Text = "Email Archives";
            this.binaryPowerTabPage_EmailArchives.ToolTipText = "";
            // 
            // binaryColorPickerComboBox9
            // 
            this.binaryColorPickerComboBox9.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox9.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox9.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox9.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox9.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox9.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox9.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox9.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox9.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox9.FormattingEnabled = true;
            this.binaryColorPickerComboBox9.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBox9.Location = new System.Drawing.Point(519, 69);
            this.binaryColorPickerComboBox9.Name = "binaryColorPickerComboBox9";
            this.binaryColorPickerComboBox9.SelectedColor = System.Drawing.Color.Black;
            this.binaryColorPickerComboBox9.ShowBorderAlways = true;
            this.binaryColorPickerComboBox9.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox9.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox9.TabIndex = 52;
            this.binaryColorPickerComboBox9.SelectedColorChanged += new System.EventHandler(this.HandleEmailArchivesTabPageHeaderForeColorChanged);
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label61.Location = new System.Drawing.Point(363, 72);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(135, 13);
            this.label61.TabIndex = 51;
            this.label61.Text = "Tab page header forecolor";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(233, 12);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(220, 13);
            this.label36.TabIndex = 50;
            this.label36.Text = "This is the \"Email Archives\"  tab page.";
            // 
            // binaryColorPickerComboBox17
            // 
            this.binaryColorPickerComboBox17.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox17.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox17.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox17.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox17.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox17.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox17.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox17.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox17.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox17.FormattingEnabled = true;
            this.binaryColorPickerComboBox17.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBox17.Location = new System.Drawing.Point(519, 41);
            this.binaryColorPickerComboBox17.Name = "binaryColorPickerComboBox17";
            this.binaryColorPickerComboBox17.SelectedColor = System.Drawing.Color.Black;
            this.binaryColorPickerComboBox17.ShowBorderAlways = true;
            this.binaryColorPickerComboBox17.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox17.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox17.TabIndex = 49;
            this.binaryColorPickerComboBox17.SelectedColorChanged += new System.EventHandler(this.HandleBuiltinStyleTabEmailArchiveTabChildrenForecolorChanged);
            // 
            // binaryColorPickerComboBox18
            // 
            this.binaryColorPickerComboBox18.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox18.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox18.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox18.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox18.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox18.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox18.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox18.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox18.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox18.FormattingEnabled = true;
            this.binaryColorPickerComboBox18.Items.AddRange(new object[] {
            "255, 255, 255"});
            this.binaryColorPickerComboBox18.Location = new System.Drawing.Point(164, 41);
            this.binaryColorPickerComboBox18.Name = "binaryColorPickerComboBox18";
            this.binaryColorPickerComboBox18.SelectedColor = System.Drawing.Color.White;
            this.binaryColorPickerComboBox18.ShowBorderAlways = true;
            this.binaryColorPickerComboBox18.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox18.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox18.TabIndex = 47;
            this.binaryColorPickerComboBox18.SelectedColorChanged += new System.EventHandler(this.HandleCustomStyledTabEmailArchivesBackColorChanged);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label33.Location = new System.Drawing.Point(363, 44);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(98, 13);
            this.label33.TabIndex = 48;
            this.label33.Text = "Tab page forecolor";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label34.Location = new System.Drawing.Point(11, 44);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(100, 13);
            this.label34.TabIndex = 46;
            this.label34.Text = "Tab page backcolor";
            // 
            // binaryPowerTabPage2
            // 
            this.binaryPowerTabPage2.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage2.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.binaryPowerTabPage2.BorderSize = 1;
            this.binaryPowerTabPage2.Controls.Add(this.panel4);
            this.binaryPowerTabPage2.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage2.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage2.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage2.IsBackgroundTransparent = false;
            this.binaryPowerTabPage2.IsHeaderEnabled = true;
            this.binaryPowerTabPage2.Name = "binaryPowerTabPage2";
            this.binaryPowerTabPage2.Size = new System.Drawing.Size(766, 562);
            this.binaryPowerTabPage2.TabIndex = 4;
            this.binaryPowerTabPage2.TabPageContentIsDirty = false;
            this.binaryPowerTabPage2.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage2.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage2.Text = "Custom style";
            this.binaryPowerTabPage2.ToolTipText = "";
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.label40);
            this.panel4.Controls.Add(this.panel2);
            this.panel4.Controls.Add(this.binaryPowerTabStripUsingCustomStyle);
            this.panel4.Location = new System.Drawing.Point(4, 5);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(757, 552);
            this.panel4.TabIndex = 2;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label40.Location = new System.Drawing.Point(25, 189);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(163, 14);
            this.label40.TabIndex = 39;
            this.label40.Text = "  Customisation Options  ";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.chkShouldAutoSizeTabHeaders2);
            this.panel2.Controls.Add(this.label92);
            this.panel2.Controls.Add(this.overflowModeCmbBx2);
            this.panel2.Controls.Add(this.customTabPagesRenderignLocationCmbBx);
            this.panel2.Controls.Add(this.label78);
            this.panel2.Controls.Add(this.cmbCustomTabPageRenderingStyle);
            this.panel2.Controls.Add(this.label76);
            this.panel2.Controls.Add(this.binaryColorPickerComboBoxSideBarFillColor);
            this.panel2.Controls.Add(this.binaryColorPickerComboBoxTabPageHeaderForecolor2);
            this.panel2.Controls.Add(this.binaryColorPickerComboBoxMenuButtonFillColor2);
            this.panel2.Controls.Add(this.binaryColorPickerComboBoxMenuButtonBorderColor2);
            this.panel2.Controls.Add(this.binaryColorPickerComboBoxMenuButtonColor2);
            this.panel2.Controls.Add(this.binaryColorPickerComboBoxCloseButtonFillColor2);
            this.panel2.Controls.Add(this.binaryColorPickerComboBoxCloseButtonBorderColor2);
            this.panel2.Controls.Add(this.binaryColorPickerComboBoxCloseButtonColor2);
            this.panel2.Controls.Add(this.binaryColorPickerComboBoxTabPageBorderColor2);
            this.panel2.Controls.Add(this.label19);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Controls.Add(this.label21);
            this.panel2.Controls.Add(this.label22);
            this.panel2.Controls.Add(this.label23);
            this.panel2.Controls.Add(this.chkDrawGapBetweenTabPages2);
            this.panel2.Controls.Add(this.label24);
            this.panel2.Controls.Add(this.chkDrawTabPageOnTopofEachOther2);
            this.panel2.Controls.Add(this.chkEnableDragDrop2);
            this.panel2.Controls.Add(this.chkShowSideBarOnTabPageHeader);
            this.panel2.Controls.Add(this.label25);
            this.panel2.Controls.Add(this.chkShowCloseButton2);
            this.panel2.Controls.Add(this.label26);
            this.panel2.Controls.Add(this.label27);
            this.panel2.Controls.Add(this.chkShowMenuDropdownButton2);
            this.panel2.Controls.Add(this.chkDrawBorderAroundTabStrip2);
            this.panel2.Controls.Add(this.cmbGradientOrientationOnTabPageHeader);
            this.panel2.Controls.Add(this.numericUpDownEmptySpaceLengthBeforeFirstTabPageHeader2);
            this.panel2.Controls.Add(this.numericUpDownGapLengthBetweenTabPageHeader);
            this.panel2.Controls.Add(this.label28);
            this.panel2.Controls.Add(this.label29);
            this.panel2.Controls.Add(this.label30);
            this.panel2.Location = new System.Drawing.Point(16, 196);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(722, 340);
            this.panel2.TabIndex = 28;
            // 
            // chkShouldAutoSizeTabHeaders2
            // 
            this.chkShouldAutoSizeTabHeaders2.AutoSize = true;
            this.chkShouldAutoSizeTabHeaders2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkShouldAutoSizeTabHeaders2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.chkShouldAutoSizeTabHeaders2.Location = new System.Drawing.Point(14, 48);
            this.chkShouldAutoSizeTabHeaders2.Name = "chkShouldAutoSizeTabHeaders2";
            this.chkShouldAutoSizeTabHeaders2.Size = new System.Drawing.Size(166, 17);
            this.chkShouldAutoSizeTabHeaders2.TabIndex = 46;
            this.chkShouldAutoSizeTabHeaders2.Text = "Should auto-size tab headers";
            this.chkShouldAutoSizeTabHeaders2.UseVisualStyleBackColor = true;
            this.chkShouldAutoSizeTabHeaders2.CheckedChanged += new System.EventHandler(this.HandleCustomStyledTabControlShouldAutoSizeTabsChanged);
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label92.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label92.Location = new System.Drawing.Point(369, 91);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(125, 13);
            this.label92.TabIndex = 45;
            this.label92.Text = "Tab pags overflow mode";
            // 
            // overflowModeCmbBx2
            // 
            this.overflowModeCmbBx2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.overflowModeCmbBx2.FormattingEnabled = true;
            this.overflowModeCmbBx2.Items.AddRange(new object[] {
            "Menu",
            "MultiLine"});
            this.overflowModeCmbBx2.Location = new System.Drawing.Point(557, 89);
            this.overflowModeCmbBx2.Name = "overflowModeCmbBx2";
            this.overflowModeCmbBx2.Size = new System.Drawing.Size(148, 21);
            this.overflowModeCmbBx2.TabIndex = 44;
            this.overflowModeCmbBx2.SelectedIndexChanged += new System.EventHandler(this.HandleCustomStyledTabControlTabsOverflowChanged);
            // 
            // customTabPagesRenderignLocationCmbBx
            // 
            this.customTabPagesRenderignLocationCmbBx.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.customTabPagesRenderignLocationCmbBx.FormattingEnabled = true;
            this.customTabPagesRenderignLocationCmbBx.Items.AddRange(new object[] {
            "Top",
            "Bottom"});
            this.customTabPagesRenderignLocationCmbBx.Location = new System.Drawing.Point(557, 66);
            this.customTabPagesRenderignLocationCmbBx.Name = "customTabPagesRenderignLocationCmbBx";
            this.customTabPagesRenderignLocationCmbBx.Size = new System.Drawing.Size(148, 21);
            this.customTabPagesRenderignLocationCmbBx.TabIndex = 42;
            this.customTabPagesRenderignLocationCmbBx.SelectedIndexChanged += new System.EventHandler(this.HandleCustomTabPagesRenderignLocationCmbBx);
            // 
            // label78
            // 
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label78.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label78.Location = new System.Drawing.Point(369, 70);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(146, 13);
            this.label78.TabIndex = 41;
            this.label78.Text = "Tab pages rendering location";
            // 
            // cmbCustomTabPageRenderingStyle
            // 
            this.cmbCustomTabPageRenderingStyle.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCustomTabPageRenderingStyle.FormattingEnabled = true;
            this.cmbCustomTabPageRenderingStyle.Items.AddRange(new object[] {
            "Custom",
            "TrapeziumTop"});
            this.cmbCustomTabPageRenderingStyle.Location = new System.Drawing.Point(556, 43);
            this.cmbCustomTabPageRenderingStyle.Name = "cmbCustomTabPageRenderingStyle";
            this.cmbCustomTabPageRenderingStyle.Size = new System.Drawing.Size(149, 21);
            this.cmbCustomTabPageRenderingStyle.TabIndex = 39;
            this.cmbCustomTabPageRenderingStyle.SelectedIndexChanged += new System.EventHandler(this.HandleCustomTabPageRenderingStyleSelectionChanged);
            // 
            // label76
            // 
            this.label76.AutoSize = true;
            this.label76.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label76.Location = new System.Drawing.Point(368, 47);
            this.label76.Name = "label76";
            this.label76.Size = new System.Drawing.Size(127, 13);
            this.label76.TabIndex = 38;
            this.label76.Text = "Tab page rendering style";
            // 
            // binaryColorPickerComboBoxSideBarFillColor
            // 
            this.binaryColorPickerComboBoxSideBarFillColor.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxSideBarFillColor.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxSideBarFillColor.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxSideBarFillColor.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxSideBarFillColor.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxSideBarFillColor.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxSideBarFillColor.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxSideBarFillColor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxSideBarFillColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxSideBarFillColor.Enabled = false;
            this.binaryColorPickerComboBoxSideBarFillColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxSideBarFillColor.FormattingEnabled = true;
            this.binaryColorPickerComboBoxSideBarFillColor.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBoxSideBarFillColor.Location = new System.Drawing.Point(556, 197);
            this.binaryColorPickerComboBoxSideBarFillColor.Name = "binaryColorPickerComboBoxSideBarFillColor";
            this.binaryColorPickerComboBoxSideBarFillColor.SelectedColor = System.Drawing.Color.Black;
            this.binaryColorPickerComboBoxSideBarFillColor.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxSideBarFillColor.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxSideBarFillColor.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBoxSideBarFillColor.TabIndex = 40;
            this.binaryColorPickerComboBoxSideBarFillColor.SelectedColorChanged += new System.EventHandler(this.HandleCustomStyleTabPageSideBarFillColorChanged);
            // 
            // binaryColorPickerComboBoxTabPageHeaderForecolor2
            // 
            this.binaryColorPickerComboBoxTabPageHeaderForecolor2.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxTabPageHeaderForecolor2.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxTabPageHeaderForecolor2.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxTabPageHeaderForecolor2.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxTabPageHeaderForecolor2.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxTabPageHeaderForecolor2.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxTabPageHeaderForecolor2.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxTabPageHeaderForecolor2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxTabPageHeaderForecolor2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxTabPageHeaderForecolor2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxTabPageHeaderForecolor2.FormattingEnabled = true;
            this.binaryColorPickerComboBoxTabPageHeaderForecolor2.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBoxTabPageHeaderForecolor2.Location = new System.Drawing.Point(217, 129);
            this.binaryColorPickerComboBoxTabPageHeaderForecolor2.Name = "binaryColorPickerComboBoxTabPageHeaderForecolor2";
            this.binaryColorPickerComboBoxTabPageHeaderForecolor2.SelectedColor = System.Drawing.Color.Black;
            this.binaryColorPickerComboBoxTabPageHeaderForecolor2.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxTabPageHeaderForecolor2.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxTabPageHeaderForecolor2.Size = new System.Drawing.Size(130, 22);
            this.binaryColorPickerComboBoxTabPageHeaderForecolor2.TabIndex = 35;
            this.binaryColorPickerComboBoxTabPageHeaderForecolor2.SelectedColorChanged += new System.EventHandler(this.HandleCustomStyleTabPageHeaderForeColorChanged);
            // 
            // binaryColorPickerComboBoxMenuButtonFillColor2
            // 
            this.binaryColorPickerComboBoxMenuButtonFillColor2.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxMenuButtonFillColor2.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxMenuButtonFillColor2.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxMenuButtonFillColor2.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxMenuButtonFillColor2.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxMenuButtonFillColor2.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxMenuButtonFillColor2.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxMenuButtonFillColor2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxMenuButtonFillColor2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxMenuButtonFillColor2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxMenuButtonFillColor2.FormattingEnabled = true;
            this.binaryColorPickerComboBoxMenuButtonFillColor2.Items.AddRange(new object[] {
            "224, 224, 224"});
            this.binaryColorPickerComboBoxMenuButtonFillColor2.Location = new System.Drawing.Point(557, 302);
            this.binaryColorPickerComboBoxMenuButtonFillColor2.Name = "binaryColorPickerComboBoxMenuButtonFillColor2";
            this.binaryColorPickerComboBoxMenuButtonFillColor2.SelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.binaryColorPickerComboBoxMenuButtonFillColor2.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxMenuButtonFillColor2.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxMenuButtonFillColor2.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBoxMenuButtonFillColor2.TabIndex = 34;
            this.binaryColorPickerComboBoxMenuButtonFillColor2.SelectedColorChanged += new System.EventHandler(this.HandleCustomStyleTabPagesOverFlowMenuGlyphActiveRectangleFillColorSelectionChanged);
            // 
            // binaryColorPickerComboBoxMenuButtonBorderColor2
            // 
            this.binaryColorPickerComboBoxMenuButtonBorderColor2.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxMenuButtonBorderColor2.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxMenuButtonBorderColor2.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxMenuButtonBorderColor2.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxMenuButtonBorderColor2.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxMenuButtonBorderColor2.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxMenuButtonBorderColor2.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxMenuButtonBorderColor2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxMenuButtonBorderColor2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxMenuButtonBorderColor2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxMenuButtonBorderColor2.FormattingEnabled = true;
            this.binaryColorPickerComboBoxMenuButtonBorderColor2.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBoxMenuButtonBorderColor2.Location = new System.Drawing.Point(557, 276);
            this.binaryColorPickerComboBoxMenuButtonBorderColor2.Name = "binaryColorPickerComboBoxMenuButtonBorderColor2";
            this.binaryColorPickerComboBoxMenuButtonBorderColor2.SelectedColor = System.Drawing.Color.Black;
            this.binaryColorPickerComboBoxMenuButtonBorderColor2.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxMenuButtonBorderColor2.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxMenuButtonBorderColor2.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBoxMenuButtonBorderColor2.TabIndex = 33;
            this.binaryColorPickerComboBoxMenuButtonBorderColor2.SelectedColorChanged += new System.EventHandler(this.HandleCustomStyleTabPagesOverFlowMenuGlyphActiveRectangleBorderColorChanged);
            // 
            // binaryColorPickerComboBoxMenuButtonColor2
            // 
            this.binaryColorPickerComboBoxMenuButtonColor2.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxMenuButtonColor2.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxMenuButtonColor2.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxMenuButtonColor2.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxMenuButtonColor2.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxMenuButtonColor2.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxMenuButtonColor2.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxMenuButtonColor2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxMenuButtonColor2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxMenuButtonColor2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxMenuButtonColor2.FormattingEnabled = true;
            this.binaryColorPickerComboBoxMenuButtonColor2.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBoxMenuButtonColor2.Location = new System.Drawing.Point(557, 248);
            this.binaryColorPickerComboBoxMenuButtonColor2.Name = "binaryColorPickerComboBoxMenuButtonColor2";
            this.binaryColorPickerComboBoxMenuButtonColor2.SelectedColor = System.Drawing.Color.Black;
            this.binaryColorPickerComboBoxMenuButtonColor2.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxMenuButtonColor2.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxMenuButtonColor2.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBoxMenuButtonColor2.TabIndex = 32;
            this.binaryColorPickerComboBoxMenuButtonColor2.SelectedColorChanged += new System.EventHandler(this.HandleCustomStyleTabPagesOverFlowMenuDropDownColorChanged);
            // 
            // binaryColorPickerComboBoxCloseButtonFillColor2
            // 
            this.binaryColorPickerComboBoxCloseButtonFillColor2.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxCloseButtonFillColor2.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxCloseButtonFillColor2.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxCloseButtonFillColor2.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxCloseButtonFillColor2.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxCloseButtonFillColor2.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxCloseButtonFillColor2.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxCloseButtonFillColor2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxCloseButtonFillColor2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxCloseButtonFillColor2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxCloseButtonFillColor2.FormattingEnabled = true;
            this.binaryColorPickerComboBoxCloseButtonFillColor2.Items.AddRange(new object[] {
            "240, 240, 240"});
            this.binaryColorPickerComboBoxCloseButtonFillColor2.Location = new System.Drawing.Point(217, 246);
            this.binaryColorPickerComboBoxCloseButtonFillColor2.Name = "binaryColorPickerComboBoxCloseButtonFillColor2";
            this.binaryColorPickerComboBoxCloseButtonFillColor2.SelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            this.binaryColorPickerComboBoxCloseButtonFillColor2.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxCloseButtonFillColor2.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxCloseButtonFillColor2.Size = new System.Drawing.Size(130, 22);
            this.binaryColorPickerComboBoxCloseButtonFillColor2.TabIndex = 31;
            this.binaryColorPickerComboBoxCloseButtonFillColor2.SelectedColorChanged += new System.EventHandler(this.HandleCustomStyleTabPageCloseButtonRectangleFillColorChanged);
            // 
            // binaryColorPickerComboBoxCloseButtonBorderColor2
            // 
            this.binaryColorPickerComboBoxCloseButtonBorderColor2.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxCloseButtonBorderColor2.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxCloseButtonBorderColor2.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxCloseButtonBorderColor2.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxCloseButtonBorderColor2.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxCloseButtonBorderColor2.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxCloseButtonBorderColor2.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxCloseButtonBorderColor2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxCloseButtonBorderColor2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxCloseButtonBorderColor2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxCloseButtonBorderColor2.FormattingEnabled = true;
            this.binaryColorPickerComboBoxCloseButtonBorderColor2.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBoxCloseButtonBorderColor2.Location = new System.Drawing.Point(217, 218);
            this.binaryColorPickerComboBoxCloseButtonBorderColor2.Name = "binaryColorPickerComboBoxCloseButtonBorderColor2";
            this.binaryColorPickerComboBoxCloseButtonBorderColor2.SelectedColor = System.Drawing.Color.Black;
            this.binaryColorPickerComboBoxCloseButtonBorderColor2.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxCloseButtonBorderColor2.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxCloseButtonBorderColor2.Size = new System.Drawing.Size(130, 22);
            this.binaryColorPickerComboBoxCloseButtonBorderColor2.TabIndex = 30;
            this.binaryColorPickerComboBoxCloseButtonBorderColor2.SelectedColorChanged += new System.EventHandler(this.HandleCustomStyleTabPageCloseButtonRectangleBorderColorChanged);
            // 
            // binaryColorPickerComboBoxCloseButtonColor2
            // 
            this.binaryColorPickerComboBoxCloseButtonColor2.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxCloseButtonColor2.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxCloseButtonColor2.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxCloseButtonColor2.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxCloseButtonColor2.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxCloseButtonColor2.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxCloseButtonColor2.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxCloseButtonColor2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxCloseButtonColor2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxCloseButtonColor2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxCloseButtonColor2.FormattingEnabled = true;
            this.binaryColorPickerComboBoxCloseButtonColor2.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBoxCloseButtonColor2.Location = new System.Drawing.Point(217, 190);
            this.binaryColorPickerComboBoxCloseButtonColor2.Name = "binaryColorPickerComboBoxCloseButtonColor2";
            this.binaryColorPickerComboBoxCloseButtonColor2.SelectedColor = System.Drawing.Color.Black;
            this.binaryColorPickerComboBoxCloseButtonColor2.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxCloseButtonColor2.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxCloseButtonColor2.Size = new System.Drawing.Size(130, 22);
            this.binaryColorPickerComboBoxCloseButtonColor2.TabIndex = 29;
            this.binaryColorPickerComboBoxCloseButtonColor2.SelectedColorChanged += new System.EventHandler(this.HandleCustomStyleTabPagesCloseButtonColorChanged);
            // 
            // binaryColorPickerComboBoxTabPageBorderColor2
            // 
            this.binaryColorPickerComboBoxTabPageBorderColor2.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxTabPageBorderColor2.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxTabPageBorderColor2.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxTabPageBorderColor2.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxTabPageBorderColor2.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxTabPageBorderColor2.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxTabPageBorderColor2.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxTabPageBorderColor2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxTabPageBorderColor2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxTabPageBorderColor2.Enabled = false;
            this.binaryColorPickerComboBoxTabPageBorderColor2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxTabPageBorderColor2.FormattingEnabled = true;
            this.binaryColorPickerComboBoxTabPageBorderColor2.Items.AddRange(new object[] {
            "144, 175, 226"});
            this.binaryColorPickerComboBoxTabPageBorderColor2.Location = new System.Drawing.Point(217, 103);
            this.binaryColorPickerComboBoxTabPageBorderColor2.Name = "binaryColorPickerComboBoxTabPageBorderColor2";
            this.binaryColorPickerComboBoxTabPageBorderColor2.SelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(175)))), ((int)(((byte)(226)))));
            this.binaryColorPickerComboBoxTabPageBorderColor2.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxTabPageBorderColor2.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxTabPageBorderColor2.Size = new System.Drawing.Size(130, 22);
            this.binaryColorPickerComboBoxTabPageBorderColor2.TabIndex = 28;
            this.binaryColorPickerComboBoxTabPageBorderColor2.SelectedColorChanged += new System.EventHandler(this.HandleCustomStyleTabTabPageBorderColorChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label19.Location = new System.Drawing.Point(395, 254);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(94, 13);
            this.label19.TabIndex = 26;
            this.label19.Text = "Menu button color";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label20.Location = new System.Drawing.Point(36, 193);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(94, 13);
            this.label20.TabIndex = 25;
            this.label20.Text = "Close button color";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Enabled = false;
            this.label21.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label21.Location = new System.Drawing.Point(389, 200);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(82, 13);
            this.label21.TabIndex = 24;
            this.label21.Text = "Sidebar fill color";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label22.Location = new System.Drawing.Point(30, 132);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(136, 13);
            this.label22.TabIndex = 23;
            this.label22.Text = "Tab page Header forecolor";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Enabled = false;
            this.label23.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label23.Location = new System.Drawing.Point(30, 106);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(113, 13);
            this.label23.TabIndex = 22;
            this.label23.Text = "Tab page border color";
            // 
            // chkDrawGapBetweenTabPages2
            // 
            this.chkDrawGapBetweenTabPages2.AutoSize = true;
            this.chkDrawGapBetweenTabPages2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkDrawGapBetweenTabPages2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.chkDrawGapBetweenTabPages2.Location = new System.Drawing.Point(370, 119);
            this.chkDrawGapBetweenTabPages2.Name = "chkDrawGapBetweenTabPages2";
            this.chkDrawGapBetweenTabPages2.Size = new System.Drawing.Size(168, 17);
            this.chkDrawGapBetweenTabPages2.TabIndex = 11;
            this.chkDrawGapBetweenTabPages2.Text = "Draw gap between tab pages";
            this.chkDrawGapBetweenTabPages2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.chkDrawGapBetweenTabPages2.UseVisualStyleBackColor = true;
            this.chkDrawGapBetweenTabPages2.CheckedChanged += new System.EventHandler(this.HandleCustomStyleTabPagesHaveGapBetweenThemOptionChanged);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label24.Location = new System.Drawing.Point(36, 249);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(107, 13);
            this.label24.TabIndex = 21;
            this.label24.Text = "Close button fill color";
            // 
            // chkDrawTabPageOnTopofEachOther2
            // 
            this.chkDrawTabPageOnTopofEachOther2.AutoSize = true;
            this.chkDrawTabPageOnTopofEachOther2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkDrawTabPageOnTopofEachOther2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.chkDrawTabPageOnTopofEachOther2.Location = new System.Drawing.Point(371, 21);
            this.chkDrawTabPageOnTopofEachOther2.Name = "chkDrawTabPageOnTopofEachOther2";
            this.chkDrawTabPageOnTopofEachOther2.Size = new System.Drawing.Size(199, 17);
            this.chkDrawTabPageOnTopofEachOther2.TabIndex = 9;
            this.chkDrawTabPageOnTopofEachOther2.Text = "Draw tab page on top of each other";
            this.chkDrawTabPageOnTopofEachOther2.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.chkDrawTabPageOnTopofEachOther2.UseVisualStyleBackColor = true;
            this.chkDrawTabPageOnTopofEachOther2.CheckedChanged += new System.EventHandler(this.HandleCustomStyleTabDrawTabPageOnTopOfEachOtherOptionChanged);
            // 
            // chkEnableDragDrop2
            // 
            this.chkEnableDragDrop2.AutoSize = true;
            this.chkEnableDragDrop2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkEnableDragDrop2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.chkEnableDragDrop2.Location = new System.Drawing.Point(14, 20);
            this.chkEnableDragDrop2.Name = "chkEnableDragDrop2";
            this.chkEnableDragDrop2.Size = new System.Drawing.Size(173, 17);
            this.chkEnableDragDrop2.TabIndex = 10;
            this.chkEnableDragDrop2.Text = "Enable drag-drop of tab pages";
            this.chkEnableDragDrop2.UseVisualStyleBackColor = true;
            this.chkEnableDragDrop2.CheckedChanged += new System.EventHandler(this.HandleCustomStyleEnableDragAndDropOfTabPagesChanged);
            // 
            // chkShowSideBarOnTabPageHeader
            // 
            this.chkShowSideBarOnTabPageHeader.AutoSize = true;
            this.chkShowSideBarOnTabPageHeader.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkShowSideBarOnTabPageHeader.ForeColor = System.Drawing.SystemColors.WindowText;
            this.chkShowSideBarOnTabPageHeader.Location = new System.Drawing.Point(370, 176);
            this.chkShowSideBarOnTabPageHeader.Name = "chkShowSideBarOnTabPageHeader";
            this.chkShowSideBarOnTabPageHeader.Size = new System.Drawing.Size(188, 17);
            this.chkShowSideBarOnTabPageHeader.TabIndex = 3;
            this.chkShowSideBarOnTabPageHeader.Text = "Show sidebar on tab page header";
            this.chkShowSideBarOnTabPageHeader.UseVisualStyleBackColor = true;
            this.chkShowSideBarOnTabPageHeader.CheckedChanged += new System.EventHandler(this.HandleCustomStyleTabPageHeaderShowsSideBarOptionChanged);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label25.Location = new System.Drawing.Point(36, 221);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(129, 13);
            this.label25.TabIndex = 20;
            this.label25.Text = "Close button border color";
            // 
            // chkShowCloseButton2
            // 
            this.chkShowCloseButton2.AutoSize = true;
            this.chkShowCloseButton2.Checked = true;
            this.chkShowCloseButton2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkShowCloseButton2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkShowCloseButton2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.chkShowCloseButton2.Location = new System.Drawing.Point(16, 166);
            this.chkShowCloseButton2.Name = "chkShowCloseButton2";
            this.chkShowCloseButton2.Size = new System.Drawing.Size(114, 17);
            this.chkShowCloseButton2.TabIndex = 1;
            this.chkShowCloseButton2.Text = "Show close button";
            this.chkShowCloseButton2.UseVisualStyleBackColor = true;
            this.chkShowCloseButton2.CheckedChanged += new System.EventHandler(this.HandleCustomStyleTabShowCloseWindowButtonOptionChanged);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label26.Location = new System.Drawing.Point(395, 307);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(107, 13);
            this.label26.TabIndex = 17;
            this.label26.Text = "Menu button fill color";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label27.Location = new System.Drawing.Point(395, 282);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(129, 13);
            this.label27.TabIndex = 16;
            this.label27.Text = "Menu button border color";
            // 
            // chkShowMenuDropdownButton2
            // 
            this.chkShowMenuDropdownButton2.AutoSize = true;
            this.chkShowMenuDropdownButton2.Checked = true;
            this.chkShowMenuDropdownButton2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkShowMenuDropdownButton2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkShowMenuDropdownButton2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.chkShowMenuDropdownButton2.Location = new System.Drawing.Point(371, 228);
            this.chkShowMenuDropdownButton2.Name = "chkShowMenuDropdownButton2";
            this.chkShowMenuDropdownButton2.Size = new System.Drawing.Size(167, 17);
            this.chkShowMenuDropdownButton2.TabIndex = 2;
            this.chkShowMenuDropdownButton2.Text = "Show menu dropdown button";
            this.chkShowMenuDropdownButton2.UseVisualStyleBackColor = true;
            this.chkShowMenuDropdownButton2.CheckedChanged += new System.EventHandler(this.HandleCustomStyleShowOverflowMenuGlyphOptionChanged);
            // 
            // chkDrawBorderAroundTabStrip2
            // 
            this.chkDrawBorderAroundTabStrip2.AutoSize = true;
            this.chkDrawBorderAroundTabStrip2.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkDrawBorderAroundTabStrip2.ForeColor = System.Drawing.SystemColors.WindowText;
            this.chkDrawBorderAroundTabStrip2.Location = new System.Drawing.Point(14, 78);
            this.chkDrawBorderAroundTabStrip2.Name = "chkDrawBorderAroundTabStrip2";
            this.chkDrawBorderAroundTabStrip2.Size = new System.Drawing.Size(166, 17);
            this.chkDrawBorderAroundTabStrip2.TabIndex = 8;
            this.chkDrawBorderAroundTabStrip2.Text = "Draw border around tab strip";
            this.chkDrawBorderAroundTabStrip2.UseVisualStyleBackColor = true;
            this.chkDrawBorderAroundTabStrip2.CheckedChanged += new System.EventHandler(this.CustomStyleTabDrawBorderAroundTabStripCheckedChanged);
            // 
            // cmbGradientOrientationOnTabPageHeader
            // 
            this.cmbGradientOrientationOnTabPageHeader.FormattingEnabled = true;
            this.cmbGradientOrientationOnTabPageHeader.Items.AddRange(new object[] {
            "Vertical",
            "Horizontal",
            "ForwardDiagonal",
            "BackwardDiagonal"});
            this.cmbGradientOrientationOnTabPageHeader.Location = new System.Drawing.Point(217, 276);
            this.cmbGradientOrientationOnTabPageHeader.Name = "cmbGradientOrientationOnTabPageHeader";
            this.cmbGradientOrientationOnTabPageHeader.Size = new System.Drawing.Size(130, 21);
            this.cmbGradientOrientationOnTabPageHeader.TabIndex = 15;
            this.cmbGradientOrientationOnTabPageHeader.SelectedIndexChanged += new System.EventHandler(this.HandleCustomStyleTabPageHeaderDrawingGradientOrientationSelectionChanged);
            // 
            // numericUpDownEmptySpaceLengthBeforeFirstTabPageHeader2
            // 
            this.numericUpDownEmptySpaceLengthBeforeFirstTabPageHeader2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.numericUpDownEmptySpaceLengthBeforeFirstTabPageHeader2.Location = new System.Drawing.Point(299, 302);
            this.numericUpDownEmptySpaceLengthBeforeFirstTabPageHeader2.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.numericUpDownEmptySpaceLengthBeforeFirstTabPageHeader2.Name = "numericUpDownEmptySpaceLengthBeforeFirstTabPageHeader2";
            this.numericUpDownEmptySpaceLengthBeforeFirstTabPageHeader2.Size = new System.Drawing.Size(48, 21);
            this.numericUpDownEmptySpaceLengthBeforeFirstTabPageHeader2.TabIndex = 14;
            this.numericUpDownEmptySpaceLengthBeforeFirstTabPageHeader2.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.numericUpDownEmptySpaceLengthBeforeFirstTabPageHeader2.ValueChanged += new System.EventHandler(this.HandleCustomStyleEmptySpaceLengthBeforeTheFirstTabPageValueChanged);
            // 
            // numericUpDownGapLengthBetweenTabPageHeader
            // 
            this.numericUpDownGapLengthBetweenTabPageHeader.Enabled = false;
            this.numericUpDownGapLengthBetweenTabPageHeader.Location = new System.Drawing.Point(656, 141);
            this.numericUpDownGapLengthBetweenTabPageHeader.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.numericUpDownGapLengthBetweenTabPageHeader.Name = "numericUpDownGapLengthBetweenTabPageHeader";
            this.numericUpDownGapLengthBetweenTabPageHeader.Size = new System.Drawing.Size(48, 21);
            this.numericUpDownGapLengthBetweenTabPageHeader.TabIndex = 13;
            this.numericUpDownGapLengthBetweenTabPageHeader.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.numericUpDownGapLengthBetweenTabPageHeader.ValueChanged += new System.EventHandler(this.HandleTabControlGapLengthBetweenTabPageHeaderValueChanged);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label28.Location = new System.Drawing.Point(13, 306);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(254, 13);
            this.label28.TabIndex = 7;
            this.label28.Text = "Emptyspace length before the first tabpage header";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Enabled = false;
            this.label29.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label29.Location = new System.Drawing.Point(388, 143);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(186, 13);
            this.label29.TabIndex = 6;
            this.label29.Text = "Gaplength between tabpage headers";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label30.Location = new System.Drawing.Point(13, 280);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(200, 13);
            this.label30.TabIndex = 5;
            this.label30.Text = "Gradient orientation for tabpage header";
            // 
            // binaryPowerTabStripUsingCustomStyle
            // 
            this.binaryPowerTabStripUsingCustomStyle.Cursor = System.Windows.Forms.Cursors.Default;
            this.binaryPowerTabStripUsingCustomStyle.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabStripUsingCustomStyle.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabStripUsingCustomStyle.DrawBorderAroundTabStrip = false;
            this.binaryPowerTabStripUsingCustomStyle.DrawTabPageOnTopOfEachOther = false;
            this.binaryPowerTabStripUsingCustomStyle.EmptySpaceLengthBeforeTheFirstTabPage = 8;
            this.binaryPowerTabStripUsingCustomStyle.EnableAutomaticUpdateOfTabPagesHeaderSize = false;
            this.binaryPowerTabStripUsingCustomStyle.EnableControlledLayoutRendering = false;
            this.binaryPowerTabStripUsingCustomStyle.EnableDragAndDropOfTabPages = false;
            this.binaryPowerTabStripUsingCustomStyle.EnableTabPageLevelCloseButtonRendering = true;
            this.binaryPowerTabStripUsingCustomStyle.ExtendedWindowsXPRenderingFirstColor = System.Drawing.Color.Blue;
            this.binaryPowerTabStripUsingCustomStyle.ExtendedWindowsXPRenderingSecondColor = System.Drawing.Color.LightBlue;
            this.binaryPowerTabStripUsingCustomStyle.Font = new System.Drawing.Font("Tahoma", 8.25F);
            this.binaryPowerTabStripUsingCustomStyle.HeaderFont = null;
            this.binaryPowerTabStripUsingCustomStyle.HeaderTextCloseButtonExtraGap = 8;
            this.binaryPowerTabStripUsingCustomStyle.IsBackgroundTransparent = false;
            this.binaryPowerTabStripUsingCustomStyle.KeepShowingTooltipEvenWhenMousePointerIsMoving = false;
            this.binaryPowerTabStripUsingCustomStyle.Location = new System.Drawing.Point(16, 6);
            this.binaryPowerTabStripUsingCustomStyle.Name = "binaryPowerTabStripUsingCustomStyle";
            this.binaryPowerTabStripUsingCustomStyle.NewlyAddedPagesAreLocatedAtLeftCorner = false;
            this.binaryPowerTabStripUsingCustomStyle.PreventInvalidation = false;
            this.binaryPowerTabStripUsingCustomStyle.RenderFullTextForTabPageHeader = false;
            this.binaryPowerTabStripUsingCustomStyle.SelectedPageHeaderTextIsRenderedBold = true;
            this.binaryPowerTabStripUsingCustomStyle.ShouldAutoSizeTabs = false;
            this.binaryPowerTabStripUsingCustomStyle.ShowToolTip = true;
            this.binaryPowerTabStripUsingCustomStyle.Size = new System.Drawing.Size(722, 174);
            this.binaryPowerTabStripUsingCustomStyle.TabBottomOrientationCloseButtonPosition = Binarymission.WinForms.Controls.TabControls.CloseButtonPosition.Bottom;
            stringFormat3.Alignment = System.Drawing.StringAlignment.Center;
            stringFormat3.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat3.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat3.Trimming = System.Drawing.StringTrimming.EllipsisCharacter;
            this.binaryPowerTabStripUsingCustomStyle.TabHeaderStringFormat = stringFormat3;
            this.binaryPowerTabStripUsingCustomStyle.TabIndex = 1;
            this.binaryPowerTabStripUsingCustomStyle.TabPageBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(144)))), ((int)(((byte)(175)))), ((int)(((byte)(226)))));
            this.binaryPowerTabStripUsingCustomStyle.TabPageCloseButtonMouseEnterColor = System.Drawing.Color.Red;
            this.binaryPowerTabStripUsingCustomStyle.TabPageCloseButtonRectangleBorderColor = System.Drawing.Color.Black;
            this.binaryPowerTabStripUsingCustomStyle.TabPageCloseButtonRectangleFillColor = System.Drawing.SystemColors.Control;
            this.binaryPowerTabStripUsingCustomStyle.TabPageCurrentSelectionIndicatorEndColor = System.Drawing.Color.White;
            this.binaryPowerTabStripUsingCustomStyle.TabPageCurrentSelectionIndicatorStartColor = System.Drawing.Color.Green;
            this.binaryPowerTabStripUsingCustomStyle.TabPageHeaderDrawingGradientOrientation = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.binaryPowerTabStripUsingCustomStyle.TabPageHeaderForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabStripUsingCustomStyle.TabPageHeaderHeight = 30;
            this.binaryPowerTabStripUsingCustomStyle.TabPageHeaderShowsSideBar = false;
            this.binaryPowerTabStripUsingCustomStyle.TabPageHeaderTextFontOverridesControlDefault = false;
            this.binaryPowerTabStripUsingCustomStyle.TabPageHeaderWidth = 150;
            this.binaryPowerTabStripUsingCustomStyle.TabPages.AddRange(new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage[] {
            this.binaryPowerTabPage_Custom_Welcome,
            this.binaryPowerTabPage_Custom_UserManagement,
            this.binaryPowerTabPage_Custom_DatabaseReplication,
            this.binaryPowerTabPage_Custom_CustomerMeetings,
            this.binaryPowerTabPage_Custom_EmailArchives});
            this.binaryPowerTabStripUsingCustomStyle.TabPagesCloseButtonColor = System.Drawing.Color.Black;
            this.binaryPowerTabStripUsingCustomStyle.TabPagesHaveGapBetweenThem = false;
            this.binaryPowerTabStripUsingCustomStyle.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabStripUsingCustomStyle.TabPagesOverFlowMenuDropDownColor = System.Drawing.SystemColors.ControlText;
            this.binaryPowerTabStripUsingCustomStyle.TabPagesOverFlowMenuGlyphActiveRectangleBorderColor = System.Drawing.SystemColors.ControlText;
            this.binaryPowerTabStripUsingCustomStyle.TabPagesOverFlowMenuGlyphActiveRectangleFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.binaryPowerTabStripUsingCustomStyle.TabPagesRenderingLocation = Binarymission.WinForms.Controls.TabControls.TabPagesRenderingLocation.Top;
            this.binaryPowerTabStripUsingCustomStyle.TabRenderingStyle = Binarymission.WinForms.Controls.TabControls.RenderingStyle.Custom;
            this.binaryPowerTabStripUsingCustomStyle.TabsOverflowMode = Binarymission.WinForms.Controls.TabControls.OverflowMode.MultiLine;
            this.binaryPowerTabStripUsingCustomStyle.Text = "binaryPowerTabStrip5";
            this.binaryPowerTabStripUsingCustomStyle.ThemeBorderColorCanBeOverridden = false;
            this.binaryPowerTabStripUsingCustomStyle.ToolTipConfiguration.AutomaticDelay = 500;
            this.binaryPowerTabStripUsingCustomStyle.ToolTipConfiguration.AutoPopDelay = 5000;
            this.binaryPowerTabStripUsingCustomStyle.ToolTipConfiguration.BackColor = System.Drawing.SystemColors.Info;
            this.binaryPowerTabStripUsingCustomStyle.ToolTipConfiguration.ForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabStripUsingCustomStyle.ToolTipConfiguration.InitialDelay = 500;
            this.binaryPowerTabStripUsingCustomStyle.ToolTipConfiguration.IsBalloon = false;
            this.binaryPowerTabStripUsingCustomStyle.ToolTipConfiguration.ReshowDelay = 100;
            this.binaryPowerTabStripUsingCustomStyle.ToolTipConfiguration.StripAmpersands = false;
            this.binaryPowerTabStripUsingCustomStyle.ToolTipConfiguration.ToolTipIcon = System.Windows.Forms.ToolTipIcon.None;
            this.binaryPowerTabStripUsingCustomStyle.ToolTipConfiguration.ToolTipTitle = "";
            this.binaryPowerTabStripUsingCustomStyle.ToolTipConfiguration.UseAnimation = false;
            this.binaryPowerTabStripUsingCustomStyle.ToolTipConfiguration.UseFading = false;
            this.binaryPowerTabStripUsingCustomStyle.UseTabCurrentSelectionIndicatorColor = false;
            // 
            // binaryPowerTabPage_Custom_Welcome
            // 
            this.binaryPowerTabPage_Custom_Welcome.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage_Custom_Welcome.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(181)))), ((int)(((byte)(226)))));
            this.binaryPowerTabPage_Custom_Welcome.BorderSize = 1;
            this.binaryPowerTabPage_Custom_Welcome.Controls.Add(this.panel3);
            this.binaryPowerTabPage_Custom_Welcome.CustomEndColor = System.Drawing.Color.FromArgb(((int)(((byte)(146)))), ((int)(((byte)(222)))), ((int)(((byte)(186)))));
            this.binaryPowerTabPage_Custom_Welcome.CustomStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(238)))), ((int)(((byte)(219)))));
            this.binaryPowerTabPage_Custom_Welcome.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage_Custom_Welcome.Image = ((System.Drawing.Image)(resources.GetObject("binaryPowerTabPage_Custom_Welcome.Image")));
            this.binaryPowerTabPage_Custom_Welcome.IsBackgroundTransparent = false;
            this.binaryPowerTabPage_Custom_Welcome.IsHeaderEnabled = true;
            this.binaryPowerTabPage_Custom_Welcome.Name = "binaryPowerTabPage_Custom_Welcome";
            this.binaryPowerTabPage_Custom_Welcome.Size = new System.Drawing.Size(720, 113);
            this.binaryPowerTabPage_Custom_Welcome.TabIndex = 0;
            this.binaryPowerTabPage_Custom_Welcome.TabPageContentIsDirty = false;
            this.binaryPowerTabPage_Custom_Welcome.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage_Custom_Welcome.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage_Custom_Welcome.Text = "Welcome";
            this.binaryPowerTabPage_Custom_Welcome.ToolTipText = "";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.Window;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.binaryColorPickerComboBox12);
            this.panel3.Controls.Add(this.label41);
            this.panel3.Controls.Add(this.label64);
            this.panel3.Controls.Add(this.binaryColorPickerComboBoxTabPageHeaderEndColor);
            this.panel3.Controls.Add(this.label56);
            this.panel3.Controls.Add(this.binaryColorPickerComboBox19);
            this.panel3.Controls.Add(this.binaryColorPickerComboBoxTabPageHeaderstartcolor);
            this.panel3.Controls.Add(this.binaryColorPickerComboBox20);
            this.panel3.Controls.Add(this.label42);
            this.panel3.Controls.Add(this.label18);
            this.panel3.Controls.Add(this.label43);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(720, 113);
            this.panel3.TabIndex = 56;
            // 
            // binaryColorPickerComboBox12
            // 
            this.binaryColorPickerComboBox12.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox12.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox12.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox12.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox12.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox12.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox12.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox12.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox12.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox12.FormattingEnabled = true;
            this.binaryColorPickerComboBox12.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBox12.Location = new System.Drawing.Point(527, 78);
            this.binaryColorPickerComboBox12.Name = "binaryColorPickerComboBox12";
            this.binaryColorPickerComboBox12.SelectedColor = System.Drawing.Color.Black;
            this.binaryColorPickerComboBox12.ShowBorderAlways = true;
            this.binaryColorPickerComboBox12.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox12.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox12.TabIndex = 42;
            this.binaryColorPickerComboBox12.SelectedColorChanged += new System.EventHandler(this.HandleCustomWelcomeTabPageHeaderForeColorChanged);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(241, 7);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(190, 13);
            this.label41.TabIndex = 55;
            this.label41.Text = "This is the \"Welcome\"  tab page.";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label64.Location = new System.Drawing.Point(350, 83);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(135, 13);
            this.label64.TabIndex = 41;
            this.label64.Text = "Tab page header forecolor";
            // 
            // binaryColorPickerComboBoxTabPageHeaderEndColor
            // 
            this.binaryColorPickerComboBoxTabPageHeaderEndColor.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxTabPageHeaderEndColor.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxTabPageHeaderEndColor.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxTabPageHeaderEndColor.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxTabPageHeaderEndColor.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxTabPageHeaderEndColor.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxTabPageHeaderEndColor.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxTabPageHeaderEndColor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxTabPageHeaderEndColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxTabPageHeaderEndColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxTabPageHeaderEndColor.FormattingEnabled = true;
            this.binaryColorPickerComboBoxTabPageHeaderEndColor.Items.AddRange(new object[] {
            "146, 222, 186"});
            this.binaryColorPickerComboBoxTabPageHeaderEndColor.Location = new System.Drawing.Point(527, 53);
            this.binaryColorPickerComboBoxTabPageHeaderEndColor.Name = "binaryColorPickerComboBoxTabPageHeaderEndColor";
            this.binaryColorPickerComboBoxTabPageHeaderEndColor.SelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(146)))), ((int)(((byte)(222)))), ((int)(((byte)(186)))));
            this.binaryColorPickerComboBoxTabPageHeaderEndColor.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxTabPageHeaderEndColor.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxTabPageHeaderEndColor.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBoxTabPageHeaderEndColor.TabIndex = 39;
            this.binaryColorPickerComboBoxTabPageHeaderEndColor.SelectedColorChanged += new System.EventHandler(this.HandleCustleTabWelcomeCustomEndColorChanged);
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label56.Location = new System.Drawing.Point(350, 58);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(136, 13);
            this.label56.TabIndex = 37;
            this.label56.Text = "Tab page header end color";
            // 
            // binaryColorPickerComboBox19
            // 
            this.binaryColorPickerComboBox19.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox19.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox19.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox19.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox19.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox19.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox19.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox19.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox19.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox19.FormattingEnabled = true;
            this.binaryColorPickerComboBox19.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBox19.Location = new System.Drawing.Point(527, 28);
            this.binaryColorPickerComboBox19.Name = "binaryColorPickerComboBox19";
            this.binaryColorPickerComboBox19.SelectedColor = System.Drawing.Color.Black;
            this.binaryColorPickerComboBox19.ShowBorderAlways = true;
            this.binaryColorPickerComboBox19.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox19.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox19.TabIndex = 54;
            this.binaryColorPickerComboBox19.SelectedColorChanged += new System.EventHandler(this.HandleCustomStyledTabWelcomeTabPageChildrenForecolorChanged);
            // 
            // binaryColorPickerComboBoxTabPageHeaderstartcolor
            // 
            this.binaryColorPickerComboBoxTabPageHeaderstartcolor.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBoxTabPageHeaderstartcolor.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBoxTabPageHeaderstartcolor.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBoxTabPageHeaderstartcolor.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBoxTabPageHeaderstartcolor.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBoxTabPageHeaderstartcolor.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxTabPageHeaderstartcolor.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBoxTabPageHeaderstartcolor.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBoxTabPageHeaderstartcolor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBoxTabPageHeaderstartcolor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBoxTabPageHeaderstartcolor.FormattingEnabled = true;
            this.binaryColorPickerComboBoxTabPageHeaderstartcolor.Items.AddRange(new object[] {
            "198, 238, 219"});
            this.binaryColorPickerComboBoxTabPageHeaderstartcolor.Location = new System.Drawing.Point(204, 56);
            this.binaryColorPickerComboBoxTabPageHeaderstartcolor.Name = "binaryColorPickerComboBoxTabPageHeaderstartcolor";
            this.binaryColorPickerComboBoxTabPageHeaderstartcolor.SelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(238)))), ((int)(((byte)(219)))));
            this.binaryColorPickerComboBoxTabPageHeaderstartcolor.ShowBorderAlways = true;
            this.binaryColorPickerComboBoxTabPageHeaderstartcolor.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBoxTabPageHeaderstartcolor.Size = new System.Drawing.Size(130, 22);
            this.binaryColorPickerComboBoxTabPageHeaderstartcolor.TabIndex = 38;
            this.binaryColorPickerComboBoxTabPageHeaderstartcolor.SelectedColorChanged += new System.EventHandler(this.HandleCustleTabWelcomeCustomStartColorChanged);
            // 
            // binaryColorPickerComboBox20
            // 
            this.binaryColorPickerComboBox20.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox20.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox20.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox20.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox20.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox20.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox20.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox20.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox20.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox20.FormattingEnabled = true;
            this.binaryColorPickerComboBox20.Items.AddRange(new object[] {
            "255, 255, 255"});
            this.binaryColorPickerComboBox20.Location = new System.Drawing.Point(204, 31);
            this.binaryColorPickerComboBox20.Name = "binaryColorPickerComboBox20";
            this.binaryColorPickerComboBox20.SelectedColor = System.Drawing.Color.White;
            this.binaryColorPickerComboBox20.ShowBorderAlways = true;
            this.binaryColorPickerComboBox20.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox20.Size = new System.Drawing.Size(130, 22);
            this.binaryColorPickerComboBox20.TabIndex = 52;
            this.binaryColorPickerComboBox20.SelectedColorChanged += new System.EventHandler(this.HandleCustomStyleTabWelcomeTabPageBackcolorChanged);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label42.Location = new System.Drawing.Point(350, 33);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(98, 13);
            this.label42.TabIndex = 53;
            this.label42.Text = "Tab page forecolor";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label18.Location = new System.Drawing.Point(16, 58);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(141, 13);
            this.label18.TabIndex = 36;
            this.label18.Text = "Tab page header start color";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label43.Location = new System.Drawing.Point(16, 33);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(100, 13);
            this.label43.TabIndex = 51;
            this.label43.Text = "Tab page backcolor";
            // 
            // binaryPowerTabPage_Custom_UserManagement
            // 
            this.binaryPowerTabPage_Custom_UserManagement.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage_Custom_UserManagement.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.binaryPowerTabPage_Custom_UserManagement.BorderSize = 1;
            this.binaryPowerTabPage_Custom_UserManagement.Controls.Add(this.panel6);
            this.binaryPowerTabPage_Custom_UserManagement.CustomEndColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(169)))), ((int)(((byte)(225)))));
            this.binaryPowerTabPage_Custom_UserManagement.CustomStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(210)))), ((int)(((byte)(238)))));
            this.binaryPowerTabPage_Custom_UserManagement.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage_Custom_UserManagement.Image = ((System.Drawing.Image)(resources.GetObject("binaryPowerTabPage_Custom_UserManagement.Image")));
            this.binaryPowerTabPage_Custom_UserManagement.IsBackgroundTransparent = false;
            this.binaryPowerTabPage_Custom_UserManagement.IsHeaderEnabled = true;
            this.binaryPowerTabPage_Custom_UserManagement.Name = "binaryPowerTabPage_Custom_UserManagement";
            this.binaryPowerTabPage_Custom_UserManagement.Size = new System.Drawing.Size(720, 113);
            this.binaryPowerTabPage_Custom_UserManagement.TabIndex = 1;
            this.binaryPowerTabPage_Custom_UserManagement.TabPageContentIsDirty = false;
            this.binaryPowerTabPage_Custom_UserManagement.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage_Custom_UserManagement.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage_Custom_UserManagement.Text = "User Management";
            this.binaryPowerTabPage_Custom_UserManagement.ToolTipText = "";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.Window;
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.binaryColorPickerComboBox30);
            this.panel6.Controls.Add(this.binaryColorPickerComboBox10);
            this.panel6.Controls.Add(this.label66);
            this.panel6.Controls.Add(this.label52);
            this.panel6.Controls.Add(this.label62);
            this.panel6.Controls.Add(this.binaryColorPickerComboBox21);
            this.panel6.Controls.Add(this.binaryColorPickerComboBox11);
            this.panel6.Controls.Add(this.binaryColorPickerComboBox22);
            this.panel6.Controls.Add(this.label63);
            this.panel6.Controls.Add(this.label45);
            this.panel6.Controls.Add(this.label44);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(720, 113);
            this.panel6.TabIndex = 60;
            // 
            // binaryColorPickerComboBox30
            // 
            this.binaryColorPickerComboBox30.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox30.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox30.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox30.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox30.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox30.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox30.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox30.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox30.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox30.FormattingEnabled = true;
            this.binaryColorPickerComboBox30.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBox30.Location = new System.Drawing.Point(516, 77);
            this.binaryColorPickerComboBox30.Name = "binaryColorPickerComboBox30";
            this.binaryColorPickerComboBox30.SelectedColor = System.Drawing.Color.Black;
            this.binaryColorPickerComboBox30.ShowBorderAlways = true;
            this.binaryColorPickerComboBox30.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox30.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox30.TabIndex = 44;
            this.binaryColorPickerComboBox30.SelectedColorChanged += new System.EventHandler(this.HandleCustomUserManagementTabPageHeaderForeColorChanged);
            // 
            // binaryColorPickerComboBox10
            // 
            this.binaryColorPickerComboBox10.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox10.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox10.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox10.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox10.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox10.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox10.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox10.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox10.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox10.FormattingEnabled = true;
            this.binaryColorPickerComboBox10.Items.AddRange(new object[] {
            "130, 169, 225"});
            this.binaryColorPickerComboBox10.Location = new System.Drawing.Point(516, 50);
            this.binaryColorPickerComboBox10.Name = "binaryColorPickerComboBox10";
            this.binaryColorPickerComboBox10.SelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(130)))), ((int)(((byte)(169)))), ((int)(((byte)(225)))));
            this.binaryColorPickerComboBox10.ShowBorderAlways = true;
            this.binaryColorPickerComboBox10.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox10.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox10.TabIndex = 43;
            this.binaryColorPickerComboBox10.SelectedColorChanged += new System.EventHandler(this.HandleCustomUserManagementCustomEndColorChanged);
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label66.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label66.Location = new System.Drawing.Point(360, 83);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(135, 13);
            this.label66.TabIndex = 43;
            this.label66.Text = "Tab page header forecolor";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(229, 7);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(242, 13);
            this.label52.TabIndex = 59;
            this.label52.Text = "This is the \"User Management\"  tab page.";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label62.Location = new System.Drawing.Point(360, 56);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(136, 13);
            this.label62.TabIndex = 41;
            this.label62.Text = "Tab page header end color";
            // 
            // binaryColorPickerComboBox21
            // 
            this.binaryColorPickerComboBox21.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox21.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox21.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox21.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox21.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox21.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox21.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox21.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox21.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox21.FormattingEnabled = true;
            this.binaryColorPickerComboBox21.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBox21.Location = new System.Drawing.Point(516, 25);
            this.binaryColorPickerComboBox21.Name = "binaryColorPickerComboBox21";
            this.binaryColorPickerComboBox21.SelectedColor = System.Drawing.Color.Black;
            this.binaryColorPickerComboBox21.ShowBorderAlways = true;
            this.binaryColorPickerComboBox21.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox21.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox21.TabIndex = 58;
            this.binaryColorPickerComboBox21.SelectedColorChanged += new System.EventHandler(this.HandleCustomStyledTabUserManagementTabPageChildrenForecolorChanged);
            // 
            // binaryColorPickerComboBox11
            // 
            this.binaryColorPickerComboBox11.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox11.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox11.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox11.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox11.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox11.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox11.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox11.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox11.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox11.FormattingEnabled = true;
            this.binaryColorPickerComboBox11.Items.AddRange(new object[] {
            "193, 210, 238"});
            this.binaryColorPickerComboBox11.Location = new System.Drawing.Point(165, 56);
            this.binaryColorPickerComboBox11.Name = "binaryColorPickerComboBox11";
            this.binaryColorPickerComboBox11.SelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(210)))), ((int)(((byte)(238)))));
            this.binaryColorPickerComboBox11.ShowBorderAlways = true;
            this.binaryColorPickerComboBox11.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox11.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox11.TabIndex = 42;
            this.binaryColorPickerComboBox11.SelectedColorChanged += new System.EventHandler(this.HandleCustomUserManagementCustomStartColorChanged);
            // 
            // binaryColorPickerComboBox22
            // 
            this.binaryColorPickerComboBox22.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox22.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox22.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox22.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox22.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox22.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox22.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox22.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox22.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox22.FormattingEnabled = true;
            this.binaryColorPickerComboBox22.Items.AddRange(new object[] {
            "255, 255, 255"});
            this.binaryColorPickerComboBox22.Location = new System.Drawing.Point(165, 31);
            this.binaryColorPickerComboBox22.Name = "binaryColorPickerComboBox22";
            this.binaryColorPickerComboBox22.SelectedColor = System.Drawing.Color.White;
            this.binaryColorPickerComboBox22.ShowBorderAlways = true;
            this.binaryColorPickerComboBox22.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox22.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox22.TabIndex = 56;
            this.binaryColorPickerComboBox22.SelectedColorChanged += new System.EventHandler(this.HandleCustomUserManagementBackColorChanged);
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label63.Location = new System.Drawing.Point(12, 59);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(141, 13);
            this.label63.TabIndex = 40;
            this.label63.Text = "Tab page header start color";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label45.Location = new System.Drawing.Point(12, 34);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(100, 13);
            this.label45.TabIndex = 55;
            this.label45.Text = "Tab page backcolor";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label44.Location = new System.Drawing.Point(360, 31);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(98, 13);
            this.label44.TabIndex = 57;
            this.label44.Text = "Tab page forecolor";
            // 
            // binaryPowerTabPage_Custom_DatabaseReplication
            // 
            this.binaryPowerTabPage_Custom_DatabaseReplication.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage_Custom_DatabaseReplication.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.binaryPowerTabPage_Custom_DatabaseReplication.BorderSize = 1;
            this.binaryPowerTabPage_Custom_DatabaseReplication.Controls.Add(this.panel7);
            this.binaryPowerTabPage_Custom_DatabaseReplication.CurrentlySelected = true;
            this.binaryPowerTabPage_Custom_DatabaseReplication.CustomEndColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(164)))), ((int)(((byte)(164)))));
            this.binaryPowerTabPage_Custom_DatabaseReplication.CustomStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(217)))), ((int)(((byte)(217)))));
            this.binaryPowerTabPage_Custom_DatabaseReplication.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage_Custom_DatabaseReplication.Image = ((System.Drawing.Image)(resources.GetObject("binaryPowerTabPage_Custom_DatabaseReplication.Image")));
            this.binaryPowerTabPage_Custom_DatabaseReplication.IsBackgroundTransparent = false;
            this.binaryPowerTabPage_Custom_DatabaseReplication.IsHeaderEnabled = true;
            this.binaryPowerTabPage_Custom_DatabaseReplication.Name = "binaryPowerTabPage_Custom_DatabaseReplication";
            this.binaryPowerTabPage_Custom_DatabaseReplication.Size = new System.Drawing.Size(720, 113);
            this.binaryPowerTabPage_Custom_DatabaseReplication.TabIndex = 2;
            this.binaryPowerTabPage_Custom_DatabaseReplication.TabPageContentIsDirty = false;
            this.binaryPowerTabPage_Custom_DatabaseReplication.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage_Custom_DatabaseReplication.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage_Custom_DatabaseReplication.Text = "Database Replication";
            this.binaryPowerTabPage_Custom_DatabaseReplication.ToolTipText = "";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.Window;
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.binaryColorPickerComboBox34);
            this.panel7.Controls.Add(this.label55);
            this.panel7.Controls.Add(this.binaryColorPickerComboBox35);
            this.panel7.Controls.Add(this.binaryColorPickerComboBox25);
            this.panel7.Controls.Add(this.label70);
            this.panel7.Controls.Add(this.binaryColorPickerComboBox26);
            this.panel7.Controls.Add(this.label71);
            this.panel7.Controls.Add(this.label49);
            this.panel7.Controls.Add(this.binaryColorPickerComboBox36);
            this.panel7.Controls.Add(this.label72);
            this.panel7.Controls.Add(this.label48);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(720, 113);
            this.panel7.TabIndex = 60;
            // 
            // binaryColorPickerComboBox34
            // 
            this.binaryColorPickerComboBox34.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox34.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox34.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox34.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox34.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox34.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox34.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox34.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox34.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox34.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox34.FormattingEnabled = true;
            this.binaryColorPickerComboBox34.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBox34.Location = new System.Drawing.Point(521, 79);
            this.binaryColorPickerComboBox34.Name = "binaryColorPickerComboBox34";
            this.binaryColorPickerComboBox34.SelectedColor = System.Drawing.Color.Black;
            this.binaryColorPickerComboBox34.ShowBorderAlways = true;
            this.binaryColorPickerComboBox34.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox34.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox34.TabIndex = 56;
            this.binaryColorPickerComboBox34.SelectedColorChanged += new System.EventHandler(this.HandleCustomDatabaseReplicationTabPageHeaderForeColorChanged);
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(251, 8);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(258, 13);
            this.label55.TabIndex = 59;
            this.label55.Text = "This is the \"Database Replication\"  tab page.";
            // 
            // binaryColorPickerComboBox35
            // 
            this.binaryColorPickerComboBox35.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox35.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox35.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox35.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox35.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox35.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox35.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox35.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox35.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox35.FormattingEnabled = true;
            this.binaryColorPickerComboBox35.Items.AddRange(new object[] {
            "255, 164, 164"});
            this.binaryColorPickerComboBox35.Location = new System.Drawing.Point(521, 53);
            this.binaryColorPickerComboBox35.Name = "binaryColorPickerComboBox35";
            this.binaryColorPickerComboBox35.SelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(164)))), ((int)(((byte)(164)))));
            this.binaryColorPickerComboBox35.ShowBorderAlways = true;
            this.binaryColorPickerComboBox35.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox35.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox35.TabIndex = 54;
            this.binaryColorPickerComboBox35.SelectedColorChanged += new System.EventHandler(this.HandleCustomDatabaseReplicationCustomEndColorChanged);
            // 
            // binaryColorPickerComboBox25
            // 
            this.binaryColorPickerComboBox25.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox25.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox25.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox25.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox25.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox25.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox25.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox25.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox25.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox25.FormattingEnabled = true;
            this.binaryColorPickerComboBox25.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBox25.Location = new System.Drawing.Point(521, 26);
            this.binaryColorPickerComboBox25.Name = "binaryColorPickerComboBox25";
            this.binaryColorPickerComboBox25.SelectedColor = System.Drawing.Color.Black;
            this.binaryColorPickerComboBox25.ShowBorderAlways = true;
            this.binaryColorPickerComboBox25.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox25.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox25.TabIndex = 58;
            this.binaryColorPickerComboBox25.SelectedColorChanged += new System.EventHandler(this.HandleCustomStyleTabDatabaseReplicationTabPageForecolorChanged);
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label70.Location = new System.Drawing.Point(365, 86);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(135, 13);
            this.label70.TabIndex = 55;
            this.label70.Text = "Tab page header forecolor";
            // 
            // binaryColorPickerComboBox26
            // 
            this.binaryColorPickerComboBox26.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox26.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox26.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox26.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox26.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox26.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox26.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox26.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox26.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox26.FormattingEnabled = true;
            this.binaryColorPickerComboBox26.Items.AddRange(new object[] {
            "255, 255, 255"});
            this.binaryColorPickerComboBox26.Location = new System.Drawing.Point(170, 30);
            this.binaryColorPickerComboBox26.Name = "binaryColorPickerComboBox26";
            this.binaryColorPickerComboBox26.SelectedColor = System.Drawing.Color.White;
            this.binaryColorPickerComboBox26.ShowBorderAlways = true;
            this.binaryColorPickerComboBox26.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox26.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox26.TabIndex = 56;
            this.binaryColorPickerComboBox26.SelectedColorChanged += new System.EventHandler(this.HandleCustomStyleTabDatabaseReplicationBackColorChanged);
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label71.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label71.Location = new System.Drawing.Point(365, 59);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(136, 13);
            this.label71.TabIndex = 52;
            this.label71.Text = "Tab page header end color";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label49.Location = new System.Drawing.Point(17, 33);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(100, 13);
            this.label49.TabIndex = 55;
            this.label49.Text = "Tab page backcolor";
            // 
            // binaryColorPickerComboBox36
            // 
            this.binaryColorPickerComboBox36.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox36.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox36.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox36.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox36.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox36.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox36.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox36.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox36.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox36.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox36.FormattingEnabled = true;
            this.binaryColorPickerComboBox36.Items.AddRange(new object[] {
            "255, 217, 217"});
            this.binaryColorPickerComboBox36.Location = new System.Drawing.Point(170, 58);
            this.binaryColorPickerComboBox36.Name = "binaryColorPickerComboBox36";
            this.binaryColorPickerComboBox36.SelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(217)))), ((int)(((byte)(217)))));
            this.binaryColorPickerComboBox36.ShowBorderAlways = true;
            this.binaryColorPickerComboBox36.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox36.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox36.TabIndex = 53;
            this.binaryColorPickerComboBox36.SelectedColorChanged += new System.EventHandler(this.HandleCustomDatabaseReplicationCustomStartColorChanged);
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label72.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label72.Location = new System.Drawing.Point(17, 61);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(141, 13);
            this.label72.TabIndex = 51;
            this.label72.Text = "Tab page header start color";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label48.Location = new System.Drawing.Point(369, 31);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(98, 13);
            this.label48.TabIndex = 57;
            this.label48.Text = "Tab page forecolor";
            // 
            // binaryPowerTabPage_Custom_CustomerMeetings
            // 
            this.binaryPowerTabPage_Custom_CustomerMeetings.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage_Custom_CustomerMeetings.BorderColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabPage_Custom_CustomerMeetings.BorderSize = 1;
            this.binaryPowerTabPage_Custom_CustomerMeetings.Controls.Add(this.panel9);
            this.binaryPowerTabPage_Custom_CustomerMeetings.Controls.Add(this.binaryColorPickerComboBox31);
            this.binaryPowerTabPage_Custom_CustomerMeetings.CustomEndColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(253)))), ((int)(((byte)(181)))));
            this.binaryPowerTabPage_Custom_CustomerMeetings.CustomStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(254)))), ((int)(((byte)(221)))));
            this.binaryPowerTabPage_Custom_CustomerMeetings.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage_Custom_CustomerMeetings.Image = ((System.Drawing.Image)(resources.GetObject("binaryPowerTabPage_Custom_CustomerMeetings.Image")));
            this.binaryPowerTabPage_Custom_CustomerMeetings.IsBackgroundTransparent = false;
            this.binaryPowerTabPage_Custom_CustomerMeetings.IsHeaderEnabled = true;
            this.binaryPowerTabPage_Custom_CustomerMeetings.Name = "binaryPowerTabPage_Custom_CustomerMeetings";
            this.binaryPowerTabPage_Custom_CustomerMeetings.Size = new System.Drawing.Size(720, 113);
            this.binaryPowerTabPage_Custom_CustomerMeetings.TabIndex = 3;
            this.binaryPowerTabPage_Custom_CustomerMeetings.TabPageContentIsDirty = false;
            this.binaryPowerTabPage_Custom_CustomerMeetings.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage_Custom_CustomerMeetings.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage_Custom_CustomerMeetings.Text = "Customer Meetings";
            this.binaryPowerTabPage_Custom_CustomerMeetings.ToolTipText = "";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.SystemColors.Window;
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.label54);
            this.panel9.Controls.Add(this.binaryColorPickerComboBox32);
            this.panel9.Controls.Add(this.binaryColorPickerComboBox27);
            this.panel9.Controls.Add(this.binaryColorPickerComboBox28);
            this.panel9.Controls.Add(this.label68);
            this.panel9.Controls.Add(this.label51);
            this.panel9.Controls.Add(this.binaryColorPickerComboBox33);
            this.panel9.Controls.Add(this.label69);
            this.panel9.Controls.Add(this.label50);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(0, 0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(720, 113);
            this.panel9.TabIndex = 60;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(245, 9);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(248, 13);
            this.label54.TabIndex = 59;
            this.label54.Text = "This is the \"Customer Meetings\"  tab page.";
            // 
            // binaryColorPickerComboBox32
            // 
            this.binaryColorPickerComboBox32.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox32.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox32.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox32.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox32.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox32.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox32.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox32.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox32.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox32.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox32.FormattingEnabled = true;
            this.binaryColorPickerComboBox32.Items.AddRange(new object[] {
            "255, 253, 181"});
            this.binaryColorPickerComboBox32.Location = new System.Drawing.Point(525, 64);
            this.binaryColorPickerComboBox32.Name = "binaryColorPickerComboBox32";
            this.binaryColorPickerComboBox32.SelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(253)))), ((int)(((byte)(181)))));
            this.binaryColorPickerComboBox32.ShowBorderAlways = true;
            this.binaryColorPickerComboBox32.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox32.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox32.TabIndex = 48;
            this.binaryColorPickerComboBox32.SelectedColorChanged += new System.EventHandler(this.HandleCustomerMeetingsTabCustomEndColorChanged);
            // 
            // binaryColorPickerComboBox27
            // 
            this.binaryColorPickerComboBox27.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox27.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox27.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox27.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox27.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox27.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox27.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox27.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox27.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox27.FormattingEnabled = true;
            this.binaryColorPickerComboBox27.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBox27.Location = new System.Drawing.Point(525, 36);
            this.binaryColorPickerComboBox27.Name = "binaryColorPickerComboBox27";
            this.binaryColorPickerComboBox27.SelectedColor = System.Drawing.Color.Black;
            this.binaryColorPickerComboBox27.ShowBorderAlways = true;
            this.binaryColorPickerComboBox27.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox27.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox27.TabIndex = 58;
            this.binaryColorPickerComboBox27.SelectedColorChanged += new System.EventHandler(this.HandleCustomStyleTabCustomerMeetingsTabPageForeColorChanged);
            // 
            // binaryColorPickerComboBox28
            // 
            this.binaryColorPickerComboBox28.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox28.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox28.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox28.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox28.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox28.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox28.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox28.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox28.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox28.FormattingEnabled = true;
            this.binaryColorPickerComboBox28.Items.AddRange(new object[] {
            "255, 255, 255"});
            this.binaryColorPickerComboBox28.Location = new System.Drawing.Point(174, 36);
            this.binaryColorPickerComboBox28.Name = "binaryColorPickerComboBox28";
            this.binaryColorPickerComboBox28.SelectedColor = System.Drawing.Color.White;
            this.binaryColorPickerComboBox28.ShowBorderAlways = true;
            this.binaryColorPickerComboBox28.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox28.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox28.TabIndex = 56;
            this.binaryColorPickerComboBox28.SelectedColorChanged += new System.EventHandler(this.HandleCustomCustomerMeetingsBackColorChanged);
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label68.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label68.Location = new System.Drawing.Point(369, 67);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(136, 13);
            this.label68.TabIndex = 46;
            this.label68.Text = "Tab page header end color";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label51.Location = new System.Drawing.Point(21, 39);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(100, 13);
            this.label51.TabIndex = 55;
            this.label51.Text = "Tab page backcolor";
            // 
            // binaryColorPickerComboBox33
            // 
            this.binaryColorPickerComboBox33.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox33.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox33.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox33.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox33.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox33.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox33.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox33.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox33.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox33.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox33.FormattingEnabled = true;
            this.binaryColorPickerComboBox33.Items.AddRange(new object[] {
            "255, 254, 221"});
            this.binaryColorPickerComboBox33.Location = new System.Drawing.Point(174, 64);
            this.binaryColorPickerComboBox33.Name = "binaryColorPickerComboBox33";
            this.binaryColorPickerComboBox33.SelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(254)))), ((int)(((byte)(221)))));
            this.binaryColorPickerComboBox33.ShowBorderAlways = true;
            this.binaryColorPickerComboBox33.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox33.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox33.TabIndex = 47;
            this.binaryColorPickerComboBox33.SelectedColorChanged += new System.EventHandler(this.HandleCustomerMeetingsTabCustomStartColorChanged);
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label69.Location = new System.Drawing.Point(21, 67);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(141, 13);
            this.label69.TabIndex = 45;
            this.label69.Text = "Tab page header start color";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label50.Location = new System.Drawing.Point(369, 39);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(98, 13);
            this.label50.TabIndex = 57;
            this.label50.Text = "Tab page forecolor";
            // 
            // binaryColorPickerComboBox31
            // 
            this.binaryColorPickerComboBox31.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox31.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox31.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox31.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox31.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox31.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox31.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox31.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox31.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox31.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox31.FormattingEnabled = true;
            this.binaryColorPickerComboBox31.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBox31.Location = new System.Drawing.Point(510, 79);
            this.binaryColorPickerComboBox31.Name = "binaryColorPickerComboBox31";
            this.binaryColorPickerComboBox31.SelectedColor = System.Drawing.Color.Empty;
            this.binaryColorPickerComboBox31.ShowBorderAlways = true;
            this.binaryColorPickerComboBox31.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox31.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox31.TabIndex = 50;
            this.binaryColorPickerComboBox31.SelectedColorChanged += new System.EventHandler(this.HandleCustomerMeetingsTabPageHeaderForeColorChanged);
            // 
            // binaryPowerTabPage_Custom_EmailArchives
            // 
            this.binaryPowerTabPage_Custom_EmailArchives.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage_Custom_EmailArchives.BorderColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabPage_Custom_EmailArchives.BorderSize = 1;
            this.binaryPowerTabPage_Custom_EmailArchives.Controls.Add(this.panel8);
            this.binaryPowerTabPage_Custom_EmailArchives.CustomEndColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(225)))), ((int)(((byte)(183)))));
            this.binaryPowerTabPage_Custom_EmailArchives.CustomStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(185)))), ((int)(((byte)(136)))));
            this.binaryPowerTabPage_Custom_EmailArchives.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage_Custom_EmailArchives.Image = ((System.Drawing.Image)(resources.GetObject("binaryPowerTabPage_Custom_EmailArchives.Image")));
            this.binaryPowerTabPage_Custom_EmailArchives.IsBackgroundTransparent = false;
            this.binaryPowerTabPage_Custom_EmailArchives.IsHeaderEnabled = true;
            this.binaryPowerTabPage_Custom_EmailArchives.Name = "binaryPowerTabPage_Custom_EmailArchives";
            this.binaryPowerTabPage_Custom_EmailArchives.Size = new System.Drawing.Size(720, 113);
            this.binaryPowerTabPage_Custom_EmailArchives.TabIndex = 4;
            this.binaryPowerTabPage_Custom_EmailArchives.TabPageContentIsDirty = false;
            this.binaryPowerTabPage_Custom_EmailArchives.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage_Custom_EmailArchives.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage_Custom_EmailArchives.Text = "Email Archives";
            this.binaryPowerTabPage_Custom_EmailArchives.ToolTipText = "";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.Window;
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.binaryColorPickerComboBox37);
            this.panel8.Controls.Add(this.label53);
            this.panel8.Controls.Add(this.binaryColorPickerComboBox38);
            this.panel8.Controls.Add(this.binaryColorPickerComboBox23);
            this.panel8.Controls.Add(this.label73);
            this.panel8.Controls.Add(this.binaryColorPickerComboBox24);
            this.panel8.Controls.Add(this.label74);
            this.panel8.Controls.Add(this.label47);
            this.panel8.Controls.Add(this.binaryColorPickerComboBox39);
            this.panel8.Controls.Add(this.label75);
            this.panel8.Controls.Add(this.label46);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(0, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(720, 113);
            this.panel8.TabIndex = 60;
            // 
            // binaryColorPickerComboBox37
            // 
            this.binaryColorPickerComboBox37.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox37.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox37.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox37.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox37.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox37.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox37.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox37.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox37.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox37.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox37.FormattingEnabled = true;
            this.binaryColorPickerComboBox37.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBox37.Location = new System.Drawing.Point(505, 78);
            this.binaryColorPickerComboBox37.Name = "binaryColorPickerComboBox37";
            this.binaryColorPickerComboBox37.SelectedColor = System.Drawing.Color.Black;
            this.binaryColorPickerComboBox37.ShowBorderAlways = true;
            this.binaryColorPickerComboBox37.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox37.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox37.TabIndex = 50;
            this.binaryColorPickerComboBox37.SelectedColorChanged += new System.EventHandler(this.HandleCustomEmailArchivesTabPageHeaderForeColorChanged);
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(255, 7);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(220, 13);
            this.label53.TabIndex = 59;
            this.label53.Text = "This is the \"Email Archives\"  tab page.";
            // 
            // binaryColorPickerComboBox38
            // 
            this.binaryColorPickerComboBox38.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox38.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox38.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox38.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox38.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox38.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox38.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox38.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox38.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox38.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox38.FormattingEnabled = true;
            this.binaryColorPickerComboBox38.Items.AddRange(new object[] {
            "255, 225, 183"});
            this.binaryColorPickerComboBox38.Location = new System.Drawing.Point(505, 51);
            this.binaryColorPickerComboBox38.Name = "binaryColorPickerComboBox38";
            this.binaryColorPickerComboBox38.SelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(225)))), ((int)(((byte)(183)))));
            this.binaryColorPickerComboBox38.ShowBorderAlways = true;
            this.binaryColorPickerComboBox38.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox38.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox38.TabIndex = 48;
            this.binaryColorPickerComboBox38.SelectedColorChanged += new System.EventHandler(this.HandleCustomEmailArchivesCustomEndColorChanged);
            // 
            // binaryColorPickerComboBox23
            // 
            this.binaryColorPickerComboBox23.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox23.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox23.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox23.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox23.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox23.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox23.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox23.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox23.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox23.FormattingEnabled = true;
            this.binaryColorPickerComboBox23.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBox23.Location = new System.Drawing.Point(504, 23);
            this.binaryColorPickerComboBox23.Name = "binaryColorPickerComboBox23";
            this.binaryColorPickerComboBox23.SelectedColor = System.Drawing.Color.Black;
            this.binaryColorPickerComboBox23.ShowBorderAlways = true;
            this.binaryColorPickerComboBox23.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox23.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox23.TabIndex = 58;
            this.binaryColorPickerComboBox23.SelectedColorChanged += new System.EventHandler(this.HandleCustomStyledTabEmailArchivesTabPageChildrenForecolorChanged);
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label73.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label73.Location = new System.Drawing.Point(349, 85);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(135, 13);
            this.label73.TabIndex = 49;
            this.label73.Text = "Tab page header forecolor";
            // 
            // binaryColorPickerComboBox24
            // 
            this.binaryColorPickerComboBox24.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox24.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox24.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox24.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox24.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox24.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox24.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox24.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox24.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox24.FormattingEnabled = true;
            this.binaryColorPickerComboBox24.Items.AddRange(new object[] {
            "255, 255, 255"});
            this.binaryColorPickerComboBox24.Location = new System.Drawing.Point(154, 27);
            this.binaryColorPickerComboBox24.Name = "binaryColorPickerComboBox24";
            this.binaryColorPickerComboBox24.SelectedColor = System.Drawing.Color.White;
            this.binaryColorPickerComboBox24.ShowBorderAlways = true;
            this.binaryColorPickerComboBox24.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox24.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox24.TabIndex = 56;
            this.binaryColorPickerComboBox24.SelectedColorChanged += new System.EventHandler(this.HandleCustomStyleTabEmailArchivesBackColorChanged);
            // 
            // label74
            // 
            this.label74.AutoSize = true;
            this.label74.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label74.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label74.Location = new System.Drawing.Point(349, 58);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(136, 13);
            this.label74.TabIndex = 46;
            this.label74.Text = "Tab page header end color";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label47.Location = new System.Drawing.Point(1, 30);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(100, 13);
            this.label47.TabIndex = 55;
            this.label47.Text = "Tab page backcolor";
            // 
            // binaryColorPickerComboBox39
            // 
            this.binaryColorPickerComboBox39.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox39.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox39.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox39.BackColor = System.Drawing.SystemColors.Window;
            this.binaryColorPickerComboBox39.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox39.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox39.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox39.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox39.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox39.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox39.FormattingEnabled = true;
            this.binaryColorPickerComboBox39.Items.AddRange(new object[] {
            "247, 185, 136"});
            this.binaryColorPickerComboBox39.Location = new System.Drawing.Point(154, 55);
            this.binaryColorPickerComboBox39.Name = "binaryColorPickerComboBox39";
            this.binaryColorPickerComboBox39.SelectedColor = System.Drawing.Color.FromArgb(((int)(((byte)(247)))), ((int)(((byte)(185)))), ((int)(((byte)(136)))));
            this.binaryColorPickerComboBox39.ShowBorderAlways = true;
            this.binaryColorPickerComboBox39.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox39.Size = new System.Drawing.Size(148, 22);
            this.binaryColorPickerComboBox39.TabIndex = 47;
            this.binaryColorPickerComboBox39.SelectedColorChanged += new System.EventHandler(this.HandleCustomEmailArchivesCustomStartColorChanged);
            // 
            // label75
            // 
            this.label75.AutoSize = true;
            this.label75.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label75.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label75.Location = new System.Drawing.Point(1, 58);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(141, 13);
            this.label75.TabIndex = 45;
            this.label75.Text = "Tab page header start color";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label46.Location = new System.Drawing.Point(348, 30);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(98, 13);
            this.label46.TabIndex = 57;
            this.label46.Text = "Tab page forecolor";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(690, 605);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(89, 33);
            this.button1.TabIndex = 1;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.HandleApplicationExitRequested);
            // 
            // binaryColorPickerComboBox29
            // 
            this.binaryColorPickerComboBox29.AlphaBlendFactorForControlPainting = 100;
            this.binaryColorPickerComboBox29.AlphaBlendFactorForDropDownPressedColor = 70;
            this.binaryColorPickerComboBox29.AlphaBlendFactorForItemSelectionColor = 70;
            this.binaryColorPickerComboBox29.CustomColorRectangleBorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.binaryColorPickerComboBox29.CustomControlBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox29.CustomPaintingColor = System.Drawing.SystemColors.Highlight;
            this.binaryColorPickerComboBox29.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.binaryColorPickerComboBox29.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.binaryColorPickerComboBox29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.binaryColorPickerComboBox29.FormattingEnabled = true;
            this.binaryColorPickerComboBox29.Items.AddRange(new object[] {
            "0, 0, 0"});
            this.binaryColorPickerComboBox29.Location = new System.Drawing.Point(377, 58);
            this.binaryColorPickerComboBox29.Name = "binaryColorPickerComboBox29";
            this.binaryColorPickerComboBox29.SelectedColor = System.Drawing.Color.Empty;
            this.binaryColorPickerComboBox29.ShowBorderAlways = true;
            this.binaryColorPickerComboBox29.ShowColorNameIfKnownColor = false;
            this.binaryColorPickerComboBox29.Size = new System.Drawing.Size(148, 21);
            this.binaryColorPickerComboBox29.TabIndex = 44;
            this.binaryColorPickerComboBox29.Text = "Empty";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.ForeColor = System.Drawing.SystemColors.WindowText;
            this.label65.Location = new System.Drawing.Point(198, 61);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(136, 13);
            this.label65.TabIndex = 43;
            this.label65.Text = "Tab page Header forecolor";
            // 
            // BinaryPowerTabStripDemoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(806, 683);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.binaryPowerTabStrip1);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsWindowResizingAllowed = false;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "BinaryPowerTabStripDemoForm";
            this.TitlebarText = "Binarymission Tab control for WinForms .NET";
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this.Load += new System.EventHandler(this.HandleBinaryPowerTabStripDemoLoad);
            this.binaryPowerTabStrip1.ResumeLayout(false);
            this.binaryPowerTabPage1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownEmptySpaceLengthBeforeFirstTagPageHeader)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            this.binaryPowerTabStripUsingBuiltinStyle.ResumeLayout(false);
            this.binaryPowerTabPage_Welcome.ResumeLayout(false);
            this.binaryPowerTabPage_Welcome.PerformLayout();
            this.binaryPowerTabPage_UserManagement.ResumeLayout(false);
            this.binaryPowerTabPage_UserManagement.PerformLayout();
            this.binaryPowerTabPage_CustomerMeetings.ResumeLayout(false);
            this.binaryPowerTabPage_CustomerMeetings.PerformLayout();
            this.binaryPowerTabPage_DatabaseReplication.ResumeLayout(false);
            this.binaryPowerTabPage_DatabaseReplication.PerformLayout();
            this.binaryPowerTabPage_EmailArchives.ResumeLayout(false);
            this.binaryPowerTabPage_EmailArchives.PerformLayout();
            this.binaryPowerTabPage2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownEmptySpaceLengthBeforeFirstTabPageHeader2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownGapLengthBetweenTabPageHeader)).EndInit();
            this.binaryPowerTabStripUsingCustomStyle.ResumeLayout(false);
            this.binaryPowerTabPage_Custom_Welcome.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.binaryPowerTabPage_Custom_UserManagement.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.binaryPowerTabPage_Custom_DatabaseReplication.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.binaryPowerTabPage_Custom_CustomerMeetings.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.binaryPowerTabPage_Custom_EmailArchives.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabStrip binaryPowerTabStrip1;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage1;
        private System.Windows.Forms.Panel panel1;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabStrip binaryPowerTabStripUsingBuiltinStyle;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage_DatabaseReplication;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage_Welcome;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage_UserManagement;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage_CustomerMeetings;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage_EmailArchives;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown numericUpDownEmptySpaceLengthBeforeFirstTagPageHeader;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox chkEnableDragDrop1;
        private System.Windows.Forms.CheckBox chkShowCloseButton;
        private System.Windows.Forms.CheckBox chkDrawTabPageOnTopofEachother;
        private System.Windows.Forms.CheckBox chkShowMenuDropDownButton;
        private System.Windows.Forms.CheckBox chkDrawBorderAroundTabStrip;
        private System.Windows.Forms.CheckBox chkDrawGapBetweenTabPages;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label9;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox1CloseButtonColor;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxCloseButtonFillColor;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox1CloseButtonBorderColor;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxMenuButtonFillColor;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxMenuButtonBorderColor;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxMenuButtonColor;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cmbTabPageRenderingStyle;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox2;
        private System.Windows.Forms.Label label15;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button button1;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox3;
        private System.Windows.Forms.Label label16;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox4;
        private System.Windows.Forms.Label label17;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage2;
        private System.Windows.Forms.Panel panel4;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabStrip binaryPowerTabStripUsingCustomStyle;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage_Custom_CustomerMeetings;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage_Custom_Welcome;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage_Custom_UserManagement;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage_Custom_DatabaseReplication;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage_Custom_EmailArchives;
        private System.Windows.Forms.Panel panel2;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxTabPageHeaderForecolor2;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxMenuButtonFillColor2;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxMenuButtonBorderColor2;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxMenuButtonColor2;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxCloseButtonFillColor2;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxCloseButtonBorderColor2;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxCloseButtonColor2;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxTabPageBorderColor2;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.CheckBox chkDrawGapBetweenTabPages2;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.CheckBox chkDrawTabPageOnTopofEachOther2;
        private System.Windows.Forms.CheckBox chkEnableDragDrop2;
        private System.Windows.Forms.CheckBox chkShowSideBarOnTabPageHeader;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.CheckBox chkShowCloseButton2;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.CheckBox chkShowMenuDropdownButton2;
        private System.Windows.Forms.CheckBox chkDrawBorderAroundTabStrip2;
        private System.Windows.Forms.ComboBox cmbGradientOrientationOnTabPageHeader;
        private System.Windows.Forms.NumericUpDown numericUpDownEmptySpaceLengthBeforeFirstTabPageHeader2;
        private System.Windows.Forms.NumericUpDown numericUpDownGapLengthBetweenTabPageHeader;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label1;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox17;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox18;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox13;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label2;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox14;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox15;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox16;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox19;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox20;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label55;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox25;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox26;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label52;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox21;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox22;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label53;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox23;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox24;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label54;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox27;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox28;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label18;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxTabPageHeaderEndColor;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxTabPageHeaderstartcolor;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxSideBarFillColor;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox5;
        private System.Windows.Forms.Label label57;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox6;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox7;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBoxTabPageHeaderForecolor;
        private System.Windows.Forms.Label label5;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox8;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox9;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox10;
        private System.Windows.Forms.Label label62;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox11;
        private System.Windows.Forms.Label label63;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox12;
        private System.Windows.Forms.Label label64;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox30;
        private System.Windows.Forms.Label label66;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox29;
        private System.Windows.Forms.Label label65;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox31;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox32;
        private System.Windows.Forms.Label label68;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox33;
        private System.Windows.Forms.Label label69;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox34;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox35;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox36;
        private System.Windows.Forms.Label label72;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox37;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox38;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox39;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.ComboBox cmbCustomTabPageRenderingStyle;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.ComboBox tabPageRenderingLocationCmbBx;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.ComboBox customTabPagesRenderignLocationCmbBx;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.ComboBox tabPageRenderingLocationCmbBxTab1;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.ComboBox cmbTabPageRenderingStyleTab1;
        private System.Windows.Forms.Label label80;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox40;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox41;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox42;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox43;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox44;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox45;
        private Binarymission.WinForms.Controls.ExtendedColorPickers.BinaryColorPickerComboBox binaryColorPickerComboBox46;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.CheckBox chkDrawGapBetweenTabPagesTabPage1;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.ComboBox overflowModeCmbBx1;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.ComboBox overflowModeCmbBx2;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.CheckBox chkShoudlAutoSizeTabHeaders1;
        private System.Windows.Forms.CheckBox chkShouldAutoSizeTabHeaders2;
    }
}