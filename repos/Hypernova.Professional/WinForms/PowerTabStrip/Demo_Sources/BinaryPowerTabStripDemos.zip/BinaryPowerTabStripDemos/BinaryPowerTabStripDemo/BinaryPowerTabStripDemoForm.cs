using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.ContainerControls.Windows;
using Binarymission.WinForms.Controls.ContainerControls.Windows.Enums;
using Binarymission.WinForms.Controls.TabControls;

namespace BinaryPowerTabStripDemo
{
    /*
     * Note that this demo code demonstrates how you can set the properties via code.
     * However, you do not need to write code to use the tab control.
     * Most of the things that you are doing here can be simply set in Design time / IDE property browser directly.
     * The code here is to simply explain how you CAN work with the control via code (if you want to)... that too, all it takes is setting simple properties.
     */

    public partial class BinaryPowerTabStripDemoForm : ModernChromeWindow
    {
        private List<BinaryPowerTabStrip> _tabControls;

        public BinaryPowerTabStripDemoForm()
        {
            InitializeComponent();
            Construct();
        }

        private void Construct()
        {
            _tabControls = new List<BinaryPowerTabStrip>();
            overflowModeCmbBx1.SelectedIndex = 0;
            overflowModeCmbBx2.SelectedIndex = 0;
            cmbTabPageRenderingStyleTab1.SelectedIndex = cmbTabPageRenderingStyleTab1.Items.IndexOf("VisualStudio2008");
            tabPageRenderingLocationCmbBxTab1.SelectedIndex = tabPageRenderingLocationCmbBxTab1.Items.IndexOf("Top");
            WindowChromeTheme = WindowChromeTheme.OfficeBlack;
        }

        private void HandleBuiltinStyleTabControlEnableDragAndDropOfTabPagesChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingBuiltinStyle.EnableDragAndDropOfTabPages = checkBox5.Checked;
        }

        private void HandleBuiltinStyleDrawTabPageOnTopOfEachOtherChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingBuiltinStyle.DrawTabPageOnTopOfEachOther = checkBox4.Checked;
        }

        private void HandleBuiltinStyleDrawBorderAroundTabStripChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingBuiltinStyle.DrawBorderAroundTabStrip = checkBox8.Checked;
        }

        private void HandleShowCloseButtonCheckedChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingBuiltinStyle.ShowCloseWindowButton = checkBox6.Checked;
            binaryPowerTabStripUsingBuiltinStyle.EnableTabPageLevelCloseButtonRendering = checkBox6.Checked;

            // Enable / disable the corresponding label and color picker controls
            label82.Enabled = checkBox6.Checked;
            binaryColorPickerComboBox1CloseButtonColor.Enabled = checkBox6.Checked;
            label85.Enabled = checkBox6.Checked;
            binaryColorPickerComboBox1CloseButtonBorderColor.Enabled = checkBox6.Checked;
            label84.Enabled = checkBox6.Checked;
            binaryColorPickerComboBoxCloseButtonFillColor.Enabled = checkBox6.Checked;
        }

        private void HandleTabPagesCloseButtonColorSelectedColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingBuiltinStyle.TabPagesCloseButtonColor =
                binaryColorPickerComboBox1CloseButtonColor.SelectedColor;
        }

        private void HandleBuiltinStyleTabPageCloseButtonRectangleBorderColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingBuiltinStyle.TabPageCloseButtonRectangleBorderColor =
                binaryColorPickerComboBox1CloseButtonBorderColor.SelectedColor;
        }

        private void HandleBuiltinStyleTabPageCloseButtonRectangleFillColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingBuiltinStyle.TabPageCloseButtonRectangleFillColor =
                binaryColorPickerComboBoxCloseButtonFillColor.SelectedColor;
        }

        private void HandleBuiltinStyleShowOverflowMenuGlyphChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingBuiltinStyle.ShowOverflowMenuGlyph =
                checkBox7.Checked;

            // Enable / disable the corresponding label and color picker controls
            label81.Enabled = checkBox7.Checked;
            binaryColorPickerComboBox43.Enabled = chkShowMenuDropDownButton.Checked;
            label87.Enabled = checkBox7.Checked;
            binaryColorPickerComboBox42.Enabled = chkShowMenuDropDownButton.Checked;
            label86.Enabled = checkBox7.Checked;
            binaryColorPickerComboBox41.Enabled = chkShowMenuDropDownButton.Checked;
        }

        private void HandleBuiltinStyleTabPagesOverFlowMenuDropDownColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingBuiltinStyle.TabPagesOverFlowMenuDropDownColor =
                binaryColorPickerComboBoxMenuButtonColor.SelectedColor;
        }

        private void HandleBuiltinStyleTabPagesOverFlowMenuGlyphActiveRectangleBorderColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingBuiltinStyle.TabPagesOverFlowMenuGlyphActiveRectangleBorderColor =
                binaryColorPickerComboBoxMenuButtonBorderColor.SelectedColor;
        }

        private void HandleBuiltinStyleTabPagesOverFlowMenuGlyphActiveRectangleFillColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingBuiltinStyle.TabPagesOverFlowMenuGlyphActiveRectangleFillColor =
                binaryColorPickerComboBoxMenuButtonFillColor.SelectedColor;
        }

        private void HandleBuiltinStyleTabPagesHaveGapBetweenThemChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingBuiltinStyle.TabPagesHaveGapBetweenThem =
                chkDrawGapBetweenTabPagesTabPage1.Checked;

            // Enable / disable the corresponding field buttons
            label89.Enabled = chkDrawGapBetweenTabPagesTabPage1.Checked;
            numericUpDown3.Enabled = chkDrawGapBetweenTabPagesTabPage1.Checked;
        }

        private void HandleBuiltinStyleGapBetweenTabPagesValueChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingBuiltinStyle.GapBetweenTabPages = Convert.ToInt32(numericUpDown2.Value);
        }

        private void HandleBuiltinStyleGapBetweenTabPagesValuesChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingBuiltinStyle.GapBetweenTabPages = Convert.ToInt32(numericUpDown3.Value);
        }

        private void HandleBuiltinStyledTabPageRenderingStyleTab1SelectedIndexChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingBuiltinStyle.TabRenderingStyle =
                (RenderingStyle)Enum.Parse(typeof(RenderingStyle), cmbTabPageRenderingStyleTab1.SelectedItem.ToString());
        }

        private void HandleBuiltinStyledTabControlEmptySpaceLengthBeforeFirstTagPageHeaderValueChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingBuiltinStyle.EmptySpaceLengthBeforeTheFirstTabPage =
                Convert.ToInt32(numericUpDown1.Value);
        }

        private void HandleWelcomeTabPageBackColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabPage_Welcome.BackColor = binaryColorPickerComboBox1.SelectedColor;
        }

        private void HandleApplicationExitRequested(object sender, EventArgs e)
        {
            this.Close();
        }

        private void HandleBuiltinStyleTabWelcomePageChildrenForeColorChanged(object sender, EventArgs e)
        {
            foreach (Control c in binaryColorPickerComboBox2.Parent.Controls)
            {
                c.ForeColor = binaryColorPickerComboBox2.SelectedColor;
            }
        }

        private void HandleUserManagementTabPageBackColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabPage_UserManagement.BackColor = binaryColorPickerComboBox4.SelectedColor;
        }

        private void HandleBuiltinStyleTabUserManagementTabChildrenForecolorChanged(object sender, EventArgs e)
        {
            foreach (Control c in binaryColorPickerComboBox3.Parent.Controls)
            {
                c.ForeColor = binaryColorPickerComboBox3.SelectedColor;
            }
        }

        private void HandleBuiltinStyleTabEmailArchiveTabChildrenForecolorChanged(object sender, EventArgs e)
        {
            foreach (Control c in binaryColorPickerComboBox17.Parent.Controls)
            {
                c.ForeColor = binaryColorPickerComboBox17.SelectedColor;
            }
        }

        private void HandleCustomStyledTabEmailArchivesBackColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabPage_EmailArchives.BackColor = binaryColorPickerComboBox18.SelectedColor;
        }

        private void HandleBuiltinStyledTabDbReplicationTabPageChildrenForecolorChanged(object sender, EventArgs e)
        {
            foreach (Control c in binaryColorPickerComboBox13.Parent.Controls)
            {
                c.ForeColor = binaryColorPickerComboBox13.SelectedColor;
            }
        }

        private void HandleCustomStyledTabDatabaseReplicationBackColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabPage_DatabaseReplication.BackColor = binaryColorPickerComboBox14.SelectedColor;
        }

        private void HandleBuiltinStyledTabCustomerMeetingsTabPageChildrenForecolorChanged(object sender, EventArgs e)
        {
            foreach (Control c in binaryColorPickerComboBox15.Parent.Controls)
            {
                c.ForeColor = binaryColorPickerComboBox15.SelectedColor;
            }
        }

        private void HandleCustomStyleTabCustomerMeetingsTabPageBackColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabPage_CustomerMeetings.BackColor = binaryColorPickerComboBox16.SelectedColor;
        }

        private void HandleCustomStyledTabWelcomeTabPageChildrenForecolorChanged(object sender, EventArgs e)
        {
            foreach (Control c in binaryColorPickerComboBox19.Parent.Controls)
            {
                c.ForeColor = binaryColorPickerComboBox19.SelectedColor;
            }
            binaryPowerTabStripUsingCustomStyle.Refresh();
        }

        private void HandleCustomStyleTabWelcomeTabPageBackcolorChanged(object sender, EventArgs e)
        {
            binaryPowerTabPage_Custom_Welcome.BackColor = binaryColorPickerComboBox20.SelectedColor;
            binaryPowerTabStripUsingCustomStyle.Refresh();
        }

        private void HandleCustomStyledTabUserManagementTabPageChildrenForecolorChanged(object sender, EventArgs e)
        {
            foreach (Control c in binaryColorPickerComboBox21.Parent.Controls)
            {
                c.ForeColor = binaryColorPickerComboBox21.SelectedColor;
            }
            binaryPowerTabStripUsingCustomStyle.Refresh();
        }

        private void HandleCustomStyledTabEmailArchivesTabPageChildrenForecolorChanged(object sender, EventArgs e)
        {
            foreach (Control c in binaryColorPickerComboBox23.Parent.Controls)
            {
                c.ForeColor = binaryColorPickerComboBox23.SelectedColor;
            }
            binaryPowerTabStripUsingCustomStyle.Refresh();
        }

        private void HandleCustomStyleTabDatabaseReplicationTabPageForecolorChanged(object sender, EventArgs e)
        {
            foreach (Control c in binaryColorPickerComboBox25.Parent.Controls)
            {
                c.ForeColor = binaryColorPickerComboBox25.SelectedColor;
            }
            binaryPowerTabStripUsingCustomStyle.Refresh();
        }

        private void HandleCustomStyleTabEmailArchivesBackColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabPage_Custom_EmailArchives.BackColor = binaryColorPickerComboBox24.SelectedColor;
            binaryPowerTabStripUsingCustomStyle.Refresh();
        }

        private void HandleCustomStyleTabDatabaseReplicationBackColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabPage_Custom_DatabaseReplication.BackColor =
                binaryColorPickerComboBox26.SelectedColor;
            binaryPowerTabStripUsingCustomStyle.Refresh();
        }

        private void HandleCustomStyleTabCustomerMeetingsTabPageForeColorChanged(object sender, EventArgs e)
        {
            foreach (Control c in binaryColorPickerComboBox27.Parent.Controls)
            {
                c.ForeColor = binaryColorPickerComboBox27.SelectedColor;
            }
        }

        private void HandleCustomCustomerMeetingsBackColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabPage_Custom_CustomerMeetings.BackColor =
                binaryColorPickerComboBox28.SelectedColor;
        }

        private void HandleCustomUserManagementBackColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabPage_Custom_UserManagement.BackColor =
                binaryColorPickerComboBox22.SelectedColor;
            binaryPowerTabStripUsingCustomStyle.Refresh();
        }

        private void HandleCustomStyleEnableDragAndDropOfTabPagesChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingCustomStyle.EnableDragAndDropOfTabPages = chkEnableDragDrop2.Checked;
        }

        private void CustomStyleTabDrawBorderAroundTabStripCheckedChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingCustomStyle.DrawBorderAroundTabStrip =
                chkDrawBorderAroundTabStrip2.Checked;

            // Enable / disable the corresponding field buttons
            label23.Enabled = chkDrawBorderAroundTabStrip2.Checked;
            binaryColorPickerComboBoxTabPageBorderColor2.Enabled = chkDrawBorderAroundTabStrip2.Checked;
        }

        private void HandleCustomStyleTabTabPageBorderColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingCustomStyle.TabPageBorderColor =
                binaryColorPickerComboBoxTabPageBorderColor2.SelectedColor;
            binaryPowerTabStripUsingCustomStyle.Refresh();
        }

        private void HandleCustomStyleTabPageHeaderForeColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingCustomStyle.TabPageHeaderForeColor =
                binaryColorPickerComboBoxTabPageHeaderForecolor2.SelectedColor;

            //Set the tab page header color in individual pages
            binaryColorPickerComboBox12.SelectedColor = binaryColorPickerComboBoxTabPageHeaderForecolor2.SelectedColor;
            binaryColorPickerComboBox30.SelectedColor = binaryColorPickerComboBoxTabPageHeaderForecolor2.SelectedColor;
            binaryColorPickerComboBox31.SelectedColor = binaryColorPickerComboBoxTabPageHeaderForecolor2.SelectedColor;
            binaryColorPickerComboBox34.SelectedColor = binaryColorPickerComboBoxTabPageHeaderForecolor2.SelectedColor;
            binaryColorPickerComboBox37.SelectedColor = binaryColorPickerComboBoxTabPageHeaderForecolor2.SelectedColor;
        }

        private void HandleCustleTabWelcomeCustomStartColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabPage_Custom_Welcome.CustomStartColor =
                binaryColorPickerComboBoxTabPageHeaderstartcolor.SelectedColor;
            binaryPowerTabStripUsingCustomStyle.Refresh();
        }

        private void HandleCustleTabWelcomeCustomEndColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabPage_Custom_Welcome.CustomEndColor =
                binaryColorPickerComboBoxTabPageHeaderEndColor.SelectedColor;
            binaryPowerTabStripUsingCustomStyle.Refresh();
        }

        private void HandleCustomStyleTabDrawTabPageOnTopOfEachOtherOptionChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingCustomStyle.DrawTabPageOnTopOfEachOther =
                chkDrawTabPageOnTopofEachOther2.Checked;
        }

        private void HandleCustomStyleEmptySpaceLengthBeforeTheFirstTabPageValueChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingCustomStyle.EmptySpaceLengthBeforeTheFirstTabPage =
                Convert.ToInt32(numericUpDownEmptySpaceLengthBeforeFirstTabPageHeader2.Value);
        }

        private void HandleCustomStyleTabPagesHaveGapBetweenThemOptionChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingCustomStyle.TabPagesHaveGapBetweenThem = chkDrawGapBetweenTabPages2.Checked;

            // Enable / disable the corresponding field buttons
            label29.Enabled = chkDrawGapBetweenTabPages2.Checked;
            numericUpDownGapLengthBetweenTabPageHeader.Enabled =
                chkDrawGapBetweenTabPages2.Checked;
        }

        private void HandleCustomStyleTabPageHeaderShowsSideBarOptionChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingCustomStyle.TabPageHeaderShowsSideBar =
                chkShowSideBarOnTabPageHeader.Checked;

            // Enable / disable the corresponding field buttons
            label21.Enabled = chkShowSideBarOnTabPageHeader.Checked;
            binaryColorPickerComboBoxSideBarFillColor.Enabled = chkShowSideBarOnTabPageHeader.Checked;
        }

        private void HandleCustomStyleTabShowCloseWindowButtonOptionChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingCustomStyle.ShowCloseWindowButton = binaryPowerTabStripUsingCustomStyle.EnableTabPageLevelCloseButtonRendering =
                chkShowCloseButton2.Checked;

            // Enable / disable the corresponding field buttons
            label20.Enabled = chkShowCloseButton2.Checked;
            binaryColorPickerComboBoxCloseButtonColor2.Enabled = chkShowCloseButton2.Checked;
            label25.Enabled = chkShowCloseButton2.Checked;
            binaryColorPickerComboBoxCloseButtonBorderColor2.Enabled = chkShowCloseButton2.Checked;
            label24.Enabled = chkShowCloseButton2.Checked;
            binaryColorPickerComboBoxCloseButtonFillColor2.Enabled = chkShowCloseButton2.Checked;
        }

        private void HandleCustomStyleTabPagesCloseButtonColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingCustomStyle.TabPagesCloseButtonColor =
                binaryColorPickerComboBoxCloseButtonColor2.SelectedColor;
        }

        private void HandleCustomStyleTabPageCloseButtonRectangleBorderColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingCustomStyle.TabPageCloseButtonRectangleBorderColor =
                binaryColorPickerComboBoxCloseButtonBorderColor2.SelectedColor;
        }

        private void HandleCustomStyleTabPageCloseButtonRectangleFillColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingCustomStyle.TabPageCloseButtonRectangleFillColor =
                binaryColorPickerComboBoxCloseButtonFillColor2.SelectedColor;
        }

        private void HandleCustomStyleShowOverflowMenuGlyphOptionChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingCustomStyle.ShowOverflowMenuGlyph =
                chkShowMenuDropdownButton2.Checked;

            // Enable / disable the corresponding field buttons          
            label9.Enabled = chkShowMenuDropdownButton2.Checked;
            binaryColorPickerComboBoxMenuButtonColor2.Enabled =
                chkShowMenuDropdownButton2.Checked;
            label27.Enabled = chkShowMenuDropdownButton2.Checked;
            binaryColorPickerComboBoxMenuButtonBorderColor2.Enabled =
                chkShowMenuDropdownButton2.Checked;
            label26.Enabled = chkShowMenuDropdownButton2.Checked;
            binaryColorPickerComboBoxMenuButtonFillColor2.Enabled =
                chkShowMenuDropdownButton2.Checked;
        }

        private void HandleCustomStyleTabPagesOverFlowMenuDropDownColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingCustomStyle.TabPagesOverFlowMenuDropDownColor =
                binaryColorPickerComboBoxMenuButtonColor2.SelectedColor;
        }

        private void HandleCustomStyleTabPagesOverFlowMenuGlyphActiveRectangleBorderColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingCustomStyle.TabPagesOverFlowMenuGlyphActiveRectangleBorderColor =
                binaryColorPickerComboBoxMenuButtonBorderColor2.SelectedColor;
        }

        private void HandleCustomStyleTabPagesOverFlowMenuGlyphActiveRectangleFillColorSelectionChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingCustomStyle.TabPagesOverFlowMenuGlyphActiveRectangleFillColor =
                binaryColorPickerComboBoxMenuButtonFillColor2.SelectedColor;
        }

        private void HandleCustomStyleTabPageHeaderDrawingGradientOrientationSelectionChanged(object sender, EventArgs e)
        {
            switch (cmbGradientOrientationOnTabPageHeader.SelectedIndex)
            {
                case 0:
                    binaryPowerTabStripUsingCustomStyle.TabPageHeaderDrawingGradientOrientation = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
                    break;

                case 1:
                    binaryPowerTabStripUsingCustomStyle.TabPageHeaderDrawingGradientOrientation = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
                    break;

                case 2:
                    binaryPowerTabStripUsingCustomStyle.TabPageHeaderDrawingGradientOrientation = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal;
                    break;

                case 3:
                    binaryPowerTabStripUsingCustomStyle.TabPageHeaderDrawingGradientOrientation = System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal;
                    break;
            }
        }

        private void HandleBinaryPowerTabStripDemoLoad(object sender, EventArgs e)
        {
            RetrievePresetsForBuiltinStyleTab();
            RetrievePresetsForCustomStyleTab();
            customTabPagesRenderignLocationCmbBx.SelectedIndex = 0;
            tabPageRenderingLocationCmbBx.SelectedIndex = 0;
        }

        private void RetrievePresetsForBuiltinStyleTab()
        {
            // Retrieving tab page Headerforecolor
            binaryColorPickerComboBoxTabPageHeaderForecolor.SelectedColor = binaryPowerTabStripUsingBuiltinStyle.TabPageHeaderForeColor;

            //Retrieving colors for the Closebutton in the Built-in style tab
            binaryColorPickerComboBox1CloseButtonColor.SelectedColor =
                binaryPowerTabStripUsingBuiltinStyle.TabPagesCloseButtonColor;
            binaryColorPickerComboBox1CloseButtonBorderColor.SelectedColor =
                binaryPowerTabStripUsingBuiltinStyle.TabPageCloseButtonRectangleBorderColor;
            binaryColorPickerComboBoxCloseButtonFillColor.SelectedColor =
                binaryPowerTabStripUsingBuiltinStyle.TabPageCloseButtonRectangleFillColor;

            //Retrieving colors for the Menubutton in the Built-in style tab
            binaryColorPickerComboBoxMenuButtonColor.SelectedColor =
                binaryPowerTabStripUsingBuiltinStyle.TabPagesOverFlowMenuDropDownColor;
            binaryColorPickerComboBoxMenuButtonBorderColor.SelectedColor =
                binaryPowerTabStripUsingBuiltinStyle.TabPagesOverFlowMenuGlyphActiveRectangleBorderColor;
            binaryColorPickerComboBoxMenuButtonFillColor.SelectedColor =
                binaryPowerTabStripUsingBuiltinStyle.TabPagesOverFlowMenuGlyphActiveRectangleFillColor;

            //Retrieving Backcolors and forecolors for the individual tab pages in the built-in style tab
            //Retrieve colors for the Welcome Page
            binaryColorPickerComboBox1.SelectedColor = binaryPowerTabPage_Welcome.BackColor;
            binaryColorPickerComboBox2.SelectedColor = label35.ForeColor;
            binaryColorPickerComboBox6.SelectedColor = binaryPowerTabStripUsingBuiltinStyle.TabPageHeaderForeColor;
            //Retrieve colors for the User Management Page
            binaryColorPickerComboBox4.SelectedColor = binaryPowerTabPage_UserManagement.BackColor;
            binaryColorPickerComboBox3.SelectedColor = label16.ForeColor;
            binaryColorPickerComboBox7.SelectedColor = binaryPowerTabStripUsingBuiltinStyle.TabPageHeaderForeColor;
            //Retrieve colors for the Customer Meetings Page
            binaryColorPickerComboBox16.SelectedColor = binaryPowerTabPage_CustomerMeetings.BackColor;
            binaryColorPickerComboBox15.SelectedColor = label31.ForeColor;
            binaryColorPickerComboBox5.SelectedColor = binaryPowerTabStripUsingBuiltinStyle.TabPageHeaderForeColor;
            //Retrieve colors for the Database Replication Page
            binaryColorPickerComboBox14.SelectedColor = binaryPowerTabPage_DatabaseReplication.BackColor;
            binaryColorPickerComboBox13.SelectedColor = label2.ForeColor;
            binaryColorPickerComboBox8.SelectedColor = binaryPowerTabStripUsingBuiltinStyle.TabPageHeaderForeColor;
            //Retrieve colors for the Email Archives Page
            binaryColorPickerComboBox18.SelectedColor = binaryPowerTabPage_EmailArchives.BackColor;
            binaryColorPickerComboBox17.SelectedColor = label33.ForeColor;
            binaryColorPickerComboBox9.SelectedColor = binaryPowerTabStripUsingBuiltinStyle.TabPageHeaderForeColor;
        }

        private void RetrievePresetsForCustomStyleTab()
        {
            //Retrieving presets for custom style tab
            //Retrieving tab strip border color
            binaryColorPickerComboBoxTabPageBorderColor2.SelectedColor = binaryPowerTabStripUsingCustomStyle.TabPageBorderColor;

            //Retrieving tab page rendering style for built-in style tab
            switch (binaryPowerTabStripUsingCustomStyle.TabRenderingStyle)
            {
                case RenderingStyle.Custom:
                    cmbCustomTabPageRenderingStyle.SelectedIndex = 0;
                    break;

                case RenderingStyle.TrapeziumTop:
                    cmbCustomTabPageRenderingStyle.SelectedIndex = 1;
                    break;
            }

            //Retrieving tab page header fore color
            binaryColorPickerComboBoxTabPageHeaderForecolor2.SelectedColor = binaryPowerTabStripUsingCustomStyle.TabPageHeaderForeColor;

            //Retrieving tab page side bar fill color
            binaryColorPickerComboBoxSideBarFillColor.SelectedColor = binaryPowerTabStripUsingCustomStyle.TabPageSideBarFillColor;

            //Retrieving colors for the Closebutton
            binaryColorPickerComboBoxCloseButtonColor2.SelectedColor = binaryPowerTabStripUsingCustomStyle.TabPagesCloseButtonColor;
            binaryColorPickerComboBoxCloseButtonBorderColor2.SelectedColor = binaryPowerTabStripUsingCustomStyle.TabPageCloseButtonRectangleBorderColor;
            binaryColorPickerComboBoxCloseButtonFillColor2.SelectedColor = binaryPowerTabStripUsingCustomStyle.TabPageCloseButtonRectangleFillColor;

            //Retrieving colors for the Menudropdown button
            binaryColorPickerComboBoxMenuButtonColor2.SelectedColor = binaryPowerTabStripUsingCustomStyle.TabPagesOverFlowMenuDropDownColor;
            binaryColorPickerComboBoxMenuButtonBorderColor2.SelectedColor = binaryPowerTabStripUsingCustomStyle.TabPagesOverFlowMenuGlyphActiveRectangleBorderColor;
            binaryColorPickerComboBoxMenuButtonFillColor2.SelectedColor = binaryPowerTabStripUsingCustomStyle.TabPagesOverFlowMenuGlyphActiveRectangleFillColor;

            //Retrieving Gradient orientation for tab page header
            switch (binaryPowerTabStripUsingCustomStyle.TabPageHeaderDrawingGradientOrientation)
            {
                case System.Drawing.Drawing2D.LinearGradientMode.Vertical:
                    cmbGradientOrientationOnTabPageHeader.SelectedIndex = 0;
                    break;

                case System.Drawing.Drawing2D.LinearGradientMode.Horizontal:
                    cmbGradientOrientationOnTabPageHeader.SelectedIndex = 1;
                    break;

                case System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal:
                    cmbGradientOrientationOnTabPageHeader.SelectedIndex = 2;
                    break;

                case System.Drawing.Drawing2D.LinearGradientMode.BackwardDiagonal:
                    cmbGradientOrientationOnTabPageHeader.SelectedIndex = 3;
                    break;
            }

            //Retrieving backcolors and forecolors for the individual tab pages
            //Retrieve colors for the Welcome Page
            binaryColorPickerComboBox20.SelectedColor = binaryPowerTabPage_Custom_Welcome.BackColor;
            binaryColorPickerComboBox19.SelectedColor = label42.ForeColor;
            binaryColorPickerComboBoxTabPageHeaderstartcolor.SelectedColor =
                binaryPowerTabPage_Custom_Welcome.CustomStartColor;
            binaryColorPickerComboBoxTabPageHeaderEndColor.SelectedColor =
                binaryPowerTabPage_Custom_Welcome.CustomEndColor;
            binaryColorPickerComboBox12.SelectedColor = binaryPowerTabPage_Custom_Welcome.TabPageHeaderForeColor;
            //Retrieve colors for the User Management Page
            binaryColorPickerComboBox22.SelectedColor = binaryPowerTabPage_Custom_UserManagement.BackColor;
            binaryColorPickerComboBox21.SelectedColor = label44.ForeColor;
            binaryColorPickerComboBox11.SelectedColor = binaryPowerTabPage_Custom_UserManagement.CustomStartColor;
            binaryColorPickerComboBox10.SelectedColor = binaryPowerTabPage_Custom_UserManagement.CustomEndColor;
            binaryColorPickerComboBox30.SelectedColor = binaryPowerTabPage_Custom_UserManagement.TabPageHeaderForeColor;
            //Retrieve colors for the Customer Meetings Page
            binaryColorPickerComboBox28.SelectedColor = binaryPowerTabPage_Custom_CustomerMeetings.BackColor;
            binaryColorPickerComboBox27.SelectedColor = label50.ForeColor;
            binaryColorPickerComboBox33.SelectedColor = binaryPowerTabPage_Custom_CustomerMeetings.CustomStartColor;
            binaryColorPickerComboBox32.SelectedColor = binaryPowerTabPage_Custom_CustomerMeetings.CustomEndColor;
            binaryColorPickerComboBox31.SelectedColor = binaryPowerTabPage_Custom_CustomerMeetings.TabPageHeaderForeColor;
            //Retrieve colors for the Database Replication Page
            binaryColorPickerComboBox26.SelectedColor = binaryPowerTabPage_Custom_DatabaseReplication.BackColor;
            binaryColorPickerComboBox25.SelectedColor = label48.ForeColor;
            binaryColorPickerComboBox36.SelectedColor = binaryPowerTabPage_Custom_DatabaseReplication.CustomStartColor;
            binaryColorPickerComboBox35.SelectedColor = binaryPowerTabPage_Custom_DatabaseReplication.CustomEndColor;
            binaryColorPickerComboBox34.SelectedColor = binaryPowerTabPage_Custom_DatabaseReplication.TabPageHeaderForeColor;
            //Retrieve colors for the Email Archives Page
            binaryColorPickerComboBox24.SelectedColor = binaryPowerTabPage_Custom_EmailArchives.BackColor;
            binaryColorPickerComboBox23.SelectedColor = label46.ForeColor;
            binaryColorPickerComboBox39.SelectedColor = binaryPowerTabPage_Custom_EmailArchives.CustomStartColor;
            binaryColorPickerComboBox38.SelectedColor = binaryPowerTabPage_Custom_EmailArchives.CustomEndColor;
            binaryColorPickerComboBox37.SelectedColor = binaryPowerTabPage_Custom_EmailArchives.TabPageHeaderForeColor;
        }

        private void HandleBuiltinStyleTabCustomerMeetingsTabPageHeaderForeColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabPage_CustomerMeetings.TabPageHeaderForeColor = binaryColorPickerComboBox5.SelectedColor;
            binaryPowerTabStripUsingBuiltinStyle.Refresh();
        }

        private void HandleWelcomeTabPageHeaderForeColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabPage_Welcome.TabPageHeaderForeColor = binaryColorPickerComboBox6.SelectedColor;
            binaryPowerTabStripUsingBuiltinStyle.Refresh();
        }

        private void HandleCustomStyleTabPageSideBarFillColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingCustomStyle.TabPageSideBarFillColor = binaryColorPickerComboBoxSideBarFillColor.SelectedColor;
        }

        private void HandleUserManagementTabPageHeaderForeColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabPage_UserManagement.TabPageHeaderForeColor = binaryColorPickerComboBox7.SelectedColor;
            binaryPowerTabStripUsingBuiltinStyle.Refresh();
        }

        private void HandleBuiltinStyleTabPageHeaderForeColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingBuiltinStyle.TabPageHeaderForeColor = binaryColorPickerComboBox40.SelectedColor;

            //Set the tag page header forecolors in the individual tab page
            binaryColorPickerComboBox6.SelectedColor = binaryColorPickerComboBox40.SelectedColor;
            binaryColorPickerComboBox7.SelectedColor = binaryColorPickerComboBox40.SelectedColor;
            binaryColorPickerComboBox5.SelectedColor = binaryColorPickerComboBox40.SelectedColor;
            binaryColorPickerComboBox8.SelectedColor = binaryColorPickerComboBox40.SelectedColor;
            binaryColorPickerComboBox9.SelectedColor = binaryColorPickerComboBox40.SelectedColor;
        }

        private void HandleDatabaseReplicationTabPageHeaderForeColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabPage_DatabaseReplication.TabPageHeaderForeColor = binaryColorPickerComboBox8.SelectedColor;
            binaryPowerTabStripUsingBuiltinStyle.Refresh();
        }

        private void HandleEmailArchivesTabPageHeaderForeColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabPage_EmailArchives.TabPageHeaderForeColor = binaryColorPickerComboBox9.SelectedColor;
            binaryPowerTabStripUsingBuiltinStyle.Refresh();
        }

        private void HandleCustomUserManagementCustomStartColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabPage_Custom_UserManagement.CustomStartColor = binaryColorPickerComboBox11.SelectedColor;
            binaryPowerTabStripUsingCustomStyle.Refresh();
        }

        private void HandleCustomUserManagementCustomEndColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabPage_Custom_UserManagement.CustomEndColor = binaryColorPickerComboBox10.SelectedColor;
            binaryPowerTabStripUsingCustomStyle.Refresh();
        }

        private void HandleCustomWelcomeTabPageHeaderForeColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabPage_Custom_Welcome.TabPageHeaderForeColor = binaryColorPickerComboBox12.SelectedColor;
            binaryPowerTabStripUsingCustomStyle.Refresh();
        }

        private void HandleCustomUserManagementTabPageHeaderForeColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabPage_Custom_UserManagement.TabPageHeaderForeColor = binaryColorPickerComboBox30.SelectedColor;
            binaryPowerTabStripUsingCustomStyle.Refresh();
        }

        private void HandleCustomerMeetingsTabPageHeaderForeColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabPage_Custom_CustomerMeetings.TabPageHeaderForeColor = binaryColorPickerComboBox31.SelectedColor;
        }

        private void HandleCustomerMeetingsTabCustomStartColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabPage_Custom_CustomerMeetings.CustomStartColor = binaryColorPickerComboBox33.SelectedColor;
        }

        private void HandleCustomerMeetingsTabCustomEndColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabPage_Custom_CustomerMeetings.CustomEndColor = binaryColorPickerComboBox32.SelectedColor;
        }

        private void HandleCustomDatabaseReplicationTabPageHeaderForeColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabPage_Custom_DatabaseReplication.TabPageHeaderForeColor = binaryColorPickerComboBox34.SelectedColor;
            binaryPowerTabStripUsingCustomStyle.Refresh();
        }

        private void HandleCustomDatabaseReplicationCustomStartColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabPage_Custom_DatabaseReplication.CustomStartColor = binaryColorPickerComboBox36.SelectedColor;
            binaryPowerTabStripUsingCustomStyle.Refresh();
        }

        private void HandleCustomDatabaseReplicationCustomEndColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabPage_Custom_DatabaseReplication.CustomEndColor = binaryColorPickerComboBox35.SelectedColor;
            binaryPowerTabStripUsingCustomStyle.Refresh();
        }

        private void HandleCustomEmailArchivesTabPageHeaderForeColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabPage_Custom_EmailArchives.TabPageHeaderForeColor = binaryColorPickerComboBox37.SelectedColor;
            binaryPowerTabStripUsingCustomStyle.Refresh();
        }

        private void HandleCustomEmailArchivesCustomStartColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabPage_Custom_EmailArchives.CustomStartColor = binaryColorPickerComboBox39.SelectedColor;
            binaryPowerTabStripUsingCustomStyle.Refresh();
        }

        private void HandleCustomEmailArchivesCustomEndColorChanged(object sender, EventArgs e)
        {
            binaryPowerTabPage_Custom_EmailArchives.CustomEndColor = binaryColorPickerComboBox38.SelectedColor;
            binaryPowerTabStripUsingCustomStyle.Refresh();
        }

        private void HandleCustomTabPageRenderingStyleSelectionChanged(object sender, EventArgs e)
        {
            switch (cmbCustomTabPageRenderingStyle.SelectedIndex)
            {
                case 0:
                    binaryPowerTabStripUsingCustomStyle.TabRenderingStyle = RenderingStyle.Custom;
                    chkDrawTabPageOnTopofEachOther2.Enabled = true;
                    chkShowSideBarOnTabPageHeader.Enabled = true;
                    label21.Enabled = true;
                    binaryColorPickerComboBoxSideBarFillColor.Enabled = true;
                    break;

                case 1:
                    binaryPowerTabStripUsingCustomStyle.TabRenderingStyle = RenderingStyle.TrapeziumTop;
                    chkDrawTabPageOnTopofEachOther2.Checked = true;
                    chkDrawTabPageOnTopofEachOther2.Enabled = false;
                    chkShowSideBarOnTabPageHeader.Enabled = false;
                    label21.Enabled = false;
                    binaryColorPickerComboBoxSideBarFillColor.Enabled = false;
                    break;
            }
        }

        private void HandleTabControlGapLengthBetweenTabPageHeaderValueChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingCustomStyle.GapBetweenTabPages =
                Convert.ToInt32(numericUpDownGapLengthBetweenTabPageHeader.Value);
        }

        private void HandleTabPageRenderingLocationOptionChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingBuiltinStyle.TabPagesRenderingLocation = 
                tabPageRenderingLocationCmbBxTab1.SelectedIndex == 0 ? TabPagesRenderingLocation.Top : TabPagesRenderingLocation.Bottom;

            // Just trigger the tabstrip control to redraw itself, including its non-client areas.
            // You won't need to do this in your production code, since typically you will not be switching between the rendering location dynamically.

            binaryPowerTabStripUsingBuiltinStyle.Dock = DockStyle.Top;
            binaryPowerTabStripUsingBuiltinStyle.Dock = DockStyle.None;
        }

        private void HandleCustomTabPagesRenderignLocationCmbBx(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingCustomStyle.TabPagesRenderingLocation = 
                        customTabPagesRenderignLocationCmbBx.SelectedIndex == 0 ? TabPagesRenderingLocation.Top : TabPagesRenderingLocation.Bottom;

            // Just trigger the tabstrip control to redraw itself, including its non-client areas.
            // You won't need to do this in your production code, since typically you will not be switching between the rendering location dynamically.

            binaryPowerTabStripUsingCustomStyle.Dock = DockStyle.Top;
            binaryPowerTabStripUsingCustomStyle.Dock = DockStyle.None;
        }

        private void HandleEnableTabPageLevelCloseButtonRenderingChanged(object sender, EventArgs e)
        {
            _tabControls.Clear();
            GetTabStripControls(this);

            foreach (var tabControl in _tabControls)
            {
                if (tabControl == null) continue;

                tabControl.EnableTabPageLevelCloseButtonRendering = checkBox2.Checked;
                tabControl.Invalidate();
            }
        }

        private void GetTabStripControls(Control control)
        {
            foreach (Control c in control.Controls)
            {
                if (c is BinaryPowerTabStrip)
                {
                    _tabControls.Add(c as BinaryPowerTabStrip);
                }

                GetTabStripControls(c);
            }
        }

        private void HandleBuiltinStyledTabControlTabsOverflowChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingBuiltinStyle.TabsOverflowMode = (OverflowMode)Enum.Parse(typeof(OverflowMode),
                overflowModeCmbBx1.SelectedItem.ToString());
        }

        private void HandleCustomStyledTabControlTabsOverflowChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingCustomStyle.TabsOverflowMode = (OverflowMode)Enum.Parse(typeof(OverflowMode),
               overflowModeCmbBx2.SelectedItem.ToString());
        }

        private void HandleBuiltinStyledTabControlShouldAutoSizeTabsChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingBuiltinStyle.ShouldAutoSizeTabs = chkShoudlAutoSizeTabHeaders1.Checked;
        }

        private void HandleCustomStyledTabControlShouldAutoSizeTabsChanged(object sender, EventArgs e)
        {
            binaryPowerTabStripUsingCustomStyle.ShouldAutoSizeTabs = chkShouldAutoSizeTabHeaders2.Checked;
        }
    }
}