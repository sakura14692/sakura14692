﻿namespace MultiLineTabControlDemo
{
    partial class MultiLineTabControlDemoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Drawing.StringFormat stringFormat1 = new System.Drawing.StringFormat();
            System.Drawing.StringFormat stringFormat2 = new System.Drawing.StringFormat();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MultiLineTabControlDemoForm));
            this.label1 = new System.Windows.Forms.Label();
            this.binaryPowerTabStrip2 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabStrip();
            this.binaryPowerTabPage6 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.binaryPowerTabPage7 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.binaryPowerTabPage8 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.binaryPowerTabPage9 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.binaryPowerTabPage10 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.binaryPowerTabPage11 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.binaryPowerTabStrip1 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabStrip();
            this.binaryPowerTabPage1 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.binaryPowerTabPage2 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.binaryPowerTabPage3 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.binaryPowerTabPage4 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.binaryPowerTabPage5 = new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage();
            this.binaryPowerTabStrip2.SuspendLayout();
            this.binaryPowerTabStrip1.SuspendLayout();
            this.binaryPowerTabPage2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(680, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Binarymission PowerTabStrip instances: Drawing its tab page header text in multip" +
    "le lines (if need be)";
            // 
            // binaryPowerTabStrip2
            // 
            this.binaryPowerTabStrip2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.binaryPowerTabStrip2.Cursor = System.Windows.Forms.Cursors.Default;
            this.binaryPowerTabStrip2.CustomEndColor = System.Drawing.Color.White;
            this.binaryPowerTabStrip2.CustomStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.binaryPowerTabStrip2.DrawBorderAroundTabStrip = false;
            this.binaryPowerTabStrip2.DrawTabPageOnTopOfEachOther = false;
            this.binaryPowerTabStrip2.EmptySpaceLengthBeforeTheFirstTabPage = 8;
            this.binaryPowerTabStrip2.EnableAutomaticUpdateOfTabPagesHeaderSize = false;
            this.binaryPowerTabStrip2.EnableControlledLayoutRendering = false;
            this.binaryPowerTabStrip2.EnableDragAndDropOfTabPages = false;
            this.binaryPowerTabStrip2.EnableTabPageLevelCloseButtonRendering = true;
            this.binaryPowerTabStrip2.ExtendedWindowsXPRenderingFirstColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.binaryPowerTabStrip2.ExtendedWindowsXPRenderingSecondColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.binaryPowerTabStrip2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabStrip2.HeaderFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabStrip2.HeaderTextCloseButtonExtraGap = 8;
            this.binaryPowerTabStrip2.IsBackgroundTransparent = false;
            this.binaryPowerTabStrip2.KeepShowingTooltipEvenWhenMousePointerIsMoving = false;
            this.binaryPowerTabStrip2.Location = new System.Drawing.Point(16, 417);
            this.binaryPowerTabStrip2.Name = "binaryPowerTabStrip2";
            this.binaryPowerTabStrip2.NewlyAddedPagesAreLocatedAtLeftCorner = false;
            this.binaryPowerTabStrip2.PreventInvalidation = false;
            this.binaryPowerTabStrip2.RenderFullTextForTabPageHeader = true;
            this.binaryPowerTabStrip2.SelectedPageHeaderTextIsRenderedBold = false;
            this.binaryPowerTabStrip2.SelectedTabPageHeaderFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabStrip2.ShouldAutoSizeTabs = true;
            this.binaryPowerTabStrip2.ShouldDrawTabPageHeaderInMultiLines = true;
            this.binaryPowerTabStrip2.ShouldUpdateUponParentMove = false;
            this.binaryPowerTabStrip2.ShouldUpdateUponParentResize = false;
            this.binaryPowerTabStrip2.ShowToolTip = true;
            this.binaryPowerTabStrip2.Size = new System.Drawing.Size(817, 321);
            this.binaryPowerTabStrip2.TabBottomOrientationCloseButtonPosition = Binarymission.WinForms.Controls.TabControls.CloseButtonPosition.Bottom;
            stringFormat1.Alignment = System.Drawing.StringAlignment.Center;
            stringFormat1.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat1.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat1.Trimming = System.Drawing.StringTrimming.EllipsisCharacter;
            this.binaryPowerTabStrip2.TabHeaderStringFormat = stringFormat1;
            this.binaryPowerTabStrip2.TabIndex = 2;
            this.binaryPowerTabStrip2.TabPageBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(181)))), ((int)(((byte)(226)))));
            this.binaryPowerTabStrip2.TabPageCloseButtonMouseEnterColor = System.Drawing.Color.Red;
            this.binaryPowerTabStrip2.TabPageCloseButtonRectangleBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryPowerTabStrip2.TabPageCloseButtonRectangleFillColor = System.Drawing.SystemColors.Highlight;
            this.binaryPowerTabStrip2.TabPageCurrentSelectionIndicatorEndColor = System.Drawing.Color.White;
            this.binaryPowerTabStrip2.TabPageCurrentSelectionIndicatorStartColor = System.Drawing.Color.Orange;
            this.binaryPowerTabStrip2.TabPageHeaderDrawingGradientOrientation = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.binaryPowerTabStrip2.TabPageHeaderForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabStrip2.TabPageHeaderHeight = 75;
            this.binaryPowerTabStrip2.TabPageHeaderShowsSideBar = false;
            this.binaryPowerTabStrip2.TabPageHeaderTextFontOverridesControlDefault = false;
            this.binaryPowerTabStrip2.TabPageHeaderWidth = 285;
            this.binaryPowerTabStrip2.TabPages.AddRange(new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage[] {
            this.binaryPowerTabPage6,
            this.binaryPowerTabPage7,
            this.binaryPowerTabPage8,
            this.binaryPowerTabPage9,
            this.binaryPowerTabPage10,
            this.binaryPowerTabPage11});
            this.binaryPowerTabStrip2.TabPagesCloseButtonColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabStrip2.TabPagesHaveGapBetweenThem = false;
            this.binaryPowerTabStrip2.TabPageSideBarFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.binaryPowerTabStrip2.TabPagesOverflowCalculationStrategy = Binarymission.WinForms.Controls.TabControls.TabPagesOverflowCalculationStrategy.Pessimistic;
            this.binaryPowerTabStrip2.TabPagesOverFlowMenuDropDownColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabStrip2.TabPagesOverFlowMenuGlyphActiveRectangleBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryPowerTabStrip2.TabPagesOverFlowMenuGlyphActiveRectangleFillColor = System.Drawing.SystemColors.Highlight;
            this.binaryPowerTabStrip2.TabPagesRenderingLocation = Binarymission.WinForms.Controls.TabControls.TabPagesRenderingLocation.Top;
            this.binaryPowerTabStrip2.TabRenderingStyle = Binarymission.WinForms.Controls.TabControls.RenderingStyle.ExtendedWindowsXP;
            this.binaryPowerTabStrip2.TabsOverflowMode = Binarymission.WinForms.Controls.TabControls.OverflowMode.Menu;
            this.binaryPowerTabStrip2.Text = "binaryPowerTabStrip2";
            this.binaryPowerTabStrip2.ThemeBorderColorCanBeOverridden = false;
            this.binaryPowerTabStrip2.ToolTipConfiguration.AutomaticDelay = 500;
            this.binaryPowerTabStrip2.ToolTipConfiguration.AutoPopDelay = 5000;
            this.binaryPowerTabStrip2.ToolTipConfiguration.BackColor = System.Drawing.SystemColors.Info;
            this.binaryPowerTabStrip2.ToolTipConfiguration.ForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabStrip2.ToolTipConfiguration.InitialDelay = 500;
            this.binaryPowerTabStrip2.ToolTipConfiguration.IsBalloon = false;
            this.binaryPowerTabStrip2.ToolTipConfiguration.ReshowDelay = 100;
            this.binaryPowerTabStrip2.ToolTipConfiguration.StripAmpersands = false;
            this.binaryPowerTabStrip2.ToolTipConfiguration.ToolTipIcon = System.Windows.Forms.ToolTipIcon.None;
            this.binaryPowerTabStrip2.ToolTipConfiguration.ToolTipTitle = "";
            this.binaryPowerTabStrip2.ToolTipConfiguration.UseAnimation = false;
            this.binaryPowerTabStrip2.ToolTipConfiguration.UseFading = false;
            this.binaryPowerTabStrip2.UseTabCurrentSelectionIndicatorColor = true;
            // 
            // binaryPowerTabPage6
            // 
            this.binaryPowerTabPage6.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage6.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(145)))), ((int)(((byte)(155)))), ((int)(((byte)(156)))));
            this.binaryPowerTabPage6.BorderSize = 1;
            this.binaryPowerTabPage6.CurrentlySelected = true;
            this.binaryPowerTabPage6.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage6.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage6.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage6.IsBackgroundTransparent = false;
            this.binaryPowerTabPage6.IsHeaderEnabled = true;
            this.binaryPowerTabPage6.Name = "binaryPowerTabPage6";
            this.binaryPowerTabPage6.ShouldRenderCloseButton = true;
            this.binaryPowerTabPage6.Size = new System.Drawing.Size(815, 244);
            this.binaryPowerTabPage6.TabIndex = 0;
            this.binaryPowerTabPage6.TabPageContentIsDirty = false;
            this.binaryPowerTabPage6.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage6.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage6.Text = "A very long text for the tab page header that is very lengthy read";
            this.binaryPowerTabPage6.ToolTipText = "";
            // 
            // binaryPowerTabPage7
            // 
            this.binaryPowerTabPage7.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage7.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(145)))), ((int)(((byte)(155)))), ((int)(((byte)(156)))));
            this.binaryPowerTabPage7.BorderSize = 1;
            this.binaryPowerTabPage7.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage7.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage7.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage7.IsBackgroundTransparent = false;
            this.binaryPowerTabPage7.IsHeaderEnabled = true;
            this.binaryPowerTabPage7.Name = "binaryPowerTabPage7";
            this.binaryPowerTabPage7.ShouldRenderCloseButton = true;
            this.binaryPowerTabPage7.Size = new System.Drawing.Size(815, 244);
            this.binaryPowerTabPage7.TabIndex = 1;
            this.binaryPowerTabPage7.TabPageContentIsDirty = false;
            this.binaryPowerTabPage7.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage7.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage7.Text = "Another sample tab page";
            this.binaryPowerTabPage7.ToolTipText = "";
            // 
            // binaryPowerTabPage8
            // 
            this.binaryPowerTabPage8.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage8.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(145)))), ((int)(((byte)(155)))), ((int)(((byte)(156)))));
            this.binaryPowerTabPage8.BorderSize = 1;
            this.binaryPowerTabPage8.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage8.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage8.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage8.IsBackgroundTransparent = false;
            this.binaryPowerTabPage8.IsHeaderEnabled = true;
            this.binaryPowerTabPage8.Name = "binaryPowerTabPage8";
            this.binaryPowerTabPage8.ShouldRenderCloseButton = true;
            this.binaryPowerTabPage8.Size = new System.Drawing.Size(822, 170);
            this.binaryPowerTabPage8.TabIndex = 2;
            this.binaryPowerTabPage8.TabPageContentIsDirty = false;
            this.binaryPowerTabPage8.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage8.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage8.Text = "Music";
            this.binaryPowerTabPage8.ToolTipText = "";
            // 
            // binaryPowerTabPage9
            // 
            this.binaryPowerTabPage9.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage9.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.binaryPowerTabPage9.BorderSize = 1;
            this.binaryPowerTabPage9.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage9.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage9.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage9.IsBackgroundTransparent = false;
            this.binaryPowerTabPage9.IsHeaderEnabled = true;
            this.binaryPowerTabPage9.Name = "binaryPowerTabPage9";
            this.binaryPowerTabPage9.ShouldRenderCloseButton = true;
            this.binaryPowerTabPage9.Size = new System.Drawing.Size(822, 170);
            this.binaryPowerTabPage9.TabIndex = 3;
            this.binaryPowerTabPage9.TabPageContentIsDirty = false;
            this.binaryPowerTabPage9.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage9.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage9.Text = "Videos";
            this.binaryPowerTabPage9.ToolTipText = "";
            // 
            // binaryPowerTabPage10
            // 
            this.binaryPowerTabPage10.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage10.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.binaryPowerTabPage10.BorderSize = 1;
            this.binaryPowerTabPage10.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage10.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage10.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage10.IsBackgroundTransparent = false;
            this.binaryPowerTabPage10.IsHeaderEnabled = true;
            this.binaryPowerTabPage10.Name = "binaryPowerTabPage10";
            this.binaryPowerTabPage10.ShouldRenderCloseButton = true;
            this.binaryPowerTabPage10.Size = new System.Drawing.Size(822, 170);
            this.binaryPowerTabPage10.TabIndex = 4;
            this.binaryPowerTabPage10.TabPageContentIsDirty = false;
            this.binaryPowerTabPage10.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage10.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage10.Text = "Art";
            this.binaryPowerTabPage10.ToolTipText = "";
            // 
            // binaryPowerTabPage11
            // 
            this.binaryPowerTabPage11.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage11.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.binaryPowerTabPage11.BorderSize = 1;
            this.binaryPowerTabPage11.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage11.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage11.HeaderTextFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage11.IsBackgroundTransparent = false;
            this.binaryPowerTabPage11.IsHeaderEnabled = true;
            this.binaryPowerTabPage11.Name = "binaryPowerTabPage11";
            this.binaryPowerTabPage11.ShouldRenderCloseButton = false;
            this.binaryPowerTabPage11.Size = new System.Drawing.Size(822, 170);
            this.binaryPowerTabPage11.TabIndex = 5;
            this.binaryPowerTabPage11.TabPageContentIsDirty = false;
            this.binaryPowerTabPage11.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage11.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage11.Text = "Books";
            this.binaryPowerTabPage11.ToolTipText = "";
            // 
            // binaryPowerTabStrip1
            // 
            this.binaryPowerTabStrip1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.binaryPowerTabStrip1.Cursor = System.Windows.Forms.Cursors.Default;
            this.binaryPowerTabStrip1.CustomEndColor = System.Drawing.Color.White;
            this.binaryPowerTabStrip1.CustomStartColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.binaryPowerTabStrip1.DrawBorderAroundTabStrip = false;
            this.binaryPowerTabStrip1.DrawTabPageOnTopOfEachOther = true;
            this.binaryPowerTabStrip1.EmptySpaceLengthBeforeTheFirstTabPage = 8;
            this.binaryPowerTabStrip1.EnableAutomaticUpdateOfTabPagesHeaderSize = false;
            this.binaryPowerTabStrip1.EnableControlledLayoutRendering = false;
            this.binaryPowerTabStrip1.EnableDragAndDropOfTabPages = false;
            this.binaryPowerTabStrip1.EnableTabPageLevelCloseButtonRendering = true;
            this.binaryPowerTabStrip1.ExtendedWindowsXPRenderingFirstColor = System.Drawing.Color.Blue;
            this.binaryPowerTabStrip1.ExtendedWindowsXPRenderingSecondColor = System.Drawing.Color.LightBlue;
            this.binaryPowerTabStrip1.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabStrip1.HeaderFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabStrip1.HeaderTextCloseButtonExtraGap = 8;
            this.binaryPowerTabStrip1.IsBackgroundTransparent = false;
            this.binaryPowerTabStrip1.KeepShowingTooltipEvenWhenMousePointerIsMoving = false;
            this.binaryPowerTabStrip1.Location = new System.Drawing.Point(12, 58);
            this.binaryPowerTabStrip1.Name = "binaryPowerTabStrip1";
            this.binaryPowerTabStrip1.NewlyAddedPagesAreLocatedAtLeftCorner = false;
            this.binaryPowerTabStrip1.PreventInvalidation = false;
            this.binaryPowerTabStrip1.RenderFullTextForTabPageHeader = true;
            this.binaryPowerTabStrip1.SelectedPageHeaderTextIsRenderedBold = false;
            this.binaryPowerTabStrip1.SelectedTabPageHeaderFont = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabStrip1.ShouldAutoSizeTabs = false;
            this.binaryPowerTabStrip1.ShouldDrawTabPageHeaderInMultiLines = true;
            this.binaryPowerTabStrip1.ShouldUpdateUponParentMove = false;
            this.binaryPowerTabStrip1.ShouldUpdateUponParentResize = false;
            this.binaryPowerTabStrip1.ShowToolTip = true;
            this.binaryPowerTabStrip1.Size = new System.Drawing.Size(823, 326);
            this.binaryPowerTabStrip1.TabBottomOrientationCloseButtonPosition = Binarymission.WinForms.Controls.TabControls.CloseButtonPosition.Bottom;
            stringFormat2.Alignment = System.Drawing.StringAlignment.Center;
            stringFormat2.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat2.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat2.Trimming = System.Drawing.StringTrimming.EllipsisCharacter;
            this.binaryPowerTabStrip1.TabHeaderStringFormat = stringFormat2;
            this.binaryPowerTabStrip1.TabIndex = 0;
            this.binaryPowerTabStrip1.TabPageBorderColor = System.Drawing.SystemColors.ControlDark;
            this.binaryPowerTabStrip1.TabPageCloseButtonMouseEnterColor = System.Drawing.Color.Red;
            this.binaryPowerTabStrip1.TabPageCloseButtonRectangleBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryPowerTabStrip1.TabPageCloseButtonRectangleFillColor = System.Drawing.SystemColors.Highlight;
            this.binaryPowerTabStrip1.TabPageCurrentSelectionIndicatorEndColor = System.Drawing.Color.White;
            this.binaryPowerTabStrip1.TabPageCurrentSelectionIndicatorStartColor = System.Drawing.Color.Orange;
            this.binaryPowerTabStrip1.TabPageHeaderDrawingGradientOrientation = System.Drawing.Drawing2D.LinearGradientMode.Vertical;
            this.binaryPowerTabStrip1.TabPageHeaderForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabStrip1.TabPageHeaderHeight = 62;
            this.binaryPowerTabStrip1.TabPageHeaderShowsSideBar = false;
            this.binaryPowerTabStrip1.TabPageHeaderTextFontOverridesControlDefault = false;
            this.binaryPowerTabStrip1.TabPageHeaderWidth = 282;
            this.binaryPowerTabStrip1.TabPages.AddRange(new Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage[] {
            this.binaryPowerTabPage1,
            this.binaryPowerTabPage2,
            this.binaryPowerTabPage3,
            this.binaryPowerTabPage4,
            this.binaryPowerTabPage5});
            this.binaryPowerTabStrip1.TabPagesCloseButtonColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabStrip1.TabPagesHaveGapBetweenThem = false;
            this.binaryPowerTabStrip1.TabPageSideBarFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.binaryPowerTabStrip1.TabPagesOverflowCalculationStrategy = Binarymission.WinForms.Controls.TabControls.TabPagesOverflowCalculationStrategy.Pessimistic;
            this.binaryPowerTabStrip1.TabPagesOverFlowMenuDropDownColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabStrip1.TabPagesOverFlowMenuGlyphActiveRectangleBorderColor = System.Drawing.SystemColors.Highlight;
            this.binaryPowerTabStrip1.TabPagesOverFlowMenuGlyphActiveRectangleFillColor = System.Drawing.SystemColors.Highlight;
            this.binaryPowerTabStrip1.TabPagesRenderingLocation = Binarymission.WinForms.Controls.TabControls.TabPagesRenderingLocation.Top;
            this.binaryPowerTabStrip1.TabRenderingStyle = Binarymission.WinForms.Controls.TabControls.RenderingStyle.VisualStudio2008;
            this.binaryPowerTabStrip1.TabsOverflowMode = Binarymission.WinForms.Controls.TabControls.OverflowMode.MultiLine;
            this.binaryPowerTabStrip1.Text = "binaryPowerTabStrip1";
            this.binaryPowerTabStrip1.ThemeBorderColorCanBeOverridden = false;
            this.binaryPowerTabStrip1.ToolTipConfiguration.AutomaticDelay = 500;
            this.binaryPowerTabStrip1.ToolTipConfiguration.AutoPopDelay = 5000;
            this.binaryPowerTabStrip1.ToolTipConfiguration.BackColor = System.Drawing.SystemColors.Info;
            this.binaryPowerTabStrip1.ToolTipConfiguration.ForeColor = System.Drawing.SystemColors.WindowText;
            this.binaryPowerTabStrip1.ToolTipConfiguration.InitialDelay = 500;
            this.binaryPowerTabStrip1.ToolTipConfiguration.IsBalloon = false;
            this.binaryPowerTabStrip1.ToolTipConfiguration.ReshowDelay = 100;
            this.binaryPowerTabStrip1.ToolTipConfiguration.StripAmpersands = false;
            this.binaryPowerTabStrip1.ToolTipConfiguration.ToolTipIcon = System.Windows.Forms.ToolTipIcon.None;
            this.binaryPowerTabStrip1.ToolTipConfiguration.ToolTipTitle = "";
            this.binaryPowerTabStrip1.ToolTipConfiguration.UseAnimation = false;
            this.binaryPowerTabStrip1.ToolTipConfiguration.UseFading = false;
            this.binaryPowerTabStrip1.UseTabCurrentSelectionIndicatorColor = true;
            // 
            // binaryPowerTabPage1
            // 
            this.binaryPowerTabPage1.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(181)))), ((int)(((byte)(226)))));
            this.binaryPowerTabPage1.BorderSize = 0;
            this.binaryPowerTabPage1.CurrentlySelected = true;
            this.binaryPowerTabPage1.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage1.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage1.HeaderTextFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage1.Image = ((System.Drawing.Image)(resources.GetObject("binaryPowerTabPage1.Image")));
            this.binaryPowerTabPage1.IsBackgroundTransparent = false;
            this.binaryPowerTabPage1.IsHeaderEnabled = true;
            this.binaryPowerTabPage1.Name = "binaryPowerTabPage1";
            this.binaryPowerTabPage1.ShouldRenderCloseButton = false;
            this.binaryPowerTabPage1.Size = new System.Drawing.Size(821, 139);
            this.binaryPowerTabPage1.TabIndex = 0;
            this.binaryPowerTabPage1.TabPageContentIsDirty = false;
            this.binaryPowerTabPage1.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage1.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage1.Text = "Lab reports. This will list all patient care information available";
            this.binaryPowerTabPage1.ToolTipText = "";
            // 
            // binaryPowerTabPage2
            // 
            this.binaryPowerTabPage2.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage2.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.binaryPowerTabPage2.BorderSize = 0;
            this.binaryPowerTabPage2.Controls.Add(this.panel1);
            this.binaryPowerTabPage2.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage2.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage2.HeaderTextFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage2.Image = ((System.Drawing.Image)(resources.GetObject("binaryPowerTabPage2.Image")));
            this.binaryPowerTabPage2.IsBackgroundTransparent = false;
            this.binaryPowerTabPage2.IsHeaderEnabled = true;
            this.binaryPowerTabPage2.Name = "binaryPowerTabPage2";
            this.binaryPowerTabPage2.ShouldRenderCloseButton = true;
            this.binaryPowerTabPage2.Size = new System.Drawing.Size(821, 139);
            this.binaryPowerTabPage2.TabIndex = 1;
            this.binaryPowerTabPage2.TabPageContentIsDirty = false;
            this.binaryPowerTabPage2.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage2.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage2.Text = "Test reports";
            this.binaryPowerTabPage2.ToolTipText = "";
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(1, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(819, 137);
            this.panel1.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(13, 91);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(210, 32);
            this.button1.TabIndex = 0;
            this.button1.Text = "SomeCommand";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // binaryPowerTabPage3
            // 
            this.binaryPowerTabPage3.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage3.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.binaryPowerTabPage3.BorderSize = 0;
            this.binaryPowerTabPage3.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage3.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage3.HeaderTextFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage3.Image = ((System.Drawing.Image)(resources.GetObject("binaryPowerTabPage3.Image")));
            this.binaryPowerTabPage3.IsBackgroundTransparent = false;
            this.binaryPowerTabPage3.IsHeaderEnabled = true;
            this.binaryPowerTabPage3.Name = "binaryPowerTabPage3";
            this.binaryPowerTabPage3.ShouldRenderCloseButton = true;
            this.binaryPowerTabPage3.Size = new System.Drawing.Size(821, 139);
            this.binaryPowerTabPage3.TabIndex = 2;
            this.binaryPowerTabPage3.TabPageContentIsDirty = false;
            this.binaryPowerTabPage3.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage3.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage3.Text = "Diagnosis: The list can be filtered by patient name and/or other parameters";
            this.binaryPowerTabPage3.ToolTipText = "";
            // 
            // binaryPowerTabPage4
            // 
            this.binaryPowerTabPage4.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage4.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.binaryPowerTabPage4.BorderSize = 0;
            this.binaryPowerTabPage4.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage4.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage4.HeaderTextFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage4.Image = ((System.Drawing.Image)(resources.GetObject("binaryPowerTabPage4.Image")));
            this.binaryPowerTabPage4.IsBackgroundTransparent = false;
            this.binaryPowerTabPage4.IsHeaderEnabled = true;
            this.binaryPowerTabPage4.Name = "binaryPowerTabPage4";
            this.binaryPowerTabPage4.ShouldRenderCloseButton = true;
            this.binaryPowerTabPage4.Size = new System.Drawing.Size(1017, 146);
            this.binaryPowerTabPage4.TabIndex = 3;
            this.binaryPowerTabPage4.TabPageContentIsDirty = false;
            this.binaryPowerTabPage4.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage4.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage4.Text = "Report: In-patients";
            this.binaryPowerTabPage4.ToolTipText = "";
            // 
            // binaryPowerTabPage5
            // 
            this.binaryPowerTabPage5.BackColor = System.Drawing.SystemColors.Window;
            this.binaryPowerTabPage5.BorderColor = System.Drawing.SystemColors.ControlDark;
            this.binaryPowerTabPage5.BorderSize = 0;
            this.binaryPowerTabPage5.CustomEndColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage5.CustomStartColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage5.HeaderTextFont = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.binaryPowerTabPage5.Image = ((System.Drawing.Image)(resources.GetObject("binaryPowerTabPage5.Image")));
            this.binaryPowerTabPage5.IsBackgroundTransparent = false;
            this.binaryPowerTabPage5.IsHeaderEnabled = true;
            this.binaryPowerTabPage5.Name = "binaryPowerTabPage5";
            this.binaryPowerTabPage5.ShouldRenderCloseButton = true;
            this.binaryPowerTabPage5.Size = new System.Drawing.Size(740, 175);
            this.binaryPowerTabPage5.TabIndex = 4;
            this.binaryPowerTabPage5.TabPageContentIsDirty = false;
            this.binaryPowerTabPage5.TabPageHeaderForeColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage5.TabPageSideBarFillColor = System.Drawing.Color.Empty;
            this.binaryPowerTabPage5.Text = "Report: Out-patients";
            this.binaryPowerTabPage5.ToolTipText = "";
            // 
            // MultiLineTabControlDemoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(858, 791);
            this.Controls.Add(this.binaryPowerTabStrip2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.binaryPowerTabStrip1);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MultiLineTabControlDemoForm";
            this.TitlebarText = "Binarymission PowerTabStrip Multi-line tab header Demo";
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.SlateGray;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this.binaryPowerTabStrip2.ResumeLayout(false);
            this.binaryPowerTabStrip1.ResumeLayout(false);
            this.binaryPowerTabPage2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabStrip binaryPowerTabStrip1;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage1;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage2;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage3;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage4;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabStrip binaryPowerTabStrip2;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage6;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage7;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage8;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage9;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage10;
        private Binarymission.WinForms.Controls.TabControls.BinaryPowerTabPage binaryPowerTabPage11;

    }
}

