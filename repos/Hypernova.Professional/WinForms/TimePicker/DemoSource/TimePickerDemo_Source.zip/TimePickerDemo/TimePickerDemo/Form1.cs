﻿using System;
using System.Windows.Forms;
using Binarymission.WinForms.Controls.AdvancedSelectors.TimeSelectors.Data;

namespace TimePickerDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Initialize();
            txtTwelveHourTimeDisplayFormat.TextChanged += txtTwelveHourTimeDisplayFormat_TextChanged;
            txtTwentyFourHourTimeDisplayFormat.TextChanged += txtTwentyFourHourTimeDisplayFormat_TextChanged;
        }
        
        private void Initialize()
        {
            timePicker1.TimeValue = DateTime.Now;
            txtTwelveHourTimeDisplayFormat.Text = timePicker1.TwelveHoursTimeDisplayFormat;
            txtTwentyFourHourTimeDisplayFormat.Text = timePicker1.TwentyFourHoursTimeDisplayFormat;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void rdTimeConventionTwelveHours_CheckedChanged(object sender, EventArgs e)
        {
            if(rdTimeConventionTwelveHours.Checked)
                timePicker1.TimeConvention = TimeConvention.TwelveHours;
        }

        private void rdTimeConventionTwentyFourHours_CheckedChanged(object sender, EventArgs e)
        {
            if(rdTimeConventionTwentyFourHours.Checked)
                timePicker1.TimeConvention = TimeConvention.TwentyFourHours;
        }

        private void chkEnableDropDownResizing_CheckedChanged(object sender, EventArgs e)
        {
            timePicker1.DropDownHostConfiguration.EnableDropDownResizing = chkEnableDropDownResizing.Checked;
            chkShouldRememberUserDropDownSizing.Enabled =
                chkEnableDropDownResizing.Checked && chkEnableDropDownResizing.Enabled;
        }

        private void chkShouldRememberUserDropDownSizing_CheckedChanged(object sender, EventArgs e)
        {
            timePicker1.DropDownHostConfiguration.ShouldRememberUserSizedDropDownSize =
                chkShouldRememberUserDropDownSizing.Checked;
        }

        private void txtTwelveHourTimeDisplayFormat_TextChanged(object sender, EventArgs e)
        {
            timePicker1.TwelveHoursTimeDisplayFormat = txtTwelveHourTimeDisplayFormat.Text;
        }

        private void txtTwentyFourHourTimeDisplayFormat_TextChanged(object sender, EventArgs e)
        {
            timePicker1.TwentyFourHoursTimeDisplayFormat = txtTwentyFourHourTimeDisplayFormat.Text;
        }

        private void msTimeHost_ValueChanged(object sender, EventArgs e)
        {
            timePicker1.TimeValue = msTimeHost.Value;
        }

        private void chkShowSpinnerButtonsInFullSize_CheckedChanged(object sender, EventArgs e)
        {
            timePicker1.ShouldDrawSpinnerButtonsInFullSize = chkShowSpinnerButtonsInFullSize.Checked;
        }

        private void spinnerMousePresTimeChangeTriggerSpeed_ValueChanged(object sender, EventArgs e)
        {
            timePicker1.MousePressedValueChangeTriggerSpeed = (int)spinnerMousePresTimeChangeTriggerSpeed.Value;
        }

        private void chkEnforceTimeOnlyFormats_CheckedChanged(object sender, EventArgs e)
        {
            timePicker1.EnforceTimeOnlyFormats = chkEnforceTimeOnlyFormats.Checked;
        }

        private void timePickerIntervalSpinner_ValueChanged(object sender, EventArgs e)
        {
            timePicker1.Interval = timePickerIntervalSpinner.Value;
        }

        private void txtAnteMeridianValue_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtAnteMeridianValue.Text))
            {
                timePicker1.AnteMeridianValue = txtAnteMeridianValue.Text.Trim();
            }
        }

        private void txtPostMeridianValue_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtPostMeridianValue.Text))
            {
                timePicker1.PostMeridianValue = txtPostMeridianValue.Text.Trim();
            }
        }
    }
}
