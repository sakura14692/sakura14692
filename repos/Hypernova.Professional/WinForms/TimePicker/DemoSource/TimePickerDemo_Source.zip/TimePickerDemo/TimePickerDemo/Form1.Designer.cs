﻿using System.ComponentModel;

namespace TimePickerDemo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Drawing.StringFormat stringFormat1 = new System.Drawing.StringFormat();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtPostMeridianValue = new System.Windows.Forms.TextBox();
            this.txtAnteMeridianValue = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.chkEnforceTimeOnlyFormats = new System.Windows.Forms.CheckBox();
            this.label17 = new System.Windows.Forms.Label();
            this.spinnerMousePresTimeChangeTriggerSpeed = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.timePickerIntervalSpinner = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.chkShowSpinnerButtonsInFullSize = new System.Windows.Forms.CheckBox();
            this.msTimeHost = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtTwelveHourTimeDisplayFormat = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txtTwentyFourHourTimeDisplayFormat = new System.Windows.Forms.TextBox();
            this.chkShouldRememberUserDropDownSizing = new System.Windows.Forms.CheckBox();
            this.label15 = new System.Windows.Forms.Label();
            this.chkEnableDropDownResizing = new System.Windows.Forms.CheckBox();
            this.rdTimeConventionTwentyFourHours = new System.Windows.Forms.RadioButton();
            this.rdTimeConventionTwelveHours = new System.Windows.Forms.RadioButton();
            this.label16 = new System.Windows.Forms.Label();
            this.timePicker1 = new Binarymission.WinForms.Controls.AdvancedSelectors.TimeSelectors.Core.TimePickerDropDown();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spinnerMousePresTimeChangeTriggerSpeed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.timePickerIntervalSpinner)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label1.Location = new System.Drawing.Point(12, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(204, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "TimePicker control instance:";
            // 
            // btnExit
            // 
            this.btnExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnExit.Location = new System.Drawing.Point(881, 660);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(89, 30);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox2.Controls.Add(this.txtPostMeridianValue);
            this.groupBox2.Controls.Add(this.txtAnteMeridianValue);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.chkEnforceTimeOnlyFormats);
            this.groupBox2.Controls.Add(this.label17);
            this.groupBox2.Controls.Add(this.spinnerMousePresTimeChangeTriggerSpeed);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.timePickerIntervalSpinner);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.chkShowSpinnerButtonsInFullSize);
            this.groupBox2.Controls.Add(this.msTimeHost);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.txtTwelveHourTimeDisplayFormat);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.txtTwentyFourHourTimeDisplayFormat);
            this.groupBox2.Controls.Add(this.chkShouldRememberUserDropDownSizing);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.chkEnableDropDownResizing);
            this.groupBox2.Controls.Add(this.rdTimeConventionTwentyFourHours);
            this.groupBox2.Controls.Add(this.rdTimeConventionTwelveHours);
            this.groupBox2.Controls.Add(this.label16);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(297, 62);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(673, 581);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Options";
            // 
            // txtPostMeridianValue
            // 
            this.txtPostMeridianValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPostMeridianValue.Location = new System.Drawing.Point(404, 280);
            this.txtPostMeridianValue.Name = "txtPostMeridianValue";
            this.txtPostMeridianValue.Size = new System.Drawing.Size(157, 22);
            this.txtPostMeridianValue.TabIndex = 24;
            this.txtPostMeridianValue.Text = "PM";
            this.txtPostMeridianValue.TextChanged += new System.EventHandler(this.txtPostMeridianValue_TextChanged);
            // 
            // txtAnteMeridianValue
            // 
            this.txtAnteMeridianValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAnteMeridianValue.Location = new System.Drawing.Point(404, 252);
            this.txtAnteMeridianValue.Name = "txtAnteMeridianValue";
            this.txtAnteMeridianValue.Size = new System.Drawing.Size(157, 22);
            this.txtAnteMeridianValue.TabIndex = 23;
            this.txtAnteMeridianValue.Text = "AM";
            this.txtAnteMeridianValue.TextChanged += new System.EventHandler(this.txtAnteMeridianValue_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label4.Location = new System.Drawing.Point(255, 283);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(140, 16);
            this.label4.TabIndex = 22;
            this.label4.Text = "Text for Post Meridian:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label3.Location = new System.Drawing.Point(255, 255);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(140, 16);
            this.label3.TabIndex = 21;
            this.label3.Text = "Text for Ante Meridian:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label2.Location = new System.Drawing.Point(234, 229);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(188, 16);
            this.label2.TabIndex = 20;
            this.label2.Text = "Setup custom AM / PM values:";
            // 
            // chkEnforceTimeOnlyFormats
            // 
            this.chkEnforceTimeOnlyFormats.AutoSize = true;
            this.chkEnforceTimeOnlyFormats.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkEnforceTimeOnlyFormats.Location = new System.Drawing.Point(236, 178);
            this.chkEnforceTimeOnlyFormats.Name = "chkEnforceTimeOnlyFormats";
            this.chkEnforceTimeOnlyFormats.Size = new System.Drawing.Size(310, 20);
            this.chkEnforceTimeOnlyFormats.TabIndex = 19;
            this.chkEnforceTimeOnlyFormats.Text = "Should automatically enforce time-only formats?";
            this.chkEnforceTimeOnlyFormats.UseVisualStyleBackColor = true;
            this.chkEnforceTimeOnlyFormats.CheckedChanged += new System.EventHandler(this.chkEnforceTimeOnlyFormats_CheckedChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(570, 468);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(75, 16);
            this.label17.TabIndex = 18;
            this.label17.Text = "(milli-secs.)";
            // 
            // spinnerMousePresTimeChangeTriggerSpeed
            // 
            this.spinnerMousePresTimeChangeTriggerSpeed.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.spinnerMousePresTimeChangeTriggerSpeed.Location = new System.Drawing.Point(505, 465);
            this.spinnerMousePresTimeChangeTriggerSpeed.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.spinnerMousePresTimeChangeTriggerSpeed.Minimum = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.spinnerMousePresTimeChangeTriggerSpeed.Name = "spinnerMousePresTimeChangeTriggerSpeed";
            this.spinnerMousePresTimeChangeTriggerSpeed.Size = new System.Drawing.Size(59, 22);
            this.spinnerMousePresTimeChangeTriggerSpeed.TabIndex = 17;
            this.spinnerMousePresTimeChangeTriggerSpeed.Value = new decimal(new int[] {
            350,
            0,
            0,
            0});
            this.spinnerMousePresTimeChangeTriggerSpeed.ValueChanged += new System.EventHandler(this.spinnerMousePresTimeChangeTriggerSpeed_ValueChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(234, 468);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(248, 16);
            this.label9.TabIndex = 16;
            this.label9.Text = "Mouse press time change trigger speed:";
            // 
            // timePickerIntervalSpinner
            // 
            this.timePickerIntervalSpinner.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.timePickerIntervalSpinner.Location = new System.Drawing.Point(505, 430);
            this.timePickerIntervalSpinner.Maximum = new decimal(new int[] {
            23,
            0,
            0,
            0});
            this.timePickerIntervalSpinner.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.timePickerIntervalSpinner.Name = "timePickerIntervalSpinner";
            this.timePickerIntervalSpinner.Size = new System.Drawing.Size(59, 22);
            this.timePickerIntervalSpinner.TabIndex = 15;
            this.timePickerIntervalSpinner.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.timePickerIntervalSpinner.ValueChanged += new System.EventHandler(this.timePickerIntervalSpinner_ValueChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(234, 432);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(261, 16);
            this.label10.TabIndex = 14;
            this.label10.Text = "Interval (for increment in picker drop-down):";
            // 
            // chkShowSpinnerButtonsInFullSize
            // 
            this.chkShowSpinnerButtonsInFullSize.AutoSize = true;
            this.chkShowSpinnerButtonsInFullSize.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkShowSpinnerButtonsInFullSize.Location = new System.Drawing.Point(237, 327);
            this.chkShowSpinnerButtonsInFullSize.Name = "chkShowSpinnerButtonsInFullSize";
            this.chkShowSpinnerButtonsInFullSize.Size = new System.Drawing.Size(219, 20);
            this.chkShowSpinnerButtonsInFullSize.TabIndex = 13;
            this.chkShowSpinnerButtonsInFullSize.Text = "Show spinner buttons in full size?";
            this.chkShowSpinnerButtonsInFullSize.UseVisualStyleBackColor = true;
            this.chkShowSpinnerButtonsInFullSize.CheckedChanged += new System.EventHandler(this.chkShowSpinnerButtonsInFullSize_CheckedChanged);
            // 
            // msTimeHost
            // 
            this.msTimeHost.CustomFormat = "hh:mm:ss";
            this.msTimeHost.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.msTimeHost.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.msTimeHost.Location = new System.Drawing.Point(236, 34);
            this.msTimeHost.Name = "msTimeHost";
            this.msTimeHost.ShowUpDown = true;
            this.msTimeHost.Size = new System.Drawing.Size(303, 22);
            this.msTimeHost.TabIndex = 12;
            this.msTimeHost.ValueChanged += new System.EventHandler(this.msTimeHost_ValueChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label11.Location = new System.Drawing.Point(24, 36);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(160, 16);
            this.label11.TabIndex = 11;
            this.label11.Text = "Set a time for TimePicker:";
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(253)))), ((int)(((byte)(252)))), ((int)(((byte)(225)))));
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(28, 516);
            this.label12.Name = "label12";
            this.label12.Padding = new System.Windows.Forms.Padding(6);
            this.label12.Size = new System.Drawing.Size(627, 48);
            this.label12.TabIndex = 9;
            this.label12.Text = "There are tons of more capabilities the control has, including being able to set " +
    "colours for every single artefact in the UI, fonts, images for command buttons, " +
    "etc.";
            // 
            // txtTwelveHourTimeDisplayFormat
            // 
            this.txtTwelveHourTimeDisplayFormat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTwelveHourTimeDisplayFormat.Location = new System.Drawing.Point(236, 115);
            this.txtTwelveHourTimeDisplayFormat.Name = "txtTwelveHourTimeDisplayFormat";
            this.txtTwelveHourTimeDisplayFormat.Size = new System.Drawing.Size(303, 22);
            this.txtTwelveHourTimeDisplayFormat.TabIndex = 6;
            this.txtTwelveHourTimeDisplayFormat.TextChanged += new System.EventHandler(this.txtTwelveHourTimeDisplayFormat_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label13.Location = new System.Drawing.Point(24, 145);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(170, 16);
            this.label13.TabIndex = 8;
            this.label13.Text = "24-hour time display format:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label14.Location = new System.Drawing.Point(24, 118);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(170, 16);
            this.label14.TabIndex = 7;
            this.label14.Text = "12-hour time display format:";
            // 
            // txtTwentyFourHourTimeDisplayFormat
            // 
            this.txtTwentyFourHourTimeDisplayFormat.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTwentyFourHourTimeDisplayFormat.Location = new System.Drawing.Point(236, 141);
            this.txtTwentyFourHourTimeDisplayFormat.Name = "txtTwentyFourHourTimeDisplayFormat";
            this.txtTwentyFourHourTimeDisplayFormat.Size = new System.Drawing.Size(303, 22);
            this.txtTwentyFourHourTimeDisplayFormat.TabIndex = 6;
            this.txtTwentyFourHourTimeDisplayFormat.TextChanged += new System.EventHandler(this.txtTwentyFourHourTimeDisplayFormat_TextChanged);
            // 
            // chkShouldRememberUserDropDownSizing
            // 
            this.chkShouldRememberUserDropDownSizing.AutoSize = true;
            this.chkShouldRememberUserDropDownSizing.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkShouldRememberUserDropDownSizing.Location = new System.Drawing.Point(237, 396);
            this.chkShouldRememberUserDropDownSizing.Name = "chkShouldRememberUserDropDownSizing";
            this.chkShouldRememberUserDropDownSizing.Size = new System.Drawing.Size(332, 20);
            this.chkShouldRememberUserDropDownSizing.TabIndex = 5;
            this.chkShouldRememberUserDropDownSizing.Text = "Should remember user sizing of the drop-down view";
            this.chkShouldRememberUserDropDownSizing.UseVisualStyleBackColor = true;
            this.chkShouldRememberUserDropDownSizing.CheckedChanged += new System.EventHandler(this.chkShouldRememberUserDropDownSizing_CheckedChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label15.Location = new System.Drawing.Point(25, 224);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(122, 16);
            this.label15.TabIndex = 4;
            this.label15.Text = "Drop-down related:";
            // 
            // chkEnableDropDownResizing
            // 
            this.chkEnableDropDownResizing.AutoSize = true;
            this.chkEnableDropDownResizing.Checked = true;
            this.chkEnableDropDownResizing.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkEnableDropDownResizing.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkEnableDropDownResizing.Location = new System.Drawing.Point(237, 362);
            this.chkEnableDropDownResizing.Name = "chkEnableDropDownResizing";
            this.chkEnableDropDownResizing.Size = new System.Drawing.Size(230, 20);
            this.chkEnableDropDownResizing.TabIndex = 3;
            this.chkEnableDropDownResizing.Text = "Should enable drop-down resizing";
            this.chkEnableDropDownResizing.UseVisualStyleBackColor = true;
            this.chkEnableDropDownResizing.CheckedChanged += new System.EventHandler(this.chkEnableDropDownResizing_CheckedChanged);
            // 
            // rdTimeConventionTwentyFourHours
            // 
            this.rdTimeConventionTwentyFourHours.AutoSize = true;
            this.rdTimeConventionTwentyFourHours.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdTimeConventionTwentyFourHours.Location = new System.Drawing.Point(407, 77);
            this.rdTimeConventionTwentyFourHours.Name = "rdTimeConventionTwentyFourHours";
            this.rdTimeConventionTwentyFourHours.Size = new System.Drawing.Size(132, 20);
            this.rdTimeConventionTwentyFourHours.TabIndex = 2;
            this.rdTimeConventionTwentyFourHours.Text = "TwentyFour hours";
            this.rdTimeConventionTwentyFourHours.UseVisualStyleBackColor = true;
            this.rdTimeConventionTwentyFourHours.CheckedChanged += new System.EventHandler(this.rdTimeConventionTwentyFourHours_CheckedChanged);
            // 
            // rdTimeConventionTwelveHours
            // 
            this.rdTimeConventionTwelveHours.AutoSize = true;
            this.rdTimeConventionTwelveHours.Checked = true;
            this.rdTimeConventionTwelveHours.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdTimeConventionTwelveHours.Location = new System.Drawing.Point(236, 77);
            this.rdTimeConventionTwelveHours.Name = "rdTimeConventionTwelveHours";
            this.rdTimeConventionTwelveHours.Size = new System.Drawing.Size(106, 20);
            this.rdTimeConventionTwelveHours.TabIndex = 1;
            this.rdTimeConventionTwelveHours.TabStop = true;
            this.rdTimeConventionTwelveHours.Text = "Twelve hours";
            this.rdTimeConventionTwelveHours.UseVisualStyleBackColor = true;
            this.rdTimeConventionTwelveHours.CheckedChanged += new System.EventHandler(this.rdTimeConventionTwelveHours_CheckedChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label16.Location = new System.Drawing.Point(24, 77);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(110, 16);
            this.label16.TabIndex = 0;
            this.label16.Text = "Time convention:";
            // 
            // timePicker1
            // 
            this.timePicker1.AnteMeridianValue = "AM";
            this.timePicker1.ContentPadding = new System.Windows.Forms.Padding(4);
            this.timePicker1.DropDownHostConfiguration.BorderThickness = 0F;
            this.timePicker1.DropDownHostConfiguration.DisplayLocation = new System.Drawing.Point(0, 0);
            this.timePicker1.DropDownHostConfiguration.DisplayTextVisualToTotalSizeRatio = 80F;
            this.timePicker1.DropDownHostConfiguration.DropDownContentPadding = new System.Windows.Forms.Padding(0);
            this.timePicker1.DropDownHostConfiguration.DropDownResizeGripperColor = System.Drawing.Color.White;
            this.timePicker1.DropDownHostConfiguration.DropDownResizeSectionBorderColor = System.Drawing.Color.SlateGray;
            this.timePicker1.DropDownHostConfiguration.DropDownResizeSectionFillColor = System.Drawing.Color.SlateGray;
            this.timePicker1.DropDownHostConfiguration.DropDownSize = new System.Drawing.Size(257, 120);
            this.timePicker1.DropDownHostConfiguration.EnableDropDownResizing = true;
            this.timePicker1.DropDownHostConfiguration.PopupCommandVisualBorderColor = System.Drawing.Color.Chocolate;
            this.timePicker1.DropDownHostConfiguration.PopupCommandVisualBorderColorOnHover = System.Drawing.Color.DarkRed;
            this.timePicker1.DropDownHostConfiguration.PopupCommandVisualBorderColorOnPressed = System.Drawing.Color.SlateGray;
            this.timePicker1.DropDownHostConfiguration.PopupCommandVisualFont = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.timePicker1.DropDownHostConfiguration.PopupCommandVisualHoveredBackColor = System.Drawing.Color.DarkRed;
            this.timePicker1.DropDownHostConfiguration.PopupCommandVisualHoverStateImage = null;
            this.timePicker1.DropDownHostConfiguration.PopupCommandVisualMaximumInternalImageDrawingSize = new System.Drawing.Size(32, 32);
            this.timePicker1.DropDownHostConfiguration.PopupCommandVisualNormalBackColor = System.Drawing.Color.Chocolate;
            this.timePicker1.DropDownHostConfiguration.PopupCommandVisualNormalStateImage = null;
            this.timePicker1.DropDownHostConfiguration.PopupCommandVisualPressedBackColor = System.Drawing.Color.SlateGray;
            this.timePicker1.DropDownHostConfiguration.PopupCommandVisualPressedStateImage = null;
            this.timePicker1.DropDownHostConfiguration.PopupCommandVisualShouldApplyPaddingWhilePositioningImage = false;
            this.timePicker1.DropDownHostConfiguration.PopupCommandVisualText = null;
            this.timePicker1.DropDownHostConfiguration.PopupCommandVisualTextForeColor = System.Drawing.SystemColors.WindowText;
            this.timePicker1.DropDownHostConfiguration.PopupContentHost = null;
            this.timePicker1.DropDownHostConfiguration.ShouldDrawBidirectionalResizeGripper = true;
            this.timePicker1.DropDownHostConfiguration.ShouldDrawDropDownResizeSectionWith3DBorder = false;
            this.timePicker1.DropDownHostConfiguration.ShouldDrawDropShadow = false;
            this.timePicker1.DropDownHostConfiguration.ShouldDrawVerticalResizeGripper = true;
            this.timePicker1.DropDownHostConfiguration.ShouldRememberUserSizedDropDownSize = false;
            this.timePicker1.DropDownHostConfiguration.TextDisplayVisualBackColor = System.Drawing.SystemColors.Window;
            this.timePicker1.DropDownHostConfiguration.TextDisplayVisualBorderColor = System.Drawing.Color.SlateGray;
            this.timePicker1.DropDownHostConfiguration.TextDisplayVisualBorderThickness = 1;
            this.timePicker1.DropDownHostConfiguration.TextDisplayVisualFont = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.timePicker1.DropDownHostConfiguration.TextDisplayVisualTextForeColor = System.Drawing.SystemColors.ControlText;
            this.timePicker1.DropDownTimeSelectionButtonEndColor = System.Drawing.Color.Empty;
            this.timePicker1.DropDownTimeSelectionButtonStartColor = System.Drawing.Color.Empty;
            this.timePicker1.EnforceTimeOnlyFormats = false;
            this.timePicker1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.timePicker1.HourValueComponentBackColor = System.Drawing.Color.Empty;
            this.timePicker1.HourValueComponentBackgroundEndColor = System.Drawing.Color.White;
            this.timePicker1.HourValueComponentBackgroundStartColor = System.Drawing.Color.White;
            this.timePicker1.HourValueComponentDisplayForeColor = System.Drawing.SystemColors.ControlText;
            this.timePicker1.Interval = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.timePicker1.Location = new System.Drawing.Point(17, 60);
            this.timePicker1.MaxValue = 0;
            this.timePicker1.MinuteValueComponentBackColor = System.Drawing.Color.Empty;
            this.timePicker1.MinuteValueComponentBackgroundEndColor = System.Drawing.Color.White;
            this.timePicker1.MinuteValueComponentBackgroundStartColor = System.Drawing.Color.White;
            this.timePicker1.MinuteValueComponentDisplayForeColor = System.Drawing.SystemColors.ControlText;
            this.timePicker1.MinValue = 0;
            this.timePicker1.MousePressedValueChangeTriggerSpeed = 350;
            this.timePicker1.Name = "timePicker1";
            this.timePicker1.PostMeridianValue = "PM";
            this.timePicker1.SecondValueComponentBackColor = System.Drawing.Color.Empty;
            this.timePicker1.SecondValueComponentBackgroundEndColor = System.Drawing.Color.White;
            this.timePicker1.SecondValueComponentBackgroundStartColor = System.Drawing.Color.White;
            this.timePicker1.SecondValueComponentDisplayForeColor = System.Drawing.SystemColors.ControlText;
            this.timePicker1.ShouldAutoScaleTimePickerComponentsFont = false;
            this.timePicker1.ShouldCloseSelectorDropDownViewUponAcceptCancelChanges = false;
            this.timePicker1.ShouldDrawSpinnerButtonsInFullSize = false;
            this.timePicker1.Size = new System.Drawing.Size(192, 29);
            this.timePicker1.SpinnerBackgroundBrushEndColor = System.Drawing.Color.White;
            this.timePicker1.SpinnerBackgroundBrushStartColor = System.Drawing.Color.Red;
            this.timePicker1.SpinnerHoverBackgroundBrushEndColor = System.Drawing.Color.White;
            this.timePicker1.SpinnerHoverBackgroundBrushStartColor = System.Drawing.Color.Green;
            this.timePicker1.SpinnerPressedBackgroundBrushEndColor = System.Drawing.Color.White;
            this.timePicker1.SpinnerPressedBackgroundBrushStartColor = System.Drawing.Color.Purple;
            this.timePicker1.TabIndex = 4;
            this.timePicker1.Text = "timePickerDropDown1";
            this.timePicker1.TimeConvention = Binarymission.WinForms.Controls.AdvancedSelectors.TimeSelectors.Data.TimeConvention.TwelveHours;
            this.timePicker1.TimeMeridianValueComponentBackColor = System.Drawing.Color.Empty;
            this.timePicker1.TimeMeridianValueComponentBackgroundEndColor = System.Drawing.Color.White;
            this.timePicker1.TimeMeridianValueComponentBackgroundStartColor = System.Drawing.Color.White;
            this.timePicker1.TimeMeridianValueComponentDisplayForeColor = System.Drawing.Color.Black;
            this.timePicker1.TimePickerComponentsFont = null;
            this.timePicker1.TimePickerDropDownBackgroundEndColor = System.Drawing.Color.White;
            this.timePicker1.TimePickerDropDownBackgroundStartColor = System.Drawing.Color.White;
            this.timePicker1.TimeValue = new System.DateTime(2017, 7, 2, 12, 21, 34, 961);
            this.timePicker1.TwelveHoursTimeDisplayFormat = "hh: mm: ss tt";
            this.timePicker1.TwentyFourHoursTimeDisplayFormat = "HH: mm: ss";
            this.timePicker1.ValueComponentBackColor = System.Drawing.Color.Empty;
            this.timePicker1.ValueComponentBorderColor = System.Drawing.Color.Black;
            this.timePicker1.ValueComponentBorderThickness = 1;
            this.timePicker1.ValueDisplayTextFontOffSetFactor = 5;
            stringFormat1.Alignment = System.Drawing.StringAlignment.Center;
            stringFormat1.HotkeyPrefix = System.Drawing.Text.HotkeyPrefix.None;
            stringFormat1.LineAlignment = System.Drawing.StringAlignment.Center;
            stringFormat1.Trimming = System.Drawing.StringTrimming.Character;
            this.timePicker1.ValueStringFormat = stringFormat1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(982, 702);
            this.Controls.Add(this.timePicker1);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Binarymission TimePicker .NET control Demo";
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spinnerMousePresTimeChangeTriggerSpeed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.timePickerIntervalSpinner)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnExit;
        private Binarymission.WinForms.Controls.AdvancedSelectors.TimeSelectors.Core.TimePickerDropDown timePicker1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.NumericUpDown spinnerMousePresTimeChangeTriggerSpeed;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown timePickerIntervalSpinner;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.CheckBox chkShowSpinnerButtonsInFullSize;
        private System.Windows.Forms.DateTimePicker msTimeHost;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtTwelveHourTimeDisplayFormat;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtTwentyFourHourTimeDisplayFormat;
        private System.Windows.Forms.CheckBox chkShouldRememberUserDropDownSizing;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.CheckBox chkEnableDropDownResizing;
        private System.Windows.Forms.RadioButton rdTimeConventionTwentyFourHours;
        private System.Windows.Forms.RadioButton rdTimeConventionTwelveHours;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.CheckBox chkEnforceTimeOnlyFormats;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtAnteMeridianValue;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPostMeridianValue;
    }
}

