﻿namespace TreeListViewDemo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.configureToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.allowColumnReorderingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.drawCellBorderWhenSelectingACell = new System.Windows.Forms.ToolStripMenuItem();
            this.allowRowHeightToBeResizeableToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.allowTreelistColumnCellToWrapIntoMultipleLinesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.drawColumnBackgroundWithRandomColorUponSelectingACell = new System.Windows.Forms.ToolStripMenuItem();
            this.drawColumnBackgroundDrawingUponMouseHoveringToolstripMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.showNodeImageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enableDrawingNodeConnectingLinesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.enableTreelistColumnCellEditingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.applyTreelistColumnFormattingToAllColumnsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.drawColumnSeparatorLineToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.renderSampleRadioButtonsCheckboxesOrImagesOnLeafnodesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enableAutomaticBuiltinDragDropOfTreeNodesFeatureToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.expandAllNodesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.collapseAllNodesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.expandTheSelectedNodeOnlyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.collapseTheSelectedNodeOnlyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.expandTheSelectedNodeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.collapseTheSelectedNodeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.cmdExpandNode = new System.Windows.Forms.ToolStripMenuItem();
            this.cmdCollapseNode = new System.Windows.Forms.ToolStripMenuItem();
            this.cmdExpandNodeDeep = new System.Windows.Forms.ToolStripMenuItem();
            this.cmdCollapseNodeDeep = new System.Windows.Forms.ToolStripMenuItem();
            this.copySelectedNodesToClipboard = new System.Windows.Forms.ToolStripMenuItem();
            this.applyBackColorForColumnToolstripItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.configureToolStripMenuItem,
            this.toolStripMenuItem2});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(799, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F)));
            this.toolStripMenuItem1.Size = new System.Drawing.Size(37, 20);
            this.toolStripMenuItem1.Text = "&File";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(92, 22);
            this.exitToolStripMenuItem.Text = "E&xit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.ExitToolStripMenuItemClick);
            // 
            // configureToolStripMenuItem
            // 
            this.configureToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.allowColumnReorderingToolStripMenuItem,
            this.drawCellBorderWhenSelectingACell,
            this.allowRowHeightToBeResizeableToolStripMenuItem,
            this.allowTreelistColumnCellToWrapIntoMultipleLinesToolStripMenuItem,
            this.toolStripSeparator4,
            this.drawColumnBackgroundWithRandomColorUponSelectingACell,
            this.drawColumnBackgroundDrawingUponMouseHoveringToolstripMenu,
            this.toolStripSeparator1,
            this.showNodeImageToolStripMenuItem,
            this.enableDrawingNodeConnectingLinesToolStripMenuItem,
            this.toolStripSeparator2,
            this.enableTreelistColumnCellEditingToolStripMenuItem,
            this.applyTreelistColumnFormattingToAllColumnsToolStripMenuItem,
            this.drawColumnSeparatorLineToolStripMenuItem,
            this.toolStripSeparator3,
            this.renderSampleRadioButtonsCheckboxesOrImagesOnLeafnodesToolStripMenuItem,
            this.enableAutomaticBuiltinDragDropOfTreeNodesFeatureToolStripMenuItem});
            this.configureToolStripMenuItem.Name = "configureToolStripMenuItem";
            this.configureToolStripMenuItem.Size = new System.Drawing.Size(72, 20);
            this.configureToolStripMenuItem.Text = "&Configure";
            // 
            // allowColumnReorderingToolStripMenuItem
            // 
            this.allowColumnReorderingToolStripMenuItem.Checked = true;
            this.allowColumnReorderingToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.allowColumnReorderingToolStripMenuItem.Name = "allowColumnReorderingToolStripMenuItem";
            this.allowColumnReorderingToolStripMenuItem.Size = new System.Drawing.Size(430, 22);
            this.allowColumnReorderingToolStripMenuItem.Text = "Allow column re-ordering";
            this.allowColumnReorderingToolStripMenuItem.Click += new System.EventHandler(this.AllowColumnReorderingToolStripMenuItemClick);
            // 
            // drawCellBorderWhenSelectingACell
            // 
            this.drawCellBorderWhenSelectingACell.Name = "drawCellBorderWhenSelectingACell";
            this.drawCellBorderWhenSelectingACell.Size = new System.Drawing.Size(430, 22);
            this.drawCellBorderWhenSelectingACell.Text = "Draw Cell border when selecting a cell";
            this.drawCellBorderWhenSelectingACell.Click += new System.EventHandler(this.DrawCellBorderWhenSelectingACellClick);
            // 
            // allowRowHeightToBeResizeableToolStripMenuItem
            // 
            this.allowRowHeightToBeResizeableToolStripMenuItem.Name = "allowRowHeightToBeResizeableToolStripMenuItem";
            this.allowRowHeightToBeResizeableToolStripMenuItem.Size = new System.Drawing.Size(430, 22);
            this.allowRowHeightToBeResizeableToolStripMenuItem.Text = "Allow row height to be re-sizeable";
            this.allowRowHeightToBeResizeableToolStripMenuItem.Click += new System.EventHandler(this.AllowRowHeightToBeResizeableToolStripMenuItemClick);
            // 
            // allowTreelistColumnCellToWrapIntoMultipleLinesToolStripMenuItem
            // 
            this.allowTreelistColumnCellToWrapIntoMultipleLinesToolStripMenuItem.Checked = true;
            this.allowTreelistColumnCellToWrapIntoMultipleLinesToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.allowTreelistColumnCellToWrapIntoMultipleLinesToolStripMenuItem.Name = "allowTreelistColumnCellToWrapIntoMultipleLinesToolStripMenuItem";
            this.allowTreelistColumnCellToWrapIntoMultipleLinesToolStripMenuItem.Size = new System.Drawing.Size(430, 22);
            this.allowTreelistColumnCellToWrapIntoMultipleLinesToolStripMenuItem.Text = "Allow Treelist column / cell to wrap into multiple lines";
            this.allowTreelistColumnCellToWrapIntoMultipleLinesToolStripMenuItem.Click += new System.EventHandler(this.AllowTreelistColumnCellToWrapIntoMultipleLinesToolStripMenuItemClick);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(427, 6);
            // 
            // drawColumnBackgroundWithRandomColorUponSelectingACell
            // 
            this.drawColumnBackgroundWithRandomColorUponSelectingACell.Name = "drawColumnBackgroundWithRandomColorUponSelectingACell";
            this.drawColumnBackgroundWithRandomColorUponSelectingACell.Size = new System.Drawing.Size(430, 22);
            this.drawColumnBackgroundWithRandomColorUponSelectingACell.Text = "Draw column background with random color upon selecting a cell";
            this.drawColumnBackgroundWithRandomColorUponSelectingACell.Click += new System.EventHandler(this.drawColumnBackgroundWithRandomColorUponSelectingACell_Click);
            // 
            // drawColumnBackgroundDrawingUponMouseHoveringToolstripMenu
            // 
            this.drawColumnBackgroundDrawingUponMouseHoveringToolstripMenu.Name = "drawColumnBackgroundDrawingUponMouseHoveringToolstripMenu";
            this.drawColumnBackgroundDrawingUponMouseHoveringToolstripMenu.Size = new System.Drawing.Size(430, 22);
            this.drawColumnBackgroundDrawingUponMouseHoveringToolstripMenu.Text = "Draw column background with random color upon mouse hoving";
            this.drawColumnBackgroundDrawingUponMouseHoveringToolstripMenu.Click += new System.EventHandler(this.DrawColumnBackgroundDrawingUponMouseHoveringToolstripMenuClick);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(427, 6);
            // 
            // showNodeImageToolStripMenuItem
            // 
            this.showNodeImageToolStripMenuItem.Checked = true;
            this.showNodeImageToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.showNodeImageToolStripMenuItem.Name = "showNodeImageToolStripMenuItem";
            this.showNodeImageToolStripMenuItem.Size = new System.Drawing.Size(430, 22);
            this.showNodeImageToolStripMenuItem.Text = "Show custom image for Node images";
            this.showNodeImageToolStripMenuItem.Click += new System.EventHandler(this.ShowNodeImageToolStripMenuItemClick);
            // 
            // enableDrawingNodeConnectingLinesToolStripMenuItem
            // 
            this.enableDrawingNodeConnectingLinesToolStripMenuItem.Checked = true;
            this.enableDrawingNodeConnectingLinesToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.enableDrawingNodeConnectingLinesToolStripMenuItem.Name = "enableDrawingNodeConnectingLinesToolStripMenuItem";
            this.enableDrawingNodeConnectingLinesToolStripMenuItem.Size = new System.Drawing.Size(430, 22);
            this.enableDrawingNodeConnectingLinesToolStripMenuItem.Text = "Enable drawing node connecting lines";
            this.enableDrawingNodeConnectingLinesToolStripMenuItem.Click += new System.EventHandler(this.EnableDrawingNodeConnectingLinesToolStripMenuItemClick);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(427, 6);
            // 
            // enableTreelistColumnCellEditingToolStripMenuItem
            // 
            this.enableTreelistColumnCellEditingToolStripMenuItem.Checked = true;
            this.enableTreelistColumnCellEditingToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.enableTreelistColumnCellEditingToolStripMenuItem.Name = "enableTreelistColumnCellEditingToolStripMenuItem";
            this.enableTreelistColumnCellEditingToolStripMenuItem.Size = new System.Drawing.Size(430, 22);
            this.enableTreelistColumnCellEditingToolStripMenuItem.Text = "Enable Tree-list column cell editing";
            this.enableTreelistColumnCellEditingToolStripMenuItem.Click += new System.EventHandler(this.EnableTreelistColumnCellEditingToolStripMenuItemClick);
            // 
            // applyTreelistColumnFormattingToAllColumnsToolStripMenuItem
            // 
            this.applyTreelistColumnFormattingToAllColumnsToolStripMenuItem.Checked = true;
            this.applyTreelistColumnFormattingToAllColumnsToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.applyTreelistColumnFormattingToAllColumnsToolStripMenuItem.Name = "applyTreelistColumnFormattingToAllColumnsToolStripMenuItem";
            this.applyTreelistColumnFormattingToAllColumnsToolStripMenuItem.Size = new System.Drawing.Size(430, 22);
            this.applyTreelistColumnFormattingToAllColumnsToolStripMenuItem.Text = "Apply Tree-list column cell formatting to all columns";
            this.applyTreelistColumnFormattingToAllColumnsToolStripMenuItem.Click += new System.EventHandler(this.ApplyTreelistColumnFormattingToAllColumnsToolStripMenuItemClick);
            // 
            // drawColumnSeparatorLineToolStripMenuItem
            // 
            this.drawColumnSeparatorLineToolStripMenuItem.Checked = true;
            this.drawColumnSeparatorLineToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.drawColumnSeparatorLineToolStripMenuItem.Name = "drawColumnSeparatorLineToolStripMenuItem";
            this.drawColumnSeparatorLineToolStripMenuItem.Size = new System.Drawing.Size(430, 22);
            this.drawColumnSeparatorLineToolStripMenuItem.Text = "Draw Column separator line";
            this.drawColumnSeparatorLineToolStripMenuItem.Click += new System.EventHandler(this.DrawColumnSeparatorLineToolStripMenuItemClick);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(427, 6);
            // 
            // renderSampleRadioButtonsCheckboxesOrImagesOnLeafnodesToolStripMenuItem
            // 
            this.renderSampleRadioButtonsCheckboxesOrImagesOnLeafnodesToolStripMenuItem.Name = "renderSampleRadioButtonsCheckboxesOrImagesOnLeafnodesToolStripMenuItem";
            this.renderSampleRadioButtonsCheckboxesOrImagesOnLeafnodesToolStripMenuItem.Size = new System.Drawing.Size(430, 22);
            this.renderSampleRadioButtonsCheckboxesOrImagesOnLeafnodesToolStripMenuItem.Text = "Render Sample RadioButtons, Checkboxes or Images on Leaf-nodes";
            this.renderSampleRadioButtonsCheckboxesOrImagesOnLeafnodesToolStripMenuItem.Click += new System.EventHandler(this.RenderSampleRadioButtonsCheckboxesOrImagesOnLeafnodesToolStripMenuItemToolStripMenuItemClick);
            // 
            // enableAutomaticBuiltinDragDropOfTreeNodesFeatureToolStripMenuItem
            // 
            this.enableAutomaticBuiltinDragDropOfTreeNodesFeatureToolStripMenuItem.CheckOnClick = true;
            this.enableAutomaticBuiltinDragDropOfTreeNodesFeatureToolStripMenuItem.Name = "enableAutomaticBuiltinDragDropOfTreeNodesFeatureToolStripMenuItem";
            this.enableAutomaticBuiltinDragDropOfTreeNodesFeatureToolStripMenuItem.Size = new System.Drawing.Size(430, 22);
            this.enableAutomaticBuiltinDragDropOfTreeNodesFeatureToolStripMenuItem.Text = "Enable automatic built-in drag && drop of tree nodes feature";
            this.enableAutomaticBuiltinDragDropOfTreeNodesFeatureToolStripMenuItem.Click += new System.EventHandler(this.enableAutomaticBuiltInDragDropOfTreeNodesFeatureToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.expandAllNodesToolStripMenuItem,
            this.collapseAllNodesToolStripMenuItem,
            this.expandTheSelectedNodeOnlyToolStripMenuItem,
            this.collapseTheSelectedNodeOnlyToolStripMenuItem,
            this.expandTheSelectedNodeToolStripMenuItem,
            this.collapseTheSelectedNodeToolStripMenuItem});
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(81, 20);
            this.toolStripMenuItem2.Text = "C&ommands";
            // 
            // expandAllNodesToolStripMenuItem
            // 
            this.expandAllNodesToolStripMenuItem.Name = "expandAllNodesToolStripMenuItem";
            this.expandAllNodesToolStripMenuItem.Size = new System.Drawing.Size(310, 22);
            this.expandAllNodesToolStripMenuItem.Text = "E&xpand All nodes";
            this.expandAllNodesToolStripMenuItem.Click += new System.EventHandler(this.ExpandAllNodesToolStripMenuItemClick);
            // 
            // collapseAllNodesToolStripMenuItem
            // 
            this.collapseAllNodesToolStripMenuItem.Name = "collapseAllNodesToolStripMenuItem";
            this.collapseAllNodesToolStripMenuItem.Size = new System.Drawing.Size(310, 22);
            this.collapseAllNodesToolStripMenuItem.Text = "C&ollapse All nodes";
            this.collapseAllNodesToolStripMenuItem.Click += new System.EventHandler(this.CollapseAllNodesToolStripMenuItemClick);
            // 
            // expandTheSelectedNodeOnlyToolStripMenuItem
            // 
            this.expandTheSelectedNodeOnlyToolStripMenuItem.Name = "expandTheSelectedNodeOnlyToolStripMenuItem";
            this.expandTheSelectedNodeOnlyToolStripMenuItem.Size = new System.Drawing.Size(310, 22);
            this.expandTheSelectedNodeOnlyToolStripMenuItem.Text = "Expand the selected node only";
            this.expandTheSelectedNodeOnlyToolStripMenuItem.Click += new System.EventHandler(this.expandTheSelectedNodeOnlyToolStripMenuItem_Click);
            // 
            // collapseTheSelectedNodeOnlyToolStripMenuItem
            // 
            this.collapseTheSelectedNodeOnlyToolStripMenuItem.Name = "collapseTheSelectedNodeOnlyToolStripMenuItem";
            this.collapseTheSelectedNodeOnlyToolStripMenuItem.Size = new System.Drawing.Size(310, 22);
            this.collapseTheSelectedNodeOnlyToolStripMenuItem.Text = "Collapse the selected node only";
            this.collapseTheSelectedNodeOnlyToolStripMenuItem.Click += new System.EventHandler(this.collapseTheSelectedNodeOnlyToolStripMenuItem_Click);
            // 
            // expandTheSelectedNodeToolStripMenuItem
            // 
            this.expandTheSelectedNodeToolStripMenuItem.Name = "expandTheSelectedNodeToolStripMenuItem";
            this.expandTheSelectedNodeToolStripMenuItem.Size = new System.Drawing.Size(310, 22);
            this.expandTheSelectedNodeToolStripMenuItem.Text = "Expand the Selected node (and its children)";
            this.expandTheSelectedNodeToolStripMenuItem.Click += new System.EventHandler(this.expandTheSelectedNodeToolStripMenuItem_Click);
            // 
            // collapseTheSelectedNodeToolStripMenuItem
            // 
            this.collapseTheSelectedNodeToolStripMenuItem.Name = "collapseTheSelectedNodeToolStripMenuItem";
            this.collapseTheSelectedNodeToolStripMenuItem.Size = new System.Drawing.Size(310, 22);
            this.collapseTheSelectedNodeToolStripMenuItem.Text = "Collapse the selected node  (and its children)";
            this.collapseTheSelectedNodeToolStripMenuItem.Click += new System.EventHandler(this.collapseTheSelectedNodeToolStripMenuItem_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cmdExpandNode,
            this.cmdCollapseNode,
            this.cmdExpandNodeDeep,
            this.cmdCollapseNodeDeep,
            this.copySelectedNodesToClipboard,
            this.applyBackColorForColumnToolstripItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(341, 136);
            // 
            // cmdExpandNode
            // 
            this.cmdExpandNode.Name = "cmdExpandNode";
            this.cmdExpandNode.Size = new System.Drawing.Size(340, 22);
            this.cmdExpandNode.Text = "Expand node";
            // 
            // cmdCollapseNode
            // 
            this.cmdCollapseNode.Name = "cmdCollapseNode";
            this.cmdCollapseNode.Size = new System.Drawing.Size(340, 22);
            this.cmdCollapseNode.Text = "Collapse node";
            // 
            // cmdExpandNodeDeep
            // 
            this.cmdExpandNodeDeep.Name = "cmdExpandNodeDeep";
            this.cmdExpandNodeDeep.Size = new System.Drawing.Size(340, 22);
            this.cmdExpandNodeDeep.Text = "Expand node deep (including all children)";
            // 
            // cmdCollapseNodeDeep
            // 
            this.cmdCollapseNodeDeep.Name = "cmdCollapseNodeDeep";
            this.cmdCollapseNodeDeep.Size = new System.Drawing.Size(340, 22);
            this.cmdCollapseNodeDeep.Text = "Collapse node deep (including all children)";
            // 
            // copySelectedNodesToClipboard
            // 
            this.copySelectedNodesToClipboard.Name = "copySelectedNodesToClipboard";
            this.copySelectedNodesToClipboard.Size = new System.Drawing.Size(340, 22);
            this.copySelectedNodesToClipboard.Text = "Copy Selected nodes(s) to Clipboard";
            // 
            // applyBackColorForColumnToolstripItem
            // 
            this.applyBackColorForColumnToolstripItem.CheckOnClick = true;
            this.applyBackColorForColumnToolstripItem.Name = "applyBackColorForColumnToolstripItem";
            this.applyBackColorForColumnToolstripItem.Size = new System.Drawing.Size(340, 22);
            this.applyBackColorForColumnToolstripItem.Text = "Apply a random background color for this column";
            // 
            // panel1
            // 
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 24);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(799, 470);
            this.panel1.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundDisabledCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundDisabledMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundHotMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundNormalMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedCloseCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMaximizeRestoreCommandButton.Color = System.Drawing.Color.SlateGray;
            this.BackgroundPressedMinimizeCommandButton.Color = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(799, 494);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.DefaultNormalWindowSize = new System.Drawing.Size(300, 300);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.TitlebarText = "Binarymission TreeListView .NET control Demo (WinForms)";
            this.WindowChromeTitleTextBrush.Color = System.Drawing.Color.White;
            this.WindowChromeTitleTextBrushWhenTitlebarBackgroundIsTransparent.Color = System.Drawing.Color.SlateGray;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem configureToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem allowColumnReorderingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem allowRowHeightToBeResizeableToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem allowTreelistColumnCellToWrapIntoMultipleLinesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem expandAllNodesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem collapseAllNodesToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem showNodeImageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem enableDrawingNodeConnectingLinesToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem copySelectedNodesToClipboard;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem enableTreelistColumnCellEditingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem applyTreelistColumnFormattingToAllColumnsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem drawColumnSeparatorLineToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem renderSampleRadioButtonsCheckboxesOrImagesOnLeafnodesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem drawCellBorderWhenSelectingACell;
        private System.Windows.Forms.ToolStripMenuItem applyBackColorForColumnToolstripItem;
        private System.Windows.Forms.ToolStripMenuItem drawColumnBackgroundDrawingUponMouseHoveringToolstripMenu;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem drawColumnBackgroundWithRandomColorUponSelectingACell;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolStripMenuItem enableAutomaticBuiltinDragDropOfTreeNodesFeatureToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem expandTheSelectedNodeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem collapseTheSelectedNodeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem expandTheSelectedNodeOnlyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem collapseTheSelectedNodeOnlyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cmdExpandNode;
        private System.Windows.Forms.ToolStripMenuItem cmdCollapseNode;
        private System.Windows.Forms.ToolStripMenuItem cmdExpandNodeDeep;
        private System.Windows.Forms.ToolStripMenuItem cmdCollapseNodeDeep;
    }
}



